<?php
$page_title = 'Register';
include 'includes/header.php';

if (isLoggedIn()) redirect(BASE_URL . '/index.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $email = mysqli_real_escape_string(db(), $_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    $errors = [];
    if (empty($name)) $errors[] = 'Name is required.';
    if (empty($email)) $errors[] = 'Email is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    $check = mysqli_query(db(), "SELECT id FROM users WHERE email = '$email'");
    if (mysqli_num_rows($check) > 0) $errors[] = 'Email already registered.';

    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hash')";
        if (mysqli_query(db(), $sql)) {
            setFlash('success', 'Registration successful! Please login.');
            redirect(BASE_URL . '/login.php');
        } else {
            $errors[] = 'Registration failed. Try again.';
        }
    }
}
?>

<div class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-header">
            <h3><i class="bi bi-person-plus-fill"></i> Create Account</h3>
            <p>Join ShopWise for the best shopping experience</p>
        </div>
        <div class="auth-body">
            <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" required value="<?= isset($_POST['name']) ? sanitize($_POST['name']) : '' ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" required value="<?= isset($_POST['email']) ? sanitize($_POST['email']) : '' ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>
                <button type="submit" class="btn-primary-custom w-100">Register Now</button>
            </form>
        </div>
        <div class="auth-footer">
            <p>Already have an account? <a href="<?= BASE_URL ?>/login.php">Login here</a></p>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
