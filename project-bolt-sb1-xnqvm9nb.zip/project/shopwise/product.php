<?php
$page_title = 'Product';
include 'includes/header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$product = getProductById($id);

if (!$product) {
    setFlash('error', 'Product not found.');
    redirect(BASE_URL . '/index.php');
}

$related = getProducts("AND p.category_id = {$product['category_id']} AND p.id != $id LIMIT 4");
?>

<div class="page-banner">
    <div class="container">
        <h1><?= sanitize($product['name']) ?></h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/category.php?id=<?= $product['category_id'] ?>"><?= sanitize($product['category_name']) ?></a></li>
                <li class="breadcrumb-item active"><?= sanitize($product['name']) ?></li>
            </ol>
        </nav>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-5">
                <div style="background:#fff;border-radius:var(--radius-lg);overflow:hidden;box-shadow:var(--shadow-md);">
                    <img src="<?= getProductImage($product) ?>" alt="<?= sanitize($product['name']) ?>" style="width:100%;aspect-ratio:1;object-fit:cover;">
                </div>
            </div>
            <div class="col-lg-7">
                <span class="product-brand" style="font-size:0.9rem;"><?= sanitize($product['brand_name']) ?></span>
                <h2 style="font-weight:700;margin-bottom:15px;"><?= sanitize($product['name']) ?></h2>
                <p style="color:var(--gray);margin-bottom:20px;">
                    <i class="bi bi-tag"></i> Category: <?= sanitize($product['category_name']) ?> &nbsp;|&nbsp;
                    <i class="bi bi-bookmark-star"></i> Brand: <?= sanitize($product['brand_name']) ?>
                </p>
                <div class="product-price-row mb-3" style="align-items:baseline;">
                    <span class="product-price" style="font-size:2rem;"><?= formatPrice($product['sale_price'] ?: $product['price']) ?></span>
                    <?php if ($product['sale_price']): ?>
                    <span class="product-old-price" style="font-size:1.2rem;"><?= formatPrice($product['price']) ?></span>
                    <span class="product-discount">Save <?= formatPrice($product['price'] - $product['sale_price']) ?></span>
                    <?php endif; ?>
                </div>
                <p style="line-height:1.8;color:var(--dark);margin-bottom:25px;"><?= sanitize($product['description'] ?? 'No description available.') ?></p>

                <div class="mb-3">
                    <?php if ($product['stock'] > 0): ?>
                    <span class="badge bg-success"><i class="bi bi-check-circle"></i> In Stock (<?= $product['stock'] ?> available)</span>
                    <?php else: ?>
                    <span class="badge bg-danger">Out of Stock</span>
                    <?php endif; ?>
                </div>

                <form action="<?= BASE_URL ?>/cart.php" method="GET" class="d-flex gap-2 align-items-center mb-3">
                    <input type="hidden" name="action" value="add">
                    <input type="hidden" name="id" value="<?= $product['id'] ?>">
                    <div class="input-group" style="width:auto;">
                        <button class="btn btn-outline-secondary qty-btn" type="button" data-action="minus">-</button>
                        <input type="number" name="qty" id="qty" value="1" min="1" class="form-control text-center" style="width:60px;">
                        <button class="btn btn-outline-secondary qty-btn" type="button" data-action="plus">+</button>
                    </div>
                    <button type="submit" class="btn-primary-custom"><i class="bi bi-cart-plus"></i> Add to Cart</button>
                </form>
                <a href="<?= BASE_URL ?>/cart.php?action=add&id=<?= $product['id'] ?>" class="btn-secondary-custom"><i class="bi bi-lightning"></i> Buy Now</a>
            </div>
        </div>

        <!-- Related Products -->
        <div class="mt-5">
            <div class="section-title"><h2>Related Products</h2></div>
            <div class="row g-4">
                <?php while ($r = mysqli_fetch_assoc($related)): ?>
                <div class="col-lg-3 col-md-6">
                    <div class="product-card">
                        <div class="product-img-wrap">
                            <img src="<?= getProductImage($r) ?>" alt="<?= sanitize($r['name']) ?>">
                        </div>
                        <div class="product-info">
                            <span class="product-brand"><?= sanitize($r['brand_name']) ?></span>
                            <a href="<?= BASE_URL ?>/product.php?id=<?= $r['id'] ?>" class="product-name"><?= sanitize($r['name']) ?></a>
                            <div class="product-price-row">
                                <span class="product-price"><?= formatPrice($r['sale_price'] ?: $r['price']) ?></span>
                            </div>
                            <a href="<?= BASE_URL ?>/cart.php?action=add&id=<?= $r['id'] ?>" class="btn-add-cart"><i class="bi bi-cart-plus"></i> Add to Cart</a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
