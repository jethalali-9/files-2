<?php
session_start();
session_destroy();
redirect(BASE_URL . '/index.php');
