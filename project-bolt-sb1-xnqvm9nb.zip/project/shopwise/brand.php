<?php
$page_title = 'Shop by Brand';
include 'includes/header.php';

$brand_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$brand = getBrandById($brand_id);

if (!$brand) {
    setFlash('error', 'Brand not found.');
    redirect(BASE_URL . '/index.php');
}

// Filter by category within brand
$cat_filter = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$where = "AND p.brand_id = $brand_id";
if ($cat_filter) $where .= " AND p.category_id = $cat_filter";

$products = getProducts($where);
$categories = getCategories();
?>

<div class="page-banner">
    <div class="container">
        <h1><?= sanitize($brand['name']) ?></h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php#brands">Brands</a></li>
                <li class="breadcrumb-item active"><?= sanitize($brand['name']) ?></li>
            </ol>
        </nav>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <div class="row">
            <!-- Filter Sidebar -->
            <div class="col-lg-3 mb-4">
                <div class="filter-sidebar">
                    <div class="filter-group">
                        <h6><i class="bi bi-funnel"></i> Filter by Category</h6>
                        <div class="filter-option">
                            <a href="<?= BASE_URL ?>/brand.php?id=<?= $brand_id ?>" style="text-decoration:none;color:inherit;display:flex;width:100%;">
                                <label>All Categories</label>
                            </a>
                        </div>
                        <?php while ($c = mysqli_fetch_assoc($categories)): ?>
                        <div class="filter-option">
                            <a href="<?= BASE_URL ?>/brand.php?id=<?= $brand_id ?>&cat=<?= $c['id'] ?>" style="text-decoration:none;color:inherit;display:flex;width:100%;">
                                <label><?= sanitize($c['name']) ?></label>
                            </a>
                        </div>
                        <?php endwhile; ?>
                    </div>
                    <div class="filter-group">
                        <h6><i class="bi bi-info-circle"></i> About Brand</h6>
                        <p style="font-size:0.9rem;color:var(--gray);"><?= sanitize($brand['description'] ?? 'No description available.') ?></p>
                    </div>
                </div>
            </div>

            <!-- Products -->
            <div class="col-lg-9">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">Products by <?= sanitize($brand['name']) ?></h4>
                    <span class="text-muted"><?= mysqli_num_rows($products) ?> items found</span>
                </div>
                <?php if (mysqli_num_rows($products) > 0): ?>
                <div class="row g-4">
                    <?php while ($p = mysqli_fetch_assoc($products)): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="product-card">
                            <div class="product-img-wrap">
                                <img src="<?= getProductImage($p) ?>" alt="<?= sanitize($p['name']) ?>">
                                <?php if ($p['sale_price']): ?>
                                <span class="product-badge">Sale</span>
                                <?php endif; ?>
                                <div class="product-actions">
                                    <a href="<?= BASE_URL ?>/product.php?id=<?= $p['id'] ?>" class="product-action-btn" title="View"><i class="bi bi-eye"></i></a>
                                </div>
                            </div>
                            <div class="product-info">
                                <span class="product-brand"><?= sanitize($p['brand_name']) ?></span>
                                <a href="<?= BASE_URL ?>/product.php?id=<?= $p['id'] ?>" class="product-name"><?= sanitize($p['name']) ?></a>
                                <span class="product-category-tag"><?= sanitize($p['category_name']) ?></span>
                                <div class="product-price-row">
                                    <span class="product-price"><?= formatPrice($p['sale_price'] ?: $p['price']) ?></span>
                                    <?php if ($p['sale_price']): ?>
                                    <span class="product-old-price"><?= formatPrice($p['price']) ?></span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?= BASE_URL ?>/cart.php?action=add&id=<?= $p['id'] ?>" class="btn-add-cart"><i class="bi bi-cart-plus"></i> Add to Cart</a>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
                <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-search" style="font-size:4rem;color:var(--gray-light);"></i>
                    <h4 class="mt-3">No products found</h4>
                    <p class="text-muted">Try changing the filter or check back later.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
