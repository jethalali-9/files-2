-- ShopWise Database Schema
-- Import this file in phpMyAdmin (XAMPP/WAMP)

CREATE DATABASE IF NOT EXISTS shopwise_db;
USE shopwise_db;

-- Admins table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    address TEXT DEFAULT NULL,
    city VARCHAR(50) DEFAULT NULL,
    pincode VARCHAR(10) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Brands table
CREATE TABLE IF NOT EXISTS brands (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT DEFAULT NULL,
    image VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT DEFAULT NULL,
    image VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT DEFAULT NULL,
    price DECIMAL(10,2) NOT NULL,
    sale_price DECIMAL(10,2) DEFAULT NULL,
    image VARCHAR(255) DEFAULT NULL,
    brand_id INT NOT NULL,
    category_id INT NOT NULL,
    stock INT DEFAULT 0,
    featured TINYINT(1) DEFAULT 0,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('Pending','Processing','Shipped','Delivered','Cancelled') DEFAULT 'Pending',
    shipping_address TEXT NOT NULL,
    city VARCHAR(50) NOT NULL,
    pincode VARCHAR(10) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    payment_method VARCHAR(50) DEFAULT 'Cash on Delivery',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Default admin (email: admin@shopwise.com, password: admin123)
INSERT INTO admins (name, email, password) VALUES ('Admin', 'admin@shopwise.com', '$2y$10$N9.uo6UZ7Hh5nI7mW9qL8eO2eZ8k5nK.7vK5nK.7vK5nK.7vK5nK');

-- Sample brands
INSERT INTO brands (name, description) VALUES
('Nike', 'Just Do It - Premium sportswear and sneakers'),
('Adidas', 'Impossible is Nothing - Sports apparel and footwear'),
('Puma', 'Forever Faster - Athletic and lifestyle products'),
('Levis', 'Quality crafted denim and casual wear'),
('Zara', 'Fast fashion for the modern individual');

-- Sample categories
INSERT INTO categories (name, description) VALUES
('Men', 'Fashion and accessories for men'),
('Women', 'Fashion and accessories for women'),
('Kids', 'Fashion and accessories for kids'),
('Couple', 'Matching outfits and couple fashion');

-- Sample products
INSERT INTO products (name, description, price, sale_price, image, brand_id, category_id, stock, featured) VALUES
('Nike Air Max Running Shoes', 'Lightweight running shoes with Air Max cushioning technology.', 5999.00, 4499.00, '', 1, 1, 50, 1),
('Nike Sportswear T-Shirt', 'Comfortable cotton blend t-shirt with Nike logo.', 1499.00, 999.00, '', 1, 1, 100, 1),
('Adidas Ultraboost', 'Premium running shoes with responsive cushioning.', 7999.00, 5999.00, '', 2, 1, 30, 1),
('Adidas Womens Leggings', 'High-waisted workout leggings with moisture wicking fabric.', 2499.00, 1799.00, '', 2, 2, 80, 1),
('Puma Sneakers', 'Classic lifestyle sneakers for everyday wear.', 3499.00, 2499.00, '', 3, 1, 60, 0),
('Puma Kids Tracksuit', 'Comfortable tracksuit for active kids.', 1999.00, 1499.00, '', 3, 3, 40, 1),
('Levis 511 Slim Jeans', 'Classic slim fit denim jeans.', 3999.00, 2999.00, '', 4, 1, 70, 1),
('Levis Womens Denim Jacket', 'Iconic denim jacket for women.', 4999.00, 3499.00, '', 4, 2, 45, 0),
('Zara Floral Dress', 'Elegant floral summer dress for women.', 3999.00, 2799.00, '', 5, 2, 35, 1),
('Zara Kids Casual Set', 'Soft cotton casual set for kids.', 1799.00, 1299.00, '', 5, 3, 55, 0),
('Nike Couple Sneakers Set', 'Matching sneaker pair for couples.', 8999.00, 6999.00, '', 1, 4, 25, 1),
('Adidas Couple Hoodie Set', 'Matching hoodie set for couples.', 5999.00, 4499.00, '', 2, 4, 30, 1),
('Puma Womens Running Shoes', 'Lightweight running shoes designed for women.', 4499.00, 3299.00, '', 3, 2, 50, 1),
('Levis Kids Denim', 'Durable denim for active kids.', 2499.00, 1799.00, '', 4, 3, 40, 0),
('Zara Mens Blazer', 'Slim fit formal blazer for men.', 6999.00, 4999.00, '', 5, 1, 20, 1);
