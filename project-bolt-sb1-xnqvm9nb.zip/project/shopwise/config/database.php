<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'shopwise_db');

// Connect to database
function db() {
    static $conn = null;
    if ($conn === null) {
        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if (!$conn) {
            die("Database connection failed: " . mysqli_connect_error());
        }
        mysqli_set_charset($conn, "utf8");
    }
    return $conn;
}

// Base URL - change if running in subfolder
define('BASE_URL', '/shopwise');
define('ADMIN_URL', BASE_URL . '/admin');
