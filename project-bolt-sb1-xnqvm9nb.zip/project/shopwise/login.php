<?php
$page_title = 'Login';
include 'includes/header.php';

if (isLoggedIn()) redirect(BASE_URL . '/index.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string(db(), $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query(db(), $sql);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        setFlash('success', 'Welcome back, ' . $user['name'] . '!');
        redirect(BASE_URL . '/index.php');
    } else {
        $error = 'Invalid email or password.';
    }
}
?>

<div class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-header">
            <h3><i class="bi bi-box-arrow-in-right"></i> Welcome Back</h3>
            <p>Login to your ShopWise account</p>
        </div>
        <div class="auth-body">
            <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn-primary-custom w-100">Login</button>
            </form>
        </div>
        <div class="auth-footer">
            <p>Don't have an account? <a href="<?= BASE_URL ?>/register.php">Register here</a></p>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
