<?php
$page_title = 'About Us';
include 'includes/header.php';
?>

<div class="page-banner">
    <div class="container">
        <h1>About ShopWise</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li class="breadcrumb-item active">About Us</li>
            </ol>
        </nav>
    </div>
</div>

<section class="about-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <h2 style="font-weight:700;color:var(--dark);">Welcome to ShopWise</h2>
                <p class="lead" style="color:var(--gray);">Your ultimate online fashion destination.</p>
                <p>At ShopWise, we believe fashion is more than just clothing — it's a way to express who you are. Founded with a passion for quality and style, we bring you the latest trends from top brands at prices you'll love.</p>
                <p>From men's and women's fashion to kids' wear and matching couple outfits, our carefully curated collections cater to every style and occasion. We partner with leading brands like Nike, Adidas, Puma, Levis, and Zara to ensure you always get authentic, premium products.</p>
                <a href="<?= BASE_URL ?>/index.php" class="btn-primary-custom mt-3">Start Shopping</a>
            </div>
            <div class="col-lg-6 text-center">
                <div style="background:var(--grad-primary);border-radius:var(--radius-xl);padding:60px 30px;color:#fff;">
                    <i class="bi bi-bag-heart" style="font-size:6rem;opacity:0.3;"></i>
                    <h3 style="font-weight:700;margin-top:20px;">Fashion for Everyone</h3>
                    <p style="opacity:0.9;">Men • Women • Kids • Couples</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5" style="background:var(--gray-lighter);">
    <div class="container">
        <div class="section-title">
            <h2>Why Choose Us</h2>
            <p>We make online shopping effortless and enjoyable</p>
        </div>
        <div class="row g-4">
            <div class="col-lg-3 col-md-6">
                <div class="about-feature-card">
                    <div class="about-feature-icon" style="background:var(--grad-primary);"><i class="bi bi-award"></i></div>
                    <h5>Premium Quality</h5>
                    <p class="text-muted">Only authentic products from top brands you trust.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="about-feature-card">
                    <div class="about-feature-icon" style="background:var(--grad-secondary);"><i class="bi bi-tag"></i></div>
                    <h5>Best Prices</h5>
                    <p class="text-muted">Competitive pricing with regular sales and discounts.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="about-feature-card">
                    <div class="about-feature-icon" style="background:linear-gradient(135deg,#06D6A0,#2EC4B6);"><i class="bi bi-truck"></i></div>
                    <h5>Fast Delivery</h5>
                    <p class="text-muted">Quick and reliable shipping to your doorstep.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="about-feature-card">
                    <div class="about-feature-icon" style="background:linear-gradient(135deg,#EF476F,#FF6B35);"><i class="bi bi-headset"></i></div>
                    <h5>24/7 Support</h5>
                    <p class="text-muted">Our team is always here to help you.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="section-title">
            <h2>Our Stats</h2>
            <p>Numbers that speak for themselves</p>
        </div>
        <div class="row g-4 text-center">
            <div class="col-lg-3 col-md-6">
                <div style="background:#fff;padding:30px;border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);">
                    <h2 style="color:var(--primary);font-weight:700;font-size:2.5rem;">10K+</h2>
                    <p class="text-muted mb-0">Happy Customers</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div style="background:#fff;padding:30px;border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);">
                    <h2 style="color:var(--secondary);font-weight:700;font-size:2.5rem;">500+</h2>
                    <p class="text-muted mb-0">Products</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div style="background:#fff;padding:30px;border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);">
                    <h2 style="color:var(--info);font-weight:700;font-size:2.5rem;">50+</h2>
                    <p class="text-muted mb-0">Top Brands</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div style="background:#fff;padding:30px;border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);">
                    <h2 style="color:var(--error);font-weight:700;font-size:2.5rem;">99%</h2>
                    <p class="text-muted mb-0">Satisfaction Rate</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
