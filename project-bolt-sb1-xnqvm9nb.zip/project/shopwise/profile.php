<?php
$page_title = 'My Profile';
include 'includes/header.php';
requireLogin();

$user = getUserById($_SESSION['user_id']);
$order_count = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) as c FROM orders WHERE user_id = {$_SESSION['user_id']}"))['c'];
?>

<div class="page-banner">
    <div class="container">
        <h1>My Profile</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li class="breadcrumb-item active">Profile</li>
            </ol>
        </nav>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-lg-3 mb-4">
                <div class="profile-sidebar">
                    <div class="profile-avatar"><?= strtoupper(substr($user['name'], 0, 1)) ?></div>
                    <h5 class="text-center"><?= sanitize($user['name']) ?></h5>
                    <p class="text-center text-muted" style="font-size:0.85rem;"><?= sanitize($user['email']) ?></p>
                    <hr>
                    <div class="profile-menu">
                        <a href="<?= BASE_URL ?>/profile.php" class="active"><i class="bi bi-person"></i> My Profile</a>
                        <a href="<?= BASE_URL ?>/edit-profile.php"><i class="bi bi-pencil-square"></i> Edit Profile</a>
                        <a href="<?= BASE_URL ?>/orders.php"><i class="bi bi-bag-check"></i> My Orders</a>
                        <a href="<?= BASE_URL ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="col-lg-9">
                <div class="profile-content">
                    <h4 class="mb-4"><i class="bi bi-person-circle"></i> Profile Information</h4>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Full Name</label>
                            <p class="fw-bold"><?= sanitize($user['name']) ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Email</label>
                            <p class="fw-bold"><?= sanitize($user['email']) ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Phone</label>
                            <p class="fw-bold"><?= $user['phone'] ? sanitize($user['phone']) : 'Not provided' ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">City</label>
                            <p class="fw-bold"><?= $user['city'] ? sanitize($user['city']) : 'Not provided' ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Pincode</label>
                            <p class="fw-bold"><?= $user['pincode'] ? sanitize($user['pincode']) : 'Not provided' ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Member Since</label>
                            <p class="fw-bold"><?= date('d M Y', strtotime($user['created_at'])) ?></p>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label text-muted">Address</label>
                            <p class="fw-bold"><?= $user['address'] ? sanitize($user['address']) : 'Not provided' ?></p>
                        </div>
                    </div>
                    <div class="mt-3">
                        <a href="<?= BASE_URL ?>/edit-profile.php" class="btn-primary-custom"><i class="bi bi-pencil"></i> Edit Profile</a>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="row g-3 mt-3">
                    <div class="col-md-4">
                        <div style="background:var(--grad-primary);color:#fff;padding:20px;border-radius:var(--radius-lg);">
                            <i class="bi bi-bag-check" style="font-size:1.5rem;"></i>
                            <h4 class="mt-2 mb-0"><?= $order_count ?></h4>
                            <p class="mb-0" style="font-size:0.85rem;opacity:0.9;">Total Orders</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div style="background:var(--grad-secondary);color:#fff;padding:20px;border-radius:var(--radius-lg);">
                            <i class="bi bi-clock-history" style="font-size:1.5rem;"></i>
                            <?php $pending = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) as c FROM orders WHERE user_id = {$_SESSION['user_id']} AND status='Pending'"))['c']; ?>
                            <h4 class="mt-2 mb-0"><?= $pending ?></h4>
                            <p class="mb-0" style="font-size:0.85rem;opacity:0.9;">Pending Orders</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div style="background:linear-gradient(135deg,#06D6A0,#2EC4B6);color:#fff;padding:20px;border-radius:var(--radius-lg);">
                            <i class="bi bi-check2-circle" style="font-size:1.5rem;"></i>
                            <?php $delivered = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) as c FROM orders WHERE user_id = {$_SESSION['user_id']} AND status='Delivered'"))['c']; ?>
                            <h4 class="mt-2 mb-0"><?= $delivered ?></h4>
                            <p class="mb-0" style="font-size:0.85rem;opacity:0.9;">Delivered Orders</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
