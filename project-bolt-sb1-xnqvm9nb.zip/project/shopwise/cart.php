<?php
$page_title = 'Cart';
include 'includes/header.php';

// Handle add to cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $qty = isset($_GET['qty']) ? max(1, (int)$_GET['qty']) : 1;
    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
    if (isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id] += $qty;
    } else {
        $_SESSION['cart'][$id] = $qty;
    }
    setFlash('success', 'Product added to cart!');
    redirect(BASE_URL . '/cart.php');
}

// Handle remove
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    unset($_SESSION['cart'][$id]);
    setFlash('success', 'Item removed from cart.');
    redirect(BASE_URL . '/cart.php');
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_cart'])) {
    foreach ($_POST['qty'] as $id => $qty) {
        $qty = max(1, (int)$qty);
        $_SESSION['cart'][(int)$id] = $qty;
    }
    setFlash('success', 'Cart updated.');
    redirect(BASE_URL . '/cart.php');
}

// Handle clear
if (isset($_GET['action']) && $_GET['action'] == 'clear') {
    unset($_SESSION['cart']);
    setFlash('success', 'Cart cleared.');
    redirect(BASE_URL . '/cart.php');
}
?>

<div class="page-banner">
    <div class="container">
        <h1>Shopping Cart</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li class="breadcrumb-item active">Cart</li>
            </ol>
        </nav>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <?php if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])): ?>
        <div class="text-center py-5">
            <i class="bi bi-cart-x" style="font-size:5rem;color:var(--gray-light);"></i>
            <h3 class="mt-3">Your cart is empty</h3>
            <p class="text-muted">Add some products to get started.</p>
            <a href="<?= BASE_URL ?>/index.php" class="btn-primary-custom">Continue Shopping</a>
        </div>
        <?php else: ?>
        <div class="row">
            <div class="col-lg-8">
                <form method="POST" action="">
                    <?php foreach ($_SESSION['cart'] as $pid => $qty):
                        $product = getProductById($pid);
                        if (!$product) continue;
                        $price = $product['sale_price'] ?: $product['price'];
                    ?>
                    <div class="cart-item">
                        <img src="<?= getProductImage($product) ?>" class="cart-item-img" alt="<?= sanitize($product['name']) ?>">
                        <div style="flex-grow:1;">
                            <span class="product-brand"><?= sanitize($product['brand_name']) ?></span>
                            <h6 class="mb-1"><?= sanitize($product['name']) ?></h6>
                            <p class="text-muted mb-0" style="font-size:0.85rem;"><?= sanitize($product['category_name']) ?></p>
                            <div class="mt-2">
                                <span class="product-price"><?= formatPrice($price) ?></span>
                                <?php if ($product['sale_price']): ?>
                                <span class="product-old-price"><?= formatPrice($product['price']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="text-center">
                            <input type="number" name="qty[<?= $pid ?>]" value="<?= $qty ?>" min="1" class="form-control text-center mb-2" style="width:70px;">
                            <a href="<?= BASE_URL ?>/cart.php?action=remove&id=<?= $pid ?>" class="text-danger" style="font-size:0.85rem;"><i class="bi bi-trash"></i> Remove</a>
                        </div>
                        <div class="text-end">
                            <strong style="font-size:1.1rem;"><?= formatPrice($price * $qty) ?></strong>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <div class="d-flex justify-content-between mt-3">
                        <a href="<?= BASE_URL ?>/cart.php?action=clear" class="btn btn-outline-danger"><i class="bi bi-trash"></i> Clear Cart</a>
                        <button type="submit" name="update_cart" class="btn btn-outline-primary"><i class="bi bi-arrow-repeat"></i> Update Cart</button>
                    </div>
                </form>
            </div>
            <div class="col-lg-4">
                <div class="cart-summary">
                    <h5 class="mb-3">Order Summary</h5>
                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span><?= formatPrice(getCartTotal()) ?></span>
                    </div>
                    <div class="summary-row">
                        <span>Shipping</span>
                        <span class="text-success">Free</span>
                    </div>
                    <div class="summary-row">
                        <span>Total</span>
                        <span class="summary-total"><?= formatPrice(getCartTotal()) ?></span>
                    </div>
                    <?php if (isLoggedIn()): ?>
                    <a href="<?= BASE_URL ?>/checkout.php" class="btn-primary-custom w-100 text-center mt-3"><i class="bi bi-credit-card"></i> Proceed to Checkout</a>
                    <?php else: ?>
                    <a href="<?= BASE_URL ?>/login.php" class="btn-primary-custom w-100 text-center mt-3"><i class="bi bi-box-arrow-in-right"></i> Login to Checkout</a>
                    <?php endif; ?>
                    <a href="<?= BASE_URL ?>/index.php" class="btn btn-outline-secondary w-100 mt-2">Continue Shopping</a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
