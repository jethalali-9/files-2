<?php
$page_title = 'Checkout';
include 'includes/header.php';
requireLogin();

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    setFlash('error', 'Your cart is empty.');
    redirect(BASE_URL . '/cart.php');
}

$user = getUserById($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $address = mysqli_real_escape_string(db(), $_POST['address']);
    $city = mysqli_real_escape_string(db(), $_POST['city']);
    $pincode = mysqli_real_escape_string(db(), $_POST['pincode']);
    $phone = mysqli_real_escape_string(db(), $_POST['phone']);
    $payment_method = mysqli_real_escape_string(db(), $_POST['payment_method']);
    $total = getCartTotal();

    $sql = "INSERT INTO orders (user_id, total_amount, shipping_address, city, pincode, phone, payment_method) 
            VALUES ({$_SESSION['user_id']}, $total, '$address', '$city', '$pincode', '$phone', '$payment_method')";
    if (mysqli_query(db(), $sql)) {
        $order_id = mysqli_insert_id(db());
        foreach ($_SESSION['cart'] as $pid => $qty) {
            $product = getProductById($pid);
            if ($product) {
                $price = $product['sale_price'] ?: $product['price'];
                $pid = (int)$pid;
                $qty = (int)$qty;
                mysqli_query(db(), "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($order_id, $pid, $qty, $price)");
            }
        }
        unset($_SESSION['cart']);
        setFlash('success', 'Order placed successfully! Order #' . $order_id);
        redirect(BASE_URL . '/orders.php');
    } else {
        $error = 'Failed to place order. Try again.';
    }
}
?>

<div class="page-banner">
    <div class="container">
        <h1>Checkout</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/cart.php">Cart</a></li>
                <li class="breadcrumb-item active">Checkout</li>
            </ol>
        </nav>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="profile-content">
                    <h4 class="mb-4"><i class="bi bi-truck"></i> Shipping Details</h4>
                    <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" value="<?= sanitize($user['name']) ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Shipping Address</label>
                            <textarea name="address" class="form-control" rows="3" required placeholder="House no, Street, Area"><?= sanitize($user['address'] ?? '') ?></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">City</label>
                                <input type="text" name="city" class="form-control" required value="<?= sanitize($user['city'] ?? '') ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Pincode</label>
                                <input type="text" name="pincode" class="form-control" required value="<?= sanitize($user['pincode'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control" required value="<?= sanitize($user['phone'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Method</label>
                            <select name="payment_method" class="form-select">
                                <option value="Cash on Delivery">Cash on Delivery</option>
                                <option value="Credit Card">Credit Card</option>
                                <option value="Debit Card">Debit Card</option>
                                <option value="UPI">UPI Payment</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-primary-custom w-100"><i class="bi bi-check-circle"></i> Place Order</button>
                    </form>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="cart-summary">
                    <h5 class="mb-3">Your Order</h5>
                    <?php foreach ($_SESSION['cart'] as $pid => $qty):
                        $product = getProductById($pid);
                        if (!$product) continue;
                        $price = $product['sale_price'] ?: $product['price'];
                    ?>
                    <div class="d-flex gap-2 mb-2 pb-2 border-bottom">
                        <img src="<?= getProductImage($product) ?>" style="width:50px;height:50px;border-radius:8px;object-fit:cover;">
                        <div style="flex-grow:1;">
                            <small><?= sanitize($product['name']) ?></small><br>
                            <span class="text-muted" style="font-size:0.8rem;"><?= $qty ?> x <?= formatPrice($price) ?></span>
                        </div>
                        <strong><?= formatPrice($price * $qty) ?></strong>
                    </div>
                    <?php endforeach; ?>
                    <div class="summary-row mt-3">
                        <span>Subtotal</span><span><?= formatPrice(getCartTotal()) ?></span>
                    </div>
                    <div class="summary-row">
                        <span>Shipping</span><span class="text-success">Free</span>
                    </div>
                    <div class="summary-row">
                        <span>Total</span><span class="summary-total"><?= formatPrice(getCartTotal()) ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
