<!-- Footer -->
<footer class="footer-main">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-3 col-md-6">
                <h5 class="footer-title">Shop<span class="brand-accent">Wise</span></h5>
                <p class="footer-text">Your one-stop online fashion destination for the latest trends in clothing, footwear, and accessories.</p>
                <div class="social-icons">
                    <a href="#"><i class="bi bi-facebook"></i></a>
                    <a href="#"><i class="bi bi-instagram"></i></a>
                    <a href="#"><i class="bi bi-twitter"></i></a>
                    <a href="#"><i class="bi bi-youtube"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-6">
                <h6 class="footer-heading">Quick Links</h6>
                <ul class="footer-links">
                    <li><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                    <li><a href="<?= BASE_URL ?>/about.php">About Us</a></li>
                    <li><a href="<?= BASE_URL ?>/login.php">Login</a></li>
                    <li><a href="<?= BASE_URL ?>/register.php">Register</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6">
                <h6 class="footer-heading">Categories</h6>
                <ul class="footer-links">
                    <?php $cats = getCategories(); while ($c = mysqli_fetch_assoc($cats)): ?>
                    <li><a href="<?= BASE_URL ?>/category.php?id=<?= $c['id'] ?>"><?= sanitize($c['name']) ?></a></li>
                    <?php endwhile; ?>
                </ul>
            </div>
            <div class="col-lg-4 col-md-6">
                <h6 class="footer-heading">Newsletter</h6>
                <p class="footer-text">Subscribe to get updates on new arrivals and special offers.</p>
                <form class="newsletter-form">
                    <input type="email" class="form-control" placeholder="Your email address">
                    <button type="submit" class="btn btn-subscribe">Subscribe</button>
                </form>
            </div>
        </div>
        <hr class="footer-divider">
        <div class="footer-bottom">
            <p>&copy; <?= date('Y') ?> ShopWise. All rights reserved.</p>
            <div class="payment-icons">
                <i class="bi bi-credit-card"></i>
                <i class="bi bi-paypal"></i>
                <i class="bi bi-wallet2"></i>
                <i class="bi bi-cash"></i>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
