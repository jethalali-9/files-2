<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

// Build brand submenu and category submenu
$brands_list = getBrands();
$categories_list = getCategories();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? $page_title . ' - ShopWise' : 'ShopWise - Online Fashion Store' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
<!-- Top Bar -->
<div class="topbar">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="topbar-left">
            <i class="bi bi-truck"></i> Free shipping on orders above ₹999
        </div>
        <div class="topbar-right">
            <?php if (isLoggedIn()): ?>
                <a href="<?= BASE_URL ?>/profile.php"><i class="bi bi-person"></i> <?= sanitize($_SESSION['user_name']) ?></a>
                <a href="<?= BASE_URL ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
            <?php else: ?>
                <a href="<?= BASE_URL ?>/login.php"><i class="bi bi-box-arrow-in-right"></i> Login</a>
                <a href="<?= BASE_URL ?>/register.php"><i class="bi bi-person-plus"></i> Register</a>
            <?php endif; ?>
            <a href="<?= ADMIN_URL ?>/login.php" class="admin-link"><i class="bi bi-shield-lock"></i> Admin</a>
        </div>
    </div>
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-main shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?= BASE_URL ?>/index.php">
            <span class="brand-logo">Shop<span class="brand-accent">Wise</span></span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/index.php">Home</a></li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Brand</a>
                    <ul class="dropdown-menu dropdown-menu-brand">
                        <?php while ($b = mysqli_fetch_assoc($brands_list)): ?>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/brand.php?id=<?= $b['id'] ?>"><?= sanitize($b['name']) ?></a></li>
                        <?php endwhile; ?>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Category</a>
                    <ul class="dropdown-menu dropdown-menu-category">
                        <?php while ($c = mysqli_fetch_assoc($categories_list)): ?>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/category.php?id=<?= $c['id'] ?>"><?= sanitize($c['name']) ?></a></li>
                        <?php endwhile; ?>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/about.php">About Us</a></li>
            </ul>
            <div class="nav-actions">
                <?php if (isLoggedIn()): ?>
                    <a href="<?= BASE_URL ?>/orders.php" class="btn-nav-icon" title="My Orders"><i class="bi bi-bag-check"></i></a>
                    <a href="<?= BASE_URL ?>/profile.php" class="btn-nav-icon" title="Profile"><i class="bi bi-person-circle"></i></a>
                <?php endif; ?>
                <a href="<?= BASE_URL ?>/cart.php" class="cart-icon" title="Cart">
                    <i class="bi bi-cart3"></i>
                    <span class="cart-badge"><?= countCartItems() ?></span>
                </a>
            </div>
        </div>
    </div>
</nav>

<?php
$flash_success = flash('success');
$flash_error = flash('error');
if ($flash_success): ?>
<div class="container mt-3"><div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle"></i> <?= sanitize($flash_success) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div></div>
<?php endif; ?>
<?php if ($flash_error): ?>
<div class="container mt-3"><div class="alert alert-danger alert-dismissible fade show"><i class="bi bi-exclamation-circle"></i> <?= sanitize($flash_error) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div></div>
<?php endif; ?>
