<?php
// Helper functions

function redirect($url) {
    header("Location: $url");
    exit();
}

function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['admin_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        redirect(BASE_URL . '/login.php');
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        redirect(ADMIN_URL . '/login.php');
    }
}

function formatPrice($price) {
    return '₹' . number_format($price, 0);
}

function getBrands() {
    $sql = "SELECT * FROM brands ORDER BY name";
    return mysqli_query(db(), $sql);
}

function getCategories() {
    $sql = "SELECT * FROM categories ORDER BY name";
    return mysqli_query(db(), $sql);
}

function getProducts($where = "") {
    $sql = "SELECT p.*, b.name AS brand_name, c.name AS category_name 
            FROM products p 
            JOIN brands b ON p.brand_id = b.id 
            JOIN categories c ON p.category_id = c.id 
            WHERE p.status = 'active' $where 
            ORDER BY p.created_at DESC";
    return mysqli_query(db(), $sql);
}

function getProductById($id) {
    $id = (int)$id;
    $sql = "SELECT p.*, b.name AS brand_name, c.name AS category_name 
            FROM products p 
            JOIN brands b ON p.brand_id = b.id 
            JOIN categories c ON p.category_id = c.id 
            WHERE p.id = $id";
    $result = mysqli_query(db(), $sql);
    return mysqli_fetch_assoc($result);
}

function getBrandById($id) {
    $id = (int)$id;
    $sql = "SELECT * FROM brands WHERE id = $id";
    $result = mysqli_query(db(), $sql);
    return mysqli_fetch_assoc($result);
}

function getCategoryById($id) {
    $id = (int)$id;
    $sql = "SELECT * FROM categories WHERE id = $id";
    $result = mysqli_query(db(), $sql);
    return mysqli_fetch_assoc($result);
}

function getProductImage($product) {
    if (!empty($product['image']) && file_exists(__DIR__ . '/../uploads/' . $product['image'])) {
        return BASE_URL . '/uploads/' . $product['image'];
    }
    return 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=600';
}

function countCartItems() {
    if (!isset($_SESSION['cart'])) return 0;
    return array_sum($_SESSION['cart']);
}

function getCartTotal() {
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) return 0;
    $total = 0;
    foreach ($_SESSION['cart'] as $pid => $qty) {
        $product = getProductById($pid);
        if ($product) {
            $price = $product['sale_price'] ? $product['sale_price'] : $product['price'];
            $total += $price * $qty;
        }
    }
    return $total;
}

function flash($key) {
    if (isset($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

function setFlash($key, $msg) {
    $_SESSION['flash'][$key] = $msg;
}

function getUserById($id) {
    $id = (int)$id;
    $sql = "SELECT * FROM users WHERE id = $id";
    $result = mysqli_query(db(), $sql);
    return mysqli_fetch_assoc($result);
}
