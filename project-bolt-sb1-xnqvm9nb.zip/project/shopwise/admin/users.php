<?php
$page_title = 'Manage Users';
$active_page = 'users';
include 'includes/header.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query(db(), "DELETE FROM users WHERE id = $id");
    setFlash('success', 'User deleted.');
    redirect(ADMIN_URL . '/users.php');
}

$users = mysqli_query(db(), "SELECT u.*, (SELECT COUNT(*) FROM orders WHERE user_id = u.id) as order_count FROM users u ORDER BY u.id DESC");
?>

<h4 class="mb-4"><i class="bi bi-people"></i> Manage Users</h4>

<div class="admin-table">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>City</th>
                    <th>Orders</th>
                    <th>Joined</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($u = mysqli_fetch_assoc($users)): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><strong><?= sanitize($u['name']) ?></strong></td>
                    <td><?= sanitize($u['email']) ?></td>
                    <td><?= sanitize($u['phone'] ?? '-') ?></td>
                    <td><?= sanitize($u['city'] ?? '-') ?></td>
                    <td><?= $u['order_count'] ?></td>
                    <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <a href="<?= ADMIN_URL ?>/users.php?delete=<?= $u['id'] ?>" class="btn-admin-delete" onclick="return confirm('Delete this user? All their orders will also be deleted.')"><i class="bi bi-trash"></i></a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
