<?php
$page_title = 'Manage Orders';
$active_page = 'orders';
include 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_id = (int)$_POST['order_id'];
    $status = mysqli_real_escape_string(db(), $_POST['status']);
    mysqli_query(db(), "UPDATE orders SET status='$status' WHERE id=$order_id");
    setFlash('success', 'Order status updated.');
    redirect(ADMIN_URL . '/orders.php');
}

$orders = mysqli_query(db(), "SELECT o.*, u.name AS user_name, u.email AS user_email FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC");
?>

<h4 class="mb-4"><i class="bi bi-bag-check"></i> Manage Orders</h4>

<div class="admin-table">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th>City</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($o = mysqli_fetch_assoc($orders)): ?>
                <tr>
                    <td><strong>#<?= $o['id'] ?></strong></td>
                    <td><?= sanitize($o['user_name']) ?><br><small class="text-muted"><?= sanitize($o['user_email']) ?></small></td>
                    <td><?= formatPrice($o['total_amount']) ?></td>
                    <td><span class="status-badge status-<?= $o['status'] ?>"><?= $o['status'] ?></span></td>
                    <td><?= sanitize($o['payment_method']) ?></td>
                    <td><?= sanitize($o['city']) ?></td>
                    <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                    <td>
                        <button class="btn-admin-edit" data-bs-toggle="modal" data-bs-target="#statusModal" onclick="setStatus(<?= $o['id'] ?>, '<?= $o['status'] ?>')"><i class="bi bi-pencil"></i> Update</button>
                        <button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#viewModal" onclick="loadOrder(<?= $o['id'] ?>)"><i class="bi bi-eye"></i> View</button>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php if (mysqli_num_rows($orders) == 0): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">No orders yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Status Update Modal -->
<div class="modal fade" id="statusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background:var(--grad-primary);color:#fff;">
                <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Update Order Status</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="order_id" id="status_order_id">
                    <label class="form-label">Order Status</label>
                    <select name="status" id="status_select" class="form-select">
                        <option value="Pending">Pending</option>
                        <option value="Processing">Processing</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-admin-primary"><i class="bi bi-check-circle"></i> Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Order Modal -->
<div class="modal fade" id="viewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background:var(--grad-secondary);color:#fff;">
                <h5 class="modal-title"><i class="bi bi-eye"></i> Order Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="orderDetailsBody">
                <p class="text-center text-muted">Loading...</p>
            </div>
        </div>
    </div>
</div>

<script>
function setStatus(id, status) {
    document.getElementById('status_order_id').value = id;
    document.getElementById('status_select').value = status;
}
function loadOrder(id) {
    fetch('order-details.php?id=' + id)
        .then(r => r.text())
        .then(html => {
            document.getElementById('orderDetailsBody').innerHTML = html;
        })
        .catch(() => {
            document.getElementById('orderDetailsBody').innerHTML = '<p class="text-danger">Failed to load order details.</p>';
        });
}
</script>

<?php include 'includes/footer.php'; ?>
