<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    exit('Unauthorized');
}

$id = (int)$_GET['id'];
$order = mysqli_fetch_assoc(mysqli_query(db(), "SELECT o.*, u.name AS user_name, u.email AS user_email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = $id"));
if (!$order) exit('Order not found');

$items = mysqli_query(db(), "SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = $id");
?>
<div class="mb-3">
    <strong>Order #<?= $order['id'] ?></strong><br>
    <small class="text-muted"><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></small>
</div>
<div class="row mb-3">
    <div class="col-md-6">
        <strong>Customer:</strong><br>
        <?= sanitize($order['user_name']) ?><br>
        <small class="text-muted"><?= sanitize($order['user_email']) ?></small>
    </div>
    <div class="col-md-6">
        <strong>Shipping Address:</strong><br>
        <?= sanitize($order['shipping_address']) ?><br>
        <small class="text-muted"><?= sanitize($order['city']) ?> - <?= sanitize($order['pincode']) ?></small><br>
        <small class="text-muted">Phone: <?= sanitize($order['phone']) ?></small>
    </div>
</div>
<table class="table table-sm">
    <thead>
        <tr style="background:var(--gray-lighter);">
            <th>Product</th>
            <th class="text-center">Qty</th>
            <th class="text-end">Price</th>
            <th class="text-end">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($item = mysqli_fetch_assoc($items)): ?>
        <tr>
            <td><?= sanitize($item['name']) ?></td>
            <td class="text-center"><?= $item['quantity'] ?></td>
            <td class="text-end"><?= formatPrice($item['price']) ?></td>
            <td class="text-end"><?= formatPrice($item['price'] * $item['quantity']) ?></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3" class="text-end"><strong>Grand Total:</strong></td>
            <td class="text-end"><strong style="color:var(--primary);font-size:1.1rem;"><?= formatPrice($order['total_amount']) ?></strong></td>
        </tr>
    </tfoot>
</table>
<div class="d-flex justify-content-between">
    <span><strong>Payment:</strong> <?= sanitize($order['payment_method']) ?></span>
    <span><strong>Status:</strong> <span class="status-badge status-<?= $order['status'] ?>"><?= $order['status'] ?></span></span>
</div>
