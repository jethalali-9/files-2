<?php
// Admin header - included on all admin pages
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($_SESSION['admin_id'])) {
    redirect(ADMIN_URL . '/login.php');
}

$admin_name = $_SESSION['admin_name'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? $page_title . ' - Admin' : 'ShopWise Admin' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/css/admin.css" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <!-- Sidebar -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="sidebar-header">
            <span class="brand-logo">Shop<span class="brand-accent">Wise</span></span>
            <small class="text-muted">Admin Panel</small>
        </div>
        <nav class="sidebar-nav">
            <a href="<?= ADMIN_URL ?>/dashboard.php" class="<?= ($active_page ?? '') == 'dashboard' ? 'active' : '' ?>"><i class="bi bi-speedometer2"></i> Dashboard</a>
            <a href="<?= ADMIN_URL ?>/products.php" class="<?= ($active_page ?? '') == 'products' ? 'active' : '' ?>"><i class="bi bi-box-seam"></i> Products</a>
            <a href="<?= ADMIN_URL ?>/brands.php" class="<?= ($active_page ?? '') == 'brands' ? 'active' : '' ?>"><i class="bi bi-bookmark-star"></i> Brands</a>
            <a href="<?= ADMIN_URL ?>/categories.php" class="<?= ($active_page ?? '') == 'categories' ? 'active' : '' ?>"><i class="bi bi-tags"></i> Categories</a>
            <a href="<?= ADMIN_URL ?>/orders.php" class="<?= ($active_page ?? '') == 'orders' ? 'active' : '' ?>"><i class="bi bi-bag-check"></i> Orders</a>
            <a href="<?= ADMIN_URL ?>/users.php" class="<?= ($active_page ?? '') == 'users' ? 'active' : '' ?>"><i class="bi bi-people"></i> Users</a>
            <a href="<?= BASE_URL ?>/index.php" target="_blank"><i class="bi bi-shop"></i> View Store</a>
            <a href="<?= ADMIN_URL ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </nav>
    </aside>

    <!-- Main Content -->
    <div class="admin-main">
        <header class="admin-topbar">
            <button class="btn-toggle" onclick="document.getElementById('sidebar').classList.toggle('open')"><i class="bi bi-list"></i></button>
            <h4><?= $page_title ?? 'Dashboard' ?></h4>
            <div class="admin-user">
                <i class="bi bi-person-circle"></i> <?= sanitize($admin_name) ?>
            </div>
        </header>
        <div class="admin-content">
            <?php
            $flash_success = flash('success');
            $flash_error = flash('error');
            if ($flash_success): ?>
            <div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle"></i> <?= sanitize($flash_success) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
            <?php endif; ?>
            <?php if ($flash_error): ?>
            <div class="alert alert-danger alert-dismissible fade show"><i class="bi bi-exclamation-circle"></i> <?= sanitize($flash_error) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
            <?php endif; ?>
