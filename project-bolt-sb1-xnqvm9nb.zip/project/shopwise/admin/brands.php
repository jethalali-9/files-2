<?php
$page_title = 'Manage Brands';
$active_page = 'brands';
include 'includes/header.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query(db(), "DELETE FROM brands WHERE id = $id");
    setFlash('success', 'Brand deleted.');
    redirect(ADMIN_URL . '/brands.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string(db(), $_POST['name']);
    $description = mysqli_real_escape_string(db(), $_POST['description']);
    $edit_id = isset($_POST['edit_id']) ? (int)$_POST['edit_id'] : 0;

    if ($edit_id) {
        mysqli_query(db(), "UPDATE brands SET name='$name', description='$description' WHERE id=$edit_id");
        setFlash('success', 'Brand updated.');
    } else {
        mysqli_query(db(), "INSERT INTO brands (name, description) VALUES ('$name', '$description')");
        setFlash('success', 'Brand added.');
    }
    redirect(ADMIN_URL . '/brands.php');
}

$brands = getBrands();
$edit_brand = null;
if (isset($_GET['edit'])) {
    $edit_brand = getBrandById((int)$_GET['edit']);
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0"><i class="bi bi-bookmark-star"></i> Manage Brands</h4>
    <button class="btn-admin-primary" data-bs-toggle="modal" data-bs-target="#brandModal" onclick="resetBrand()">
        <i class="bi bi-plus-circle"></i> Add Brand
    </button>
</div>

<div class="admin-table">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr><th>ID</th><th>Name</th><th>Description</th><th>Products</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php while ($b = mysqli_fetch_assoc($brands)):
                    $count = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) as c FROM products WHERE brand_id={$b['id']}"))['c'];
                ?>
                <tr>
                    <td><?= $b['id'] ?></td>
                    <td><strong><?= sanitize($b['name']) ?></strong></td>
                    <td><?= sanitize(substr($b['description'] ?? '', 0, 60)) ?></td>
                    <td><?= $count ?></td>
                    <td>
                        <a href="<?= ADMIN_URL ?>/brands.php?edit=<?= $b['id'] ?>" class="btn-admin-edit" onclick="loadBrand(<?= $b['id'] ?>, '<?= addslashes($b['name']) ?>', '<?= addslashes($b['description'] ?? '') ?>')"><i class="bi bi-pencil"></i></a>
                        <a href="<?= ADMIN_URL ?>/brands.php?delete=<?= $b['id'] ?>" class="btn-admin-delete" onclick="return confirm('Delete this brand? All its products will also be deleted.')"><i class="bi bi-trash"></i></a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="brandModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background:var(--grad-primary);color:#fff;">
                <h5 class="modal-title" id="brandModalTitle"><i class="bi bi-bookmark-star"></i> Add Brand</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="brand_edit_id">
                    <div class="mb-3">
                        <label class="form-label">Brand Name</label>
                        <input type="text" name="name" id="brand_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" id="brand_desc" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-admin-primary"><i class="bi bi-check-circle"></i> Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($edit_brand): ?>
<script>
window.onload = function() {
    loadBrand(<?= $edit_brand['id'] ?>, '<?= addslashes($edit_brand['name']) ?>', '<?= addslashes($edit_brand['description'] ?? '') ?>');
};
</script>
<?php endif; ?>

<script>
function resetBrand() {
    document.getElementById('brand_edit_id').value = '';
    document.getElementById('brandModalTitle').innerText = 'Add Brand';
    document.querySelector('#brandModal form').reset();
}
function loadBrand(id, name, desc) {
    document.getElementById('brand_edit_id').value = id;
    document.getElementById('brand_name').value = name;
    document.getElementById('brand_desc').value = desc;
    document.getElementById('brandModalTitle').innerText = 'Edit Brand';
    new bootstrap.Modal(document.getElementById('brandModal')).show();
}
</script>

<?php include 'includes/footer.php'; ?>
