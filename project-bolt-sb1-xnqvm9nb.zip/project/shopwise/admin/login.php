<?php
// Admin auth check - start session and verify
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (isset($_SESSION['admin_id'])) {
    redirect(ADMIN_URL . '/dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string(db(), $_POST['email']);
    $password = $_POST['password'];
    $sql = "SELECT * FROM admins WHERE email = '$email'";
    $result = mysqli_query(db(), $sql);
    $admin = mysqli_fetch_assoc($result);
    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        redirect(ADMIN_URL . '/dashboard.php');
    } else {
        $error = 'Invalid credentials. Try: admin@shopwise.com / admin123';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - ShopWise</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">
    <style>
        body { background: var(--grad-dark); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="auth-header" style="background:var(--grad-dark);">
            <h3><i class="bi bi-shield-lock"></i> Admin Panel</h3>
            <p>Login to manage ShopWise</p>
        </div>
        <div class="auth-body">
            <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn-primary-custom w-100">Login</button>
            </form>
        </div>
        <div class="auth-footer">
            <p><a href="<?= BASE_URL ?>/index.php">Back to Store</a></p>
        </div>
    </div>
</body>
</html>
