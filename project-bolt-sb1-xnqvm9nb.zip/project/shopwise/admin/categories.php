<?php
$page_title = 'Manage Categories';
$active_page = 'categories';
include 'includes/header.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query(db(), "DELETE FROM categories WHERE id = $id");
    setFlash('success', 'Category deleted.');
    redirect(ADMIN_URL . '/categories.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string(db(), $_POST['name']);
    $description = mysqli_real_escape_string(db(), $_POST['description']);
    $edit_id = isset($_POST['edit_id']) ? (int)$_POST['edit_id'] : 0;

    if ($edit_id) {
        mysqli_query(db(), "UPDATE categories SET name='$name', description='$description' WHERE id=$edit_id");
        setFlash('success', 'Category updated.');
    } else {
        mysqli_query(db(), "INSERT INTO categories (name, description) VALUES ('$name', '$description')");
        setFlash('success', 'Category added.');
    }
    redirect(ADMIN_URL . '/categories.php');
}

$categories = getCategories();
$edit_cat = null;
if (isset($_GET['edit'])) {
    $edit_cat = getCategoryById((int)$_GET['edit']);
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0"><i class="bi bi-tags"></i> Manage Categories</h4>
    <button class="btn-admin-primary" data-bs-toggle="modal" data-bs-target="#catModal" onclick="resetCat()">
        <i class="bi bi-plus-circle"></i> Add Category
    </button>
</div>

<div class="admin-table">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr><th>ID</th><th>Name</th><th>Description</th><th>Products</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php while ($c = mysqli_fetch_assoc($categories)):
                    $count = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) as c FROM products WHERE category_id={$c['id']}"))['c'];
                ?>
                <tr>
                    <td><?= $c['id'] ?></td>
                    <td><strong><?= sanitize($c['name']) ?></strong></td>
                    <td><?= sanitize(substr($c['description'] ?? '', 0, 60)) ?></td>
                    <td><?= $count ?></td>
                    <td>
                        <a href="<?= ADMIN_URL ?>/categories.php?edit=<?= $c['id'] ?>" class="btn-admin-edit" onclick="loadCat(<?= $c['id'] ?>, '<?= addslashes($c['name']) ?>', '<?= addslashes($c['description'] ?? '') ?>')"><i class="bi bi-pencil"></i></a>
                        <a href="<?= ADMIN_URL ?>/categories.php?delete=<?= $c['id'] ?>" class="btn-admin-delete" onclick="return confirm('Delete this category? All its products will also be deleted.')"><i class="bi bi-trash"></i></a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="catModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background:var(--grad-secondary);color:#fff;">
                <h5 class="modal-title" id="catModalTitle"><i class="bi bi-tags"></i> Add Category</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="cat_edit_id">
                    <div class="mb-3">
                        <label class="form-label">Category Name</label>
                        <input type="text" name="name" id="cat_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" id="cat_desc" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-admin-primary"><i class="bi bi-check-circle"></i> Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($edit_cat): ?>
<script>
window.onload = function() {
    loadCat(<?= $edit_cat['id'] ?>, '<?= addslashes($edit_cat['name']) ?>', '<?= addslashes($edit_cat['description'] ?? '') ?>');
};
</script>
<?php endif; ?>

<script>
function resetCat() {
    document.getElementById('cat_edit_id').value = '';
    document.getElementById('catModalTitle').innerText = 'Add Category';
    document.querySelector('#catModal form').reset();
}
function loadCat(id, name, desc) {
    document.getElementById('cat_edit_id').value = id;
    document.getElementById('cat_name').value = name;
    document.getElementById('cat_desc').value = desc;
    document.getElementById('catModalTitle').innerText = 'Edit Category';
    new bootstrap.Modal(document.getElementById('catModal')).show();
}
</script>

<?php include 'includes/footer.php'; ?>
