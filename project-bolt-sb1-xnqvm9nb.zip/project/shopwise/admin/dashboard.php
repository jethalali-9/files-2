<?php
$page_title = 'Dashboard';
$active_page = 'dashboard';
include 'includes/header.php';

$total_products = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) as c FROM products"))['c'];
$total_orders = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) as c FROM orders"))['c'];
$total_users = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) as c FROM users"))['c'];
$total_revenue = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COALESCE(SUM(total_amount),0) as s FROM orders WHERE status != 'Cancelled'"))['s'];
$pending_orders = mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) as c FROM orders WHERE status='Pending'"))['c'];

$recent_orders = mysqli_query(db(), "SELECT o.*, u.name AS user_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5");
?>

<!-- Stat Cards -->
<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6">
        <div class="stat-card">
            <div class="stat-icon" style="background:var(--grad-primary);"><i class="bi bi-currency-rupee"></i></div>
            <h3><?= formatPrice($total_revenue) ?></h3>
            <p>Total Revenue</p>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card">
            <div class="stat-icon" style="background:var(--grad-secondary);"><i class="bi bi-bag-check"></i></div>
            <h3><?= $total_orders ?></h3>
            <p>Total Orders</p>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card">
            <div class="stat-icon" style="background:linear-gradient(135deg,#06D6A0,#2EC4B6);"><i class="bi bi-box-seam"></i></div>
            <h3><?= $total_products ?></h3>
            <p>Products</p>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card">
            <div class="stat-icon" style="background:linear-gradient(135deg,#EF476F,#FF6B35);"><i class="bi bi-people"></i></div>
            <h3><?= $total_users ?></h3>
            <p>Registered Users</p>
        </div>
    </div>
</div>

<!-- Pending Orders Alert -->
<?php if ($pending_orders > 0): ?>
<div class="alert alert-warning d-flex align-items-center">
    <i class="bi bi-exclamation-triangle me-2" style="font-size:1.3rem;"></i>
    <div>You have <strong><?= $pending_orders ?></strong> pending order(s) that need attention.</div>
    <a href="<?= ADMIN_URL ?>/orders.php" class="btn btn-sm btn-warning ms-auto">View Orders</a>
</div>
<?php endif; ?>

<!-- Recent Orders -->
<div class="admin-table mt-4">
    <div class="p-3 d-flex justify-content-between align-items-center" style="border-bottom:2px solid var(--gray-light);">
        <h5 class="mb-0"><i class="bi bi-clock-history"></i> Recent Orders</h5>
        <a href="<?= ADMIN_URL ?>/orders.php" class="btn btn-sm btn-outline-primary">View All</a>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($o = mysqli_fetch_assoc($recent_orders)): ?>
                <tr>
                    <td>#<?= $o['id'] ?></td>
                    <td><?= sanitize($o['user_name']) ?></td>
                    <td><?= formatPrice($o['total_amount']) ?></td>
                    <td><span class="status-badge status-<?= $o['status'] ?>"><?= $o['status'] ?></span></td>
                    <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                </tr>
                <?php endwhile; ?>
                <?php if (mysqli_num_rows($recent_orders) == 0): ?>
                <tr><td colspan="5" class="text-center text-muted py-4">No orders yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
