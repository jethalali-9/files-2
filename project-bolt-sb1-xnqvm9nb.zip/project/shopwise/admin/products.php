<?php
$page_title = 'Manage Products';
$active_page = 'products';
include 'includes/header.php';

// Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query(db(), "DELETE FROM products WHERE id = $id");
    setFlash('success', 'Product deleted.');
    redirect(ADMIN_URL . '/products.php');
}

// Add/Edit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string(db(), $_POST['name']);
    $description = mysqli_real_escape_string(db(), $_POST['description']);
    $price = (float)$_POST['price'];
    $sale_price = !empty($_POST['sale_price']) ? (float)$_POST['sale_price'] : 'NULL';
    $brand_id = (int)$_POST['brand_id'];
    $category_id = (int)$_POST['category_id'];
    $stock = (int)$_POST['stock'];
    $featured = isset($_POST['featured']) ? 1 : 0;
    $status = $_POST['status'];
    $image = '';

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], __DIR__ . '/../uploads/' . $image);
    }

    $edit_id = isset($_POST['edit_id']) ? (int)$_POST['edit_id'] : 0;
    if ($edit_id) {
        $img_sql = $image ? ", image='$image'" : "";
        $sale_sql = $sale_price === 'NULL' ? "sale_price=NULL" : "sale_price=$sale_price";
        $sql = "UPDATE products SET name='$name', description='$description', price=$price, $sale_sql, brand_id=$brand_id, category_id=$category_id, stock=$stock, featured=$featured, status='$status' $img_sql WHERE id=$edit_id";
    } else {
        $sale_sql = $sale_price === 'NULL' ? "NULL" : "$sale_price";
        $sql = "INSERT INTO products (name, description, price, sale_price, image, brand_id, category_id, stock, featured, status) 
                VALUES ('$name', '$description', $price, $sale_sql, '$image', $brand_id, $category_id, $stock, $featured, '$status')";
    }

    if (mysqli_query(db(), $sql)) {
        setFlash('success', $edit_id ? 'Product updated.' : 'Product added.');
        redirect(ADMIN_URL . '/products.php');
    } else {
        setFlash('error', 'Error: ' . mysqli_error(db()));
    }
}

$products = mysqli_query(db(), "SELECT p.*, b.name AS brand_name, c.name AS category_name FROM products p JOIN brands b ON p.brand_id = b.id JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC");
$brands = getBrands();
$categories = getCategories();

$edit_product = null;
if (isset($_GET['edit'])) {
    $edit_product = getProductById((int)$_GET['edit']);
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0"><i class="bi bi-box-seam"></i> Manage Products</h4>
    <button class="btn-admin-primary" data-bs-toggle="modal" data-bs-target="#productModal" onclick="resetForm()">
        <i class="bi bi-plus-circle"></i> Add Product
    </button>
</div>

<div class="admin-table">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Brand</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Sale</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($p = mysqli_fetch_assoc($products)): ?>
                <tr>
                    <td><?= $p['id'] ?></td>
                    <td><img src="<?= getProductImage($p) ?>" style="width:45px;height:45px;border-radius:8px;object-fit:cover;"></td>
                    <td><?= sanitize($p['name']) ?></td>
                    <td><?= sanitize($p['brand_name']) ?></td>
                    <td><?= sanitize($p['category_name']) ?></td>
                    <td><?= formatPrice($p['price']) ?></td>
                    <td><?= $p['sale_price'] ? formatPrice($p['sale_price']) : '-' ?></td>
                    <td><?= $p['stock'] ?></td>
                    <td><span class="badge bg-<?= $p['status'] == 'active' ? 'success' : 'secondary' ?>"><?= $p['status'] ?></span></td>
                    <td>
                        <a href="<?= ADMIN_URL ?>/products.php?edit=<?= $p['id'] ?>" class="btn-admin-edit" onclick="loadEdit(<?= $p['id'] ?>, '<?= sanitize($p['name']) ?>', '<?= sanitize($p['description'] ?? '') ?>', <?= $p['price'] ?>, <?= $p['sale_price'] ?: 'null' ?>, <?= $p['brand_id'] ?>, <?= $p['category_id'] ?>, <?= $p['stock'] ?>, <?= $p['featured'] ?>, '<?= $p['status'] ?>')" class="btn-admin-edit"><i class="bi bi-pencil"></i></a>
                        <a href="<?= ADMIN_URL ?>/products.php?delete=<?= $p['id'] ?>" class="btn-admin-delete" onclick="return confirm('Delete this product?')"><i class="bi bi-trash"></i></a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Product Modal -->
<div class="modal fade" id="productModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background:var(--grad-primary);color:#fff;">
                <h5 class="modal-title" id="modalTitle"><i class="bi bi-box-seam"></i> Add Product</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" name="name" id="name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Image</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" id="description" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Price (₹)</label>
                            <input type="number" name="price" id="price" class="form-control" step="0.01" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Sale Price (₹)</label>
                            <input type="number" name="sale_price" id="sale_price" class="form-control" step="0.01">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Stock</label>
                            <input type="number" name="stock" id="stock" class="form-control" value="0">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Brand</label>
                            <select name="brand_id" id="brand_id" class="form-select" required>
                                <?php mysqli_data_seek($brands, 0); while ($b = mysqli_fetch_assoc($brands)): ?>
                                <option value="<?= $b['id'] ?>"><?= sanitize($b['name']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Category</label>
                            <select name="category_id" id="category_id" class="form-select" required>
                                <?php mysqli_data_seek($categories, 0); while ($c = mysqli_fetch_assoc($categories)): ?>
                                <option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" id="status" class="form-select">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3 d-flex align-items-end">
                            <div class="form-check">
                                <input type="checkbox" name="featured" id="featured" class="form-check-input">
                                <label class="form-check-label">Featured Product</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-admin-primary"><i class="bi bi-check-circle"></i> Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($edit_product): ?>
<script>
window.onload = function() {
    loadEdit(<?= $edit_product['id'] ?>, '<?= addslashes($edit_product['name']) ?>', '<?= addslashes($edit_product['description'] ?? '') ?>', <?= $edit_product['price'] ?>, <?= $edit_product['sale_price'] ?: 'null' ?>, <?= $edit_product['brand_id'] ?>, <?= $edit_product['category_id'] ?>, <?= $edit_product['stock'] ?>, <?= $edit_product['featured'] ?>, '<?= $edit_product['status'] ?>');
};
</script>
<?php endif; ?>

<script>
function resetForm() {
    document.getElementById('edit_id').value = '';
    document.getElementById('modalTitle').innerText = 'Add Product';
    document.querySelector('#productModal form').reset();
}
function loadEdit(id, name, desc, price, sale, brand, cat, stock, feat, status) {
    document.getElementById('edit_id').value = id;
    document.getElementById('name').value = name;
    document.getElementById('description').value = desc;
    document.getElementById('price').value = price;
    document.getElementById('sale_price').value = sale || '';
    document.getElementById('brand_id').value = brand;
    document.getElementById('category_id').value = cat;
    document.getElementById('stock').value = stock;
    document.getElementById('featured').checked = feat == 1;
    document.getElementById('status').value = status;
    document.getElementById('modalTitle').innerText = 'Edit Product';
    new bootstrap.Modal(document.getElementById('productModal')).show();
}
</script>

<?php include 'includes/footer.php'; ?>
