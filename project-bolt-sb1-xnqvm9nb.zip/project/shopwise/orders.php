<?php
$page_title = 'My Orders';
include 'includes/header.php';
requireLogin();

$orders = mysqli_query(db(), "SELECT * FROM orders WHERE user_id = {$_SESSION['user_id']} ORDER BY created_at DESC");
?>

<div class="page-banner">
    <div class="container">
        <h1>My Orders</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li class="breadcrumb-item active">My Orders</li>
            </ol>
        </nav>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 mb-4">
                <div class="profile-sidebar">
                    <div class="profile-avatar"><?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?></div>
                    <h5 class="text-center"><?= sanitize($_SESSION['user_name']) ?></h5>
                    <p class="text-center text-muted" style="font-size:0.85rem;"><?= sanitize($_SESSION['user_email']) ?></p>
                    <hr>
                    <div class="profile-menu">
                        <a href="<?= BASE_URL ?>/profile.php"><i class="bi bi-person"></i> My Profile</a>
                        <a href="<?= BASE_URL ?>/edit-profile.php"><i class="bi bi-pencil-square"></i> Edit Profile</a>
                        <a href="<?= BASE_URL ?>/orders.php" class="active"><i class="bi bi-bag-check"></i> My Orders</a>
                        <a href="<?= BASE_URL ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <?php if (mysqli_num_rows($orders) > 0): ?>
                    <?php while ($order = mysqli_fetch_assoc($orders)):
                        $items = mysqli_query(db(), "SELECT oi.*, p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = {$order['id']}");
                    ?>
                    <div class="profile-content mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                            <h5 class="mb-0">Order #<?= $order['id'] ?></h5>
                            <span class="status-badge status-<?= $order['status'] ?>"><?= $order['status'] ?></span>
                        </div>
                        <p class="text-muted mb-3" style="font-size:0.85rem;">
                            <i class="bi bi-calendar"></i> <?= date('d M Y, h:i A', strtotime($order['created_at'])) ?> &nbsp;|&nbsp;
                            <i class="bi bi-credit-card"></i> <?= sanitize($order['payment_method']) ?> &nbsp;|&nbsp;
                            <i class="bi bi-geo-alt"></i> <?= sanitize($order['city']) ?> - <?= sanitize($order['pincode']) ?>
                        </p>
                        <div class="table-responsive">
                            <table class="table table-sm align-middle">
                                <thead>
                                    <tr style="background:var(--gray-lighter);">
                                        <th>Product</th>
                                        <th class="text-center">Qty</th>
                                        <th class="text-end">Price</th>
                                        <th class="text-end">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($item = mysqli_fetch_assoc($items)): ?>
                                    <tr>
                                        <td><?= sanitize($item['name']) ?></td>
                                        <td class="text-center"><?= $item['quantity'] ?></td>
                                        <td class="text-end"><?= formatPrice($item['price']) ?></td>
                                        <td class="text-end fw-bold"><?= formatPrice($item['price'] * $item['quantity']) ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3" class="text-end fw-bold">Grand Total:</td>
                                        <td class="text-end fw-bold" style="color:var(--primary);font-size:1.1rem;"><?= formatPrice($order['total_amount']) ?></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                <div class="profile-content text-center py-5">
                    <i class="bi bi-bag-x" style="font-size:4rem;color:var(--gray-light);"></i>
                    <h4 class="mt-3">No orders yet</h4>
                    <p class="text-muted">Start shopping to place your first order!</p>
                    <a href="<?= BASE_URL ?>/index.php" class="btn-primary-custom">Browse Products</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
