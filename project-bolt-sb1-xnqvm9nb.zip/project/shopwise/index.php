<?php
$page_title = 'Home';
include 'includes/header.php';
$featured = getProducts("AND p.featured = 1 LIMIT 8");
$latest = getProducts("LIMIT 4");
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-content animate-up">
                <h1>Discover Fashion<br>That Defines You</h1>
                <p>Shop the latest trends from top brands. Premium quality, unbeatable prices, and styles for everyone.</p>
                <a href="<?= BASE_URL ?>/index.php#products" class="btn-hero-primary">Shop Now</a>
                <a href="<?= BASE_URL ?>/about.php" class="btn-hero-secondary">Learn More</a>
            </div>
            <div class="col-lg-6 d-none d-lg-block text-center hero-content">
                <i class="bi bi-bag-heart-fill" style="font-size: 18rem; opacity: 0.15;"></i>
            </div>
        </div>
    </div>
</section>

<!-- Categories Section -->
<section class="py-5">
    <div class="container">
        <div class="section-title">
            <h2>Shop by Category</h2>
            <p>Find exactly what you're looking for</p>
        </div>
        <div class="row g-4">
            <?php
            $cat_icons = ['Men' => 'bi-gender-male', 'Women' => 'bi-gender-female', 'Kids' => 'bi-emoji-smile', 'Couple' => 'bi-heart-fill'];
            $cat_classes = ['Men' => 'cat-icon-men', 'Women' => 'cat-icon-women', 'Kids' => 'cat-icon-kids', 'Couple' => 'cat-icon-couple'];
            $cats = getCategories();
            while ($c = mysqli_fetch_assoc($cats)):
            ?>
            <div class="col-lg-3 col-md-6">
                <a href="<?= BASE_URL ?>/category.php?id=<?= $c['id'] ?>" class="category-card">
                    <div class="cat-icon <?= $cat_classes[$c['name']] ?? 'cat-icon-men' ?>">
                        <i class="bi <?= $cat_icons[$c['name']] ?? 'bi-tag' ?>"></i>
                    </div>
                    <h5><?= sanitize($c['name']) ?></h5>
                    <p><?= sanitize(substr($c['description'] ?? '', 0, 40)) ?></p>
                </a>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<!-- Features Bar -->
<section class="features-bar">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-3 col-md-6">
                <div class="feature-item">
                    <div class="feature-icon feature-icon-1"><i class="bi bi-truck"></i></div>
                    <div>
                        <h6>Free Shipping</h6>
                        <p>On orders above ₹999</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="feature-item">
                    <div class="feature-icon feature-icon-2"><i class="bi bi-arrow-repeat"></i></div>
                    <div>
                        <h6>Easy Returns</h6>
                        <p>30-day return policy</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="feature-item">
                    <div class="feature-icon feature-icon-3"><i class="bi bi-shield-check"></i></div>
                    <div>
                        <h6>Secure Payment</h6>
                        <p>100% protected payments</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="feature-item">
                    <div class="feature-icon feature-icon-4"><i class="bi bi-headset"></i></div>
                    <div>
                        <h6>24/7 Support</h6>
                        <p>Dedicated customer care</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Products -->
<section class="py-5" id="products">
    <div class="container">
        <div class="section-title">
            <h2>Featured Products</h2>
            <p>Handpicked items just for you</p>
        </div>
        <div class="row g-4">
            <?php while ($p = mysqli_fetch_assoc($featured)): ?>
            <div class="col-lg-3 col-md-6">
                <div class="product-card">
                    <div class="product-img-wrap">
                        <img src="<?= getProductImage($p) ?>" alt="<?= sanitize($p['name']) ?>">
                        <span class="product-badge featured">Featured</span>
                        <div class="product-actions">
                            <a href="<?= BASE_URL ?>/product.php?id=<?= $p['id'] ?>" class="product-action-btn" title="View"><i class="bi bi-eye"></i></a>
                        </div>
                    </div>
                    <div class="product-info">
                        <span class="product-brand"><?= sanitize($p['brand_name']) ?></span>
                        <a href="<?= BASE_URL ?>/product.php?id=<?= $p['id'] ?>" class="product-name"><?= sanitize($p['name']) ?></a>
                        <span class="product-category-tag"><?= sanitize($p['category_name']) ?></span>
                        <div class="product-price-row">
                            <span class="product-price"><?= formatPrice($p['sale_price'] ?: $p['price']) ?></span>
                            <?php if ($p['sale_price']): ?>
                            <span class="product-old-price"><?= formatPrice($p['price']) ?></span>
                            <?php endif; ?>
                        </div>
                        <a href="<?= BASE_URL ?>/cart.php?action=add&id=<?= $p['id'] ?>" class="btn-add-cart"><i class="bi bi-cart-plus"></i> Add to Cart</a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<!-- Brands Section -->
<section class="py-5" style="background: var(--gray-lighter);">
    <div class="container">
        <div class="section-title">
            <h2>Shop by Brand</h2>
            <p>Your favorite brands in one place</p>
        </div>
        <div class="row g-4">
            <?php
            $brand_colors = ['#FF6B35', '#2EC4B6', '#118AB2', '#EF476F', '#FFD23F'];
            $brands = getBrands();
            $bi = 0;
            while ($b = mysqli_fetch_assoc($brands)):
            ?>
            <div class="col-lg-2-4 col-md-4 col-sm-6" style="--bs-gutter-x: 1.5rem;">
                <a href="<?= BASE_URL ?>/brand.php?id=<?= $b['id'] ?>" class="brand-card">
                    <div class="brand-letter" style="background: <?= $brand_colors[$bi % 5] ?>;">
                        <?= strtoupper(substr($b['name'], 0, 1)) ?>
                    </div>
                    <h5><?= sanitize($b['name']) ?></h5>
                    <p><?= sanitize(substr($b['description'] ?? '', 0, 30)) ?></p>
                </a>
            </div>
            <?php $bi++; endwhile; ?>
        </div>
    </div>
</section>

<!-- Latest Products -->
<section class="py-5">
    <div class="container">
        <div class="section-title">
            <h2>New Arrivals</h2>
            <p>Fresh styles just landed</p>
        </div>
        <div class="row g-4">
            <?php while ($p = mysqli_fetch_assoc($latest)): ?>
            <div class="col-lg-3 col-md-6">
                <div class="product-card">
                    <div class="product-img-wrap">
                        <img src="<?= getProductImage($p) ?>" alt="<?= sanitize($p['name']) ?>">
                        <span class="product-badge">New</span>
                    </div>
                    <div class="product-info">
                        <span class="product-brand"><?= sanitize($p['brand_name']) ?></span>
                        <a href="<?= BASE_URL ?>/product.php?id=<?= $p['id'] ?>" class="product-name"><?= sanitize($p['name']) ?></a>
                        <span class="product-category-tag"><?= sanitize($p['category_name']) ?></span>
                        <div class="product-price-row">
                            <span class="product-price"><?= formatPrice($p['sale_price'] ?: $p['price']) ?></span>
                            <?php if ($p['sale_price']): ?>
                            <span class="product-old-price"><?= formatPrice($p['price']) ?></span>
                            <?php endif; ?>
                        </div>
                        <a href="<?= BASE_URL ?>/cart.php?action=add&id=<?= $p['id'] ?>" class="btn-add-cart"><i class="bi bi-cart-plus"></i> Add to Cart</a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <div class="text-center mt-4">
            <a href="<?= BASE_URL ?>/index.php#products" class="btn-primary-custom">View All Products</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
