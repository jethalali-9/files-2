<?php
$page_title = 'Edit Profile';
include 'includes/header.php';
requireLogin();

$user = getUserById($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string(db(), $_POST['name']);
    $phone = mysqli_real_escape_string(db(), $_POST['phone']);
    $address = mysqli_real_escape_string(db(), $_POST['address']);
    $city = mysqli_real_escape_string(db(), $_POST['city']);
    $pincode = mysqli_real_escape_string(db(), $_POST['pincode']);
    $new_password = $_POST['new_password'];

    $sql = "UPDATE users SET name='$name', phone='$phone', address='$address', city='$city', pincode='$pincode'";
    if (!empty($new_password)) {
        $hash = password_hash($new_password, PASSWORD_DEFAULT);
        $sql .= ", password='$hash'";
    }
    $sql .= " WHERE id={$_SESSION['user_id']}";

    if (mysqli_query(db(), $sql)) {
        $_SESSION['user_name'] = $name;
        setFlash('success', 'Profile updated successfully!');
        redirect(BASE_URL . '/profile.php');
    } else {
        $error = 'Failed to update profile.';
    }
}
?>

<div class="page-banner">
    <div class="container">
        <h1>Edit Profile</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/profile.php">Profile</a></li>
                <li class="breadcrumb-item active">Edit</li>
            </ol>
        </nav>
    </div>
</div>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 mb-4">
                <div class="profile-sidebar">
                    <div class="profile-avatar"><?= strtoupper(substr($user['name'], 0, 1)) ?></div>
                    <h5 class="text-center"><?= sanitize($user['name']) ?></h5>
                    <p class="text-center text-muted" style="font-size:0.85rem;"><?= sanitize($user['email']) ?></p>
                    <hr>
                    <div class="profile-menu">
                        <a href="<?= BASE_URL ?>/profile.php"><i class="bi bi-person"></i> My Profile</a>
                        <a href="<?= BASE_URL ?>/edit-profile.php" class="active"><i class="bi bi-pencil-square"></i> Edit Profile</a>
                        <a href="<?= BASE_URL ?>/orders.php"><i class="bi bi-bag-check"></i> My Orders</a>
                        <a href="<?= BASE_URL ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="profile-content">
                    <h4 class="mb-4"><i class="bi bi-pencil-square"></i> Update Your Information</h4>
                    <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" required value="<?= sanitize($user['name']) ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email (cannot change)</label>
                            <input type="email" class="form-control" value="<?= sanitize($user['email']) ?>" readonly>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" name="phone" class="form-control" value="<?= sanitize($user['phone'] ?? '') ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">City</label>
                                <input type="text" name="city" class="form-control" value="<?= sanitize($user['city'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Pincode</label>
                            <input type="text" name="pincode" class="form-control" value="<?= sanitize($user['pincode'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="3"><?= sanitize($user['address'] ?? '') ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password (leave blank to keep current)</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Enter new password">
                        </div>
                        <button type="submit" class="btn-primary-custom"><i class="bi bi-check-circle"></i> Save Changes</button>
                        <a href="<?= BASE_URL ?>/profile.php" class="btn btn-outline-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
