# ShopWise - E-Commerce Website

A complete e-commerce website built with HTML, CSS, Bootstrap, PHP, and MySQL.

## Features

### Frontend (User Side)
- **Home Page** - Hero section, featured products, brand showcase, category cards, new arrivals
- **Brand Filter** - Browse products by brand (Nike, Adidas, Puma, Levis, Zara) with sub-category filtering
- **Category Filter** - Browse products by category (Men, Women, Kids, Couple) with sub-brand filtering
- **About Us** - Company info, features, stats
- **Product Detail** - Full product view with quantity selector, related products
- **Shopping Cart** - Add, update, remove items with order summary
- **Checkout** - Shipping details form with order placement
- **User Registration & Login** - Secure password hashing
- **User Profile** - View profile information and order statistics
- **Edit Profile** - Update name, phone, address, city, pincode, password
- **My Orders** - View all orders with status tracking (Pending, Processing, Shipped, Delivered, Cancelled)

### Admin Panel
- **Dashboard** - Revenue stats, order count, recent orders overview
- **Manage Products** - Add, edit, delete products with image upload
- **Manage Brands** - Add, edit, delete brands
- **Manage Categories** - Add, edit, delete categories
- **Manage Orders** - View order details, update order status
- **Manage Users** - View and delete registered users

## Installation (XAMPP / WAMP)

1. Copy the `shopwise` folder to your web server root:
   - XAMPP: `C:\xampp\htdocs\`
   - WAMP: `C:\wamp64\www\`

2. Start Apache and MySQL from XAMPP/WAMP control panel.

3. Open phpMyAdmin (http://localhost/phpmyadmin) and import `database.sql` file.

4. Open the website at: http://localhost/shopwise

## Admin Access
- URL: http://localhost/shopwise/admin/login.php
- Email: admin@shopwise.com
- Password: admin123

## Tech Stack
- HTML5
- CSS3 (Custom color grid system)
- Bootstrap 5.3
- PHP (procedural with mysqli)
- MySQL / MariaDB

## File Structure
```
shopwise/
├── index.php              # Home page
├── brand.php              # Brand filter page
├── category.php           # Category filter page
├── about.php              # About us page
├── product.php            # Product detail page
├── cart.php               # Shopping cart
├── checkout.php           # Checkout page
├── login.php              # User login
├── register.php           # User registration
├── logout.php             # User logout
├── profile.php            # User profile
├── edit-profile.php       # Edit profile
├── orders.php             # My orders
├── database.sql           # Database schema + sample data
├── config/
│   └── database.php       # DB connection config
├── includes/
│   ├── header.php         # Site header with navigation
│   ├── footer.php         # Site footer
│   └── functions.php      # Helper functions
├── assets/
│   ├── css/
│   │   ├── style.css      # Main stylesheet
│   │   └── admin.css      # Admin panel styles
│   └── js/
│       └── main.js        # Frontend JavaScript
├── uploads/                # Product images
└── admin/
    ├── login.php          # Admin login
    ├── logout.php         # Admin logout
    ├── dashboard.php      # Admin dashboard
    ├── products.php       # Manage products
    ├── brands.php         # Manage brands
    ├── categories.php     # Manage categories
    ├── orders.php         # Manage orders
    ├── order-details.php  # AJAX order details
    ├── users.php          # Manage users
    └── includes/
        ├── header.php     # Admin header
        └── footer.php     # Admin footer
```

## Color Palette
- Primary: #FF6B35 (Orange)
- Secondary: #2EC4B6 (Teal)
- Accent: #FFD23F (Yellow)
- Success: #06D6A0 (Green)
- Error: #EF476F (Pink)
- Info: #118AB2 (Blue)
- Dark: #073B4C (Dark Teal)
