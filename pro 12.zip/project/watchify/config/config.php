<?php
// Watchify Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'watchify');
define('BASE_URL', '/watchify');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function db() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            die('<h3>Database connection failed.</h3><p>Please import <code>database/watchify.sql</code> and check <code>config/config.php</code>.</p>');
        }
    }
    return $pdo;
}

function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function url($path = '') { return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/'); }

function img_url($path) {
    if (!$path) return '';
    if (preg_match('#^https?://#', $path)) return $path;
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

function redirect($path = '') { header('Location: ' . url($path)); exit; }
function is_logged_in() { return isset($_SESSION['user_id']); }
function is_admin() { return isset($_SESSION['admin_id']); }
function require_login() { if (!is_logged_in()) redirect('login.php'); }
function require_admin() { if (!is_admin()) redirect('admin/login.php'); }
function find($table, $id) {
    $stmt = db()->prepare("SELECT * FROM `$table` WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

// Security: CSRF token
function csrf_token() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field() {
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}
function csrf_verify() {
    if (empty($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
        die('Invalid CSRF token. Please try again.');
    }
}

// Security: sanitize input
function clean($v) {
    return trim(strip_tags((string)$v));
}

// Format price in Indian Rupees
function rupee($amount) {
    return '&#8377;' . number_format((float)$amount, 0);
}
