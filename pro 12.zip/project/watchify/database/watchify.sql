-- Watchify - Database Schema with 80 products (20 per category)
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS watchify CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE watchify;

DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `old_price` decimal(10,2) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`), KEY `category_id` (`category_id`),
  CONSTRAINT `fk_prod_brand` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prod_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending',
  `payment_method` varchar(30) NOT NULL DEFAULT 'Cash on Delivery',
  `customer_name` varchar(120) DEFAULT NULL,
  `customer_phone` varchar(30) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `user_id` (`user_id`),
  CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`), KEY `order_id` (`order_id`),
  CONSTRAINT `fk_oi_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed: Brands
INSERT INTO `brands` (`name`, `slug`, `description`) VALUES
('Rolex', 'rolex', 'Luxury Swiss watches, a symbol of prestige and precision.'),
('Casio', 'casio', 'Affordable, durable and innovative Japanese watches.'),
('Omega', 'omega', 'Premium Swiss timepieces known for accuracy and style.'),
('Fossil', 'fossil', 'Modern fashion watches blending classic and contemporary.'),
('Titan', 'titan', 'Trusted Indian brand offering elegant everyday watches.');

-- Seed: Categories
INSERT INTO `categories` (`name`, `slug`) VALUES
('Men', 'men'), ('Women', 'women'), ('Kids', 'kids'), ('Couple', 'couple');

-- Seed: 80 Products (20 per category) with unique Pexels photos
-- Men (category_id=1)
INSERT INTO `products` (`name`,`brand_id`,`category_id`,`price`,`old_price`,`image`,`description`,`stock`,`featured`,`status`) VALUES
('Rolex Submariner',1,1,950000,1050000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Iconic diving watch with automatic movement.',5,1,'active'),
('Casio G-Shock',2,1,8500,10000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Shock resistant sport watch for men.',20,1,'active'),
('Omega Seamaster',3,1,425000,450000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Professional diver watch with chronometer.',3,1,'active'),
('Fossil Gen 6',4,1,18900,22000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Smart hybrid watch for men.',12,1,'active'),
('Titan Neo',5,1,5900,7500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Everyday minimalist watch for men.',25,1,'active'),
('Rolex Daytona',1,1,1150000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Racing chronograph with tachymeter.',2,0,'active'),
('Casio Edifice',2,1,12500,15000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Bold chronograph for the modern man.',15,0,'active'),
('Omega Speedmaster',3,1,385000,420000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Legendary moonwatch chronograph.',4,0,'active'),
('Fossil Townsman',4,1,14500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Classic automatic dress watch.',10,0,'active'),
('Titan Octane',5,1,3500,4500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Sporty chronograph for daily wear.',30,0,'active'),
('Rolex GMT Master',1,1,1050000,1150000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Dual time zone pilot watch.',3,1,'active'),
('Casio Pro Trek',2,1,15500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Outdoor adventure watch with sensors.',18,0,'active'),
('Omega Aqua Terra',3,1,365000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Versatile land and sea timepiece.',5,0,'active'),
('Fossil Collider',4,1,11500,13500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Slim profile casual watch.',14,0,'active'),
('Titan Raga Analog',5,1,4200,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Elegant analog for everyday use.',22,0,'active'),
('Rolex Explorer',1,1,850000,920000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Adventure ready explorer watch.',4,0,'active'),
('Casio Oceanus',2,1,18500,22000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Premium titanium chronograph.',8,0,'active'),
('Omega DeVille',3,1,295000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Sophisticated dress watch.',6,0,'active'),
('Fossil Grant',4,1,13500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Vintage inspired automatic watch.',11,0,'active'),
('Titan HTSE',5,1,6500,7900,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Charge by light technology watch.',20,0,'active');

-- Women (category_id=2)
INSERT INTO `products` (`name`,`brand_id`,`category_id`,`price`,`old_price`,`image`,`description`,`stock`,`featured`,`status`) VALUES
('Rolex Datejust',1,2,750000,820000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Classic ladies Datejust in steel and gold.',4,1,'active'),
('Casio Baby-G',2,2,6500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Tough and stylish watch for women.',15,0,'active'),
('Omega Constellation',3,2,385000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Elegant constellation watch for women.',4,0,'active'),
('Fossil Virginia',4,2,12500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Slim leather strap watch for women.',10,0,'active'),
('Titan Raga Pearl',5,2,7500,9500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Graceful mother of pearl dial watch.',18,1,'active'),
('Rolex Pearlmaster',1,2,1250000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Jewelry watch with diamond bezel.',2,0,'active'),
('Casio Sheen',2,2,8500,10500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Elegant metallic watch for women.',12,0,'active'),
('Omega Ladymatic',3,2,425000,465000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Refined automatic ladies watch.',3,0,'active'),
('Fossil Riley',4,2,11500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Modern minimalist ladies watch.',14,0,'active'),
('Titan Nebula',5,2,5500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Gold plated elegant watch.',16,0,'active'),
('Rolex Lady Datejust',1,2,680000,750000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Compact ladies luxury watch.',3,1,'active'),
('Casio Vintage',2,2,5500,7000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Retro digital watch for women.',20,0,'active'),
('Omega Seamaster Aqua',3,2,345000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Ladies aqua terra watch.',5,0,'active'),
('Fossil Carlie',4,2,10500,12500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Delicate bracelet watch for women.',13,0,'active'),
('Titan Raga Floral',5,2,6800,8200,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Floral dial elegant ladies watch.',17,0,'active'),
('Rolex Milgauss',1,2,620000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Anti-magnetic scientific watch.',3,0,'active'),
('Casio Metal Fab',2,2,4500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Metal band minimalist watch.',22,0,'active'),
('Omega Hour Vision',3,2,395000,435000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Co-axial automatic ladies watch.',4,0,'active'),
('Fossil Esse',4,2,9500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Essential minimalist ladies watch.',15,0,'active'),
('Titan Bandhan',5,2,4800,5900,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Sentimental pair watch for women.',19,0,'active');

-- Kids (category_id=3)
INSERT INTO `products` (`name`,`brand_id`,`category_id`,`price`,`old_price`,`image`,`description`,`stock`,`featured`,`status`) VALUES
('Casio Kids Digital',2,3,2500,3500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Fun colorful digital watch for kids.',30,1,'active'),
('Titan Kids Time',5,3,1800,2500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Colorful easy-read watch for kids.',40,1,'active'),
('Casio Baby-G Kids',2,3,3200,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Durable sport watch for active kids.',25,0,'active'),
('Titan Fastrack Kids',5,3,1500,2000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Cool trendy watch for kids.',35,1,'active'),
('Casio F91W Kids',2,3,1200,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Classic digital watch for kids.',50,0,'active'),
('Titan Zoop Kids',5,3,1100,1500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Fun cartoon themed watch.',45,0,'active'),
('Casio AE-1200',2,3,2800,3500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Adventure watch for young explorers.',28,0,'active'),
('Fossil Kids Mini',4,3,3500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Miniature fashion watch for kids.',20,0,'active'),
('Casio W-218',2,3,1500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Simple water resistant kids watch.',42,0,'active'),
('Titan Octane Kids',5,3,1900,2400,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Sporty kids chronograph.',32,0,'active'),
('Casio Ironman',2,3,3500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Tough sports watch for kids.',22,0,'active'),
('Fossil Scout Kids',4,3,3800,4500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Adventure ready kids watch.',18,0,'active'),
('Casio Data Bank',2,3,2200,2800,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Calculator watch for smart kids.',30,0,'active'),
('Titan Raga Kids',5,3,1700,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Elegant watch for young girls.',25,0,'active'),
('Casio G-Shock Mini',2,3,4200,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Mini G-Shock for adventurous kids.',15,1,'active'),
('Fossil Junior',4,3,3200,3900,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Stylish junior fashion watch.',20,0,'active'),
('Casio Sports Gear',2,3,3000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Sports watch with timer for kids.',26,0,'active'),
('Titan Zoop Sport',5,3,1400,1800,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Sporty colorful kids watch.',38,0,'active'),
('Casio Vintage Kids',2,3,2500,3000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Retro style kids digital watch.',24,0,'active'),
('Fossil Sport Kids',4,3,3600,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Active sport watch for kids.',17,0,'active');

-- Couple (category_id=4)
INSERT INTO `products` (`name`,`brand_id`,`category_id`,`price`,`old_price`,`image`,`description`,`stock`,`featured`,`status`) VALUES
('Couple Set Classic',5,4,12500,15000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Matching his-and-hers couple watch set.',8,1,'active'),
('Couple Set Luxe',4,4,22000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Premium couple watch set by Fossil.',6,0,'active'),
('Rolex Couple Edition',1,4,1850000,2000000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Exclusive couple set by Rolex.',2,1,'active'),
('Titan Pair Classic',5,4,8500,10500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Elegant matching pair for couples.',12,1,'active'),
('Casio Couple Sport',2,4,9500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Sporty matching couple watches.',15,0,'active'),
('Omega Couple Set',3,4,580000,650000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Luxury couple set by Omega.',3,0,'active'),
('Fossil Pair Modern',4,4,16500,19500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Modern couple watch set.',10,0,'active'),
('Titan Bandhan Set',5,4,7500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Sentimental couple pair by Titan.',14,0,'active'),
('Rolex His Hers',1,4,1650000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','His and hers luxury set.',2,0,'active'),
('Casio Duo Set',2,4,7500,9500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Affordable matching duo set.',18,0,'active'),
('Omega His Hers',3,4,495000,550000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Premium his and hers pair.',4,0,'active'),
('Fossil Couple Vintage',4,4,18500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Vintage style couple set.',8,0,'active'),
('Titan Couple Gold',5,4,11500,13500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Gold tone couple pair.',10,1,'active'),
('Rolex Love Set',1,4,1950000,2200000,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Exclusive love edition couple set.',1,0,'active'),
('Casio Pair Digital',2,4,5500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Matching digital couple watches.',20,0,'active'),
('Omega Couple Constellation',3,4,625000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Constellation couple pair.',3,0,'active'),
('Fossil Duo Sport',4,4,14500,17500,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Sporty duo couple set.',9,0,'active'),
('Titan Couple Silver',5,4,9500,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Silver tone couple pair.',11,0,'active'),
('Rolex Anniversary Set',1,4,2100000,NULL,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Anniversary edition couple set.',1,1,'active'),
('Casio Couple Retro',2,4,6500,7900,'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg','Retro matching couple watches.',16,0,'active');

-- Seed: Admin (admin@watchify.com / admin123)
INSERT INTO `admins` (`name`, `email`, `password`) VALUES
('Admin', 'admin@watchify.com', '$2y$12$znoxEYlEsi55CKGf1ZZBLus9RyLMBDSfUwsRwIHJgo9Fq9UKmZDwC');

SET FOREIGN_KEY_CHECKS = 1;
