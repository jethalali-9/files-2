<?php
require __DIR__.'/config/config.php';
require_login();
if (!isset($_SESSION['cart']) || !$_SESSION['cart']) redirect('cart.php');
$uid = (int)$_SESSION['user_id'];
$user = find('users', $uid);
$ids = array_keys($_SESSION['cart']);
$in = implode(',', array_fill(0, count($ids), '?'));
$stmt = db()->prepare("SELECT * FROM products WHERE id IN ($in)");
$stmt->execute($ids);
$products = $stmt->fetchAll();
$total = 0;
foreach ($products as $p) $total += $p['price'] * $_SESSION['cart'][$p['id']];
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_verify();
  $address = clean($_POST['address'] ?? '');
  if (!$address) $address = $user['address'];
  if (!$address) $error = 'Please enter a shipping address.';
  else {
    $pdo = db();
    $pdo->beginTransaction();
    try {
      $ins = $pdo->prepare("INSERT INTO orders (user_id,total,status,payment_method,customer_name,customer_phone,shipping_address) VALUES (?,?,?,?,?,?,?)");
      $ins->execute([$uid,$total,'Pending','Cash on Delivery',$user['name'],$user['phone'],$address]);
      $oid = (int)$pdo->lastInsertId();
      $itIns = $pdo->prepare("INSERT INTO order_items (order_id,product_id,name,image,price,qty) VALUES (?,?,?,?,?,?)");
      foreach ($products as $p) { $q = $_SESSION['cart'][$p['id']]; $itIns->execute([$oid,$p['id'],$p['name'],$p['image'],$p['price'],$q]); }
      $pdo->commit();
      $_SESSION['cart'] = [];
      redirect('order_view.php?id='.$oid);
    } catch (Exception $e) { $pdo->rollBack(); $error = 'Order could not be placed. Please try again.'; }
  }
}
$title = 'Checkout - Watchify';
include __DIR__.'/partials/header.php';
?>
<div class="container py-4">
  <nav><ol class="breadcrumb breadcrumb-soft"><li class="breadcrumb-item"><a href="<?= url('index.php') ?>">Home</a></li><li class="breadcrumb-item"><a href="<?= url('cart.php') ?>">Cart</a></li><li class="breadcrumb-item active">Checkout</li></ol></nav>
  <h3 class="fw-bold mb-4"><i class="bi bi-credit-card"></i> Checkout</h3>
  <div class="row g-4">
    <div class="col-lg-7"><div class="admin-card">
      <h5 class="fw-bold mb-3">Shipping Details</h5>
      <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
      <form method="post"><?= csrf_field() ?>
        <div class="mb-3"><label class="form-label">Full Name</label><input type="text" class="form-control" value="<?= e($user['name']) ?>" disabled></div>
        <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" value="<?= e($user['email']) ?>" disabled></div>
        <div class="mb-3"><label class="form-label">Phone</label><input type="text" class="form-control" value="<?= e($user['phone']) ?>" disabled></div>
        <div class="mb-3"><label class="form-label">Shipping Address</label><textarea name="address" class="form-control" rows="4" required><?= e($user['address']) ?></textarea></div>
        <div class="cod-banner mb-3"><i class="bi bi-cash-coin fs-4"></i> <div><strong>Cash on Delivery</strong><br><small>Pay in cash when your order arrives at your doorstep. No online payment needed.</small></div></div>
        <button class="btn btn-grad btn-lg w-100"><i class="bi bi-bag-check"></i> Place Order (COD)</button>
      </form>
    </div></div>
    <div class="col-lg-5"><div class="admin-card">
      <h5 class="fw-bold">Your Items</h5>
      <div class="d-flex flex-column gap-2"><?php foreach ($products as $p): $q=$_SESSION['cart'][$p['id']]; ?>
        <div class="d-flex gap-2 align-items-center"><img src="<?= img_url($p['image']) ?>" style="width:54px;height:54px;border-radius:10px;object-fit:cover"><div class="flex-grow-1"><div class="fw-semibold small"><?= e($p['name']) ?></div><small class="text-muted">Qty: <?= $q ?></small></div><div class="fw-bold"><?= rupee($p['price']*$q) ?></div></div>
      <?php endforeach; ?></div>
      <hr>
      <div class="d-flex justify-content-between py-1"><span>Subtotal</span><span><?= rupee($total) ?></span></div>
      <div class="d-flex justify-content-between py-1"><span>Shipping</span><span class="text-success">Free</span></div>
      <div class="d-flex justify-content-between py-1"><span>Payment</span><span class="badge-soft cod">Cash on Delivery</span></div>
      <div class="d-flex justify-content-between fw-bold fs-5 mt-2"><span>Total</span><span style="color:var(--charcoal)"><?= rupee($total) ?></span></div>
    </div></div>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
