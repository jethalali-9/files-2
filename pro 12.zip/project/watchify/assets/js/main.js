document.addEventListener('DOMContentLoaded', function () {
  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('show'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    revealEls.forEach(function (el) { io.observe(el); });
  } else { revealEls.forEach(function (el) { el.classList.add('show'); }); }

  var toggler = document.getElementById('adminToggle');
  var sidebar = document.getElementById('adminSidebar');
  if (toggler && sidebar) toggler.addEventListener('click', function () { sidebar.classList.toggle('open'); });

  // File upload preview
  var fileInput = document.getElementById('productImage');
  var preview = document.getElementById('uploadPreview');
  var previewWrap = document.getElementById('previewWrap');
  if (fileInput && preview) {
    fileInput.addEventListener('change', function () {
      var file = this.files[0];
      if (file) {
        var reader = new FileReader();
        reader.onload = function (e) {
          preview.src = e.target.result;
          if (previewWrap) previewWrap.style.display = 'block';
        };
        reader.readAsDataURL(file);
      }
    });
  }

  // Cart live total update
  var cartRows = document.querySelectorAll('[data-cart-row]');
  cartRows.forEach(function (row) {
    var input = row.querySelector('[data-qty]');
    var price = parseFloat(row.getAttribute('data-price'));
    var subEl = row.querySelector('[data-subtotal]');
    var grandEl = document.getElementById('grandTotal');
    function recalc() {
      var qty = parseInt(input.value) || 0;
      var sub = price * qty;
      if (subEl) subEl.textContent = '\u20B9' + sub.toLocaleString('en-IN');
      var total = 0;
      cartRows.forEach(function (r) {
        var q = parseInt(r.querySelector('[data-qty]').value) || 0;
        var p = parseFloat(r.getAttribute('data-price'));
        total += p * q;
      });
      if (grandEl) grandEl.textContent = '\u20B9' + total.toLocaleString('en-IN');
    }
    input.addEventListener('input', recalc);
    input.addEventListener('change', recalc);
    var dec = row.querySelector('[data-dec]');
    var inc = row.querySelector('[data-inc]');
    if (dec) dec.addEventListener('click', function () { input.stepDown(); recalc(); });
    if (inc) inc.addEventListener('click', function () { input.stepUp(); recalc(); });
  });
});
