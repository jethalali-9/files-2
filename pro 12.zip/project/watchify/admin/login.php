<?php
require __DIR__.'/../config/config.php';
if (is_admin()) redirect('admin/index.php');
$title = 'Admin Login - Watchify';
$err = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_verify();
  $email = clean($_POST['email'] ?? '');
  $pass = $_POST['password'] ?? '';
  $stmt = db()->prepare("SELECT * FROM admins WHERE email=?");
  $stmt->execute([$email]);
  $a = $stmt->fetch();
  if (!$a || !password_verify($pass, $a['password'])) $err = 'Invalid credentials.';
  else { $_SESSION['admin_id'] = (int)$a['id']; $_SESSION['admin_name'] = $a['name']; redirect('admin/index.php'); }
}
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login - Watchify</title>
<link rel="icon" href="<?= url('assets/img/favicon.svg') ?>" type="image/svg+xml">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700;800&display=swap" rel="stylesheet">
<link href="<?= url('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body style="background:var(--grad-hero);min-height:100vh;display:grid;place-items:center">
  <div class="auth-card fade-in" style="max-width:460px;grid-template-columns:1fr"><div class="auth-form">
    <div class="text-center mb-4"><img src="<?= url('assets/img/logo.svg') ?>" alt="Watchify" style="height:54px"><h3 class="fw-bold mt-2" style="color:var(--charcoal)">Admin Panel</h3><p class="text-muted">Sign in to manage Watchify</p></div>
    <?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
    <form method="post"><?= csrf_field() ?>
      <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" value="admin@watchify.com" required></div>
      <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" placeholder="admin123" required></div>
      <button class="btn btn-grad w-100 btn-lg">Login</button>
    </form>
    <div class="alert alert-info mt-3 py-2 small"><strong>Demo:</strong> admin@watchify.com / admin123</div>
    <a href="<?= url('index.php') ?>" class="d-block text-center mt-2 text-muted">&larr; Back to site</a>
  </div></div>
</body></html>
