<?php
require __DIR__.'/../config/config.php';
require_admin();
$page = 'orders';
$title = 'Orders';
if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['id'])) {
  csrf_verify();
  $status = $_POST['status'] ?? 'Pending';
  db()->prepare("UPDATE orders SET status=? WHERE id=?")->execute([$status, (int)$_POST['id']]);
  redirect('admin/orders.php');
}
if (($_GET['action']??'')==='delete' && !empty($_GET['id'])) {
  db()->prepare("DELETE FROM orders WHERE id=?")->execute([(int)$_GET['id']]);
  redirect('admin/orders.php');
}
$orders = db()->query("SELECT o.*, u.name user_name, u.email user_email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC")->fetchAll();
$allItems = db()->query("SELECT * FROM order_items ORDER BY id")->fetchAll();
$itemsByOrder = [];
foreach ($allItems as $it) $itemsByOrder[$it['order_id']][] = $it;
include __DIR__.'/partials/header.php';
?>
<div class="admin-card">
  <h5 class="fw-bold mb-3">All Orders (<?= count($orders) ?>)</h5>
  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr><th>Order ID</th><th>User ID</th><th>Name</th><th>Phone</th><th>Address</th><th>Product Name</th><th>Photo</th><th>Amount</th><th>Payment</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
      <?php if (!$orders): ?><tr><td colspan="11" class="text-center text-muted py-4">No orders yet</td></tr><?php endif; ?>
      <?php foreach ($orders as $o):
        $items = $itemsByOrder[$o['id']] ?? [];
        $itemCount = count($items);
        $rowspan = max(1, $itemCount);
      ?>
        <tr>
          <td rowspan="<?= $rowspan ?>">#<?= $o['id'] ?></td>
          <td rowspan="<?= $rowspan ?>"><?= $o['user_id'] ?></td>
          <td rowspan="<?= $rowspan ?>"><?= e($o['customer_name'] ?: $o['user_name']) ?></td>
          <td rowspan="<?= $rowspan ?>"><?= e($o['customer_phone'] ?: '-') ?></td>
          <td rowspan="<?= $rowspan ?>" style="max-width:200px"><small><?= e($o['shipping_address']) ?></small></td>
          <?php if ($items): $it = $items[0]; ?>
            <td><?= e($it['name']) ?><?php if ($itemCount>1): ?> <span class="badge rounded-pill bg-secondary">+<?= $itemCount-1 ?></span><?php endif; ?></td>
            <td><img src="<?= img_url($it['image']) ?>" style="width:50px;height:50px;border-radius:8px;object-fit:cover" onerror="this.src='https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg'"></td>
          <?php else: ?><td>-</td><td>-</td><?php endif; ?>
          <td rowspan="<?= $rowspan ?>" class="fw-bold"><?= rupee($o['total']) ?></td>
          <td rowspan="<?= $rowspan ?>"><span class="badge-soft cod"><?= e($o['payment_method'] ?? 'COD') ?></span></td>
          <td rowspan="<?= $rowspan ?>"><span class="badge-soft <?= strtolower(e($o['status'])) ?>"><?= e($o['status']) ?></span></td>
          <td rowspan="<?= $rowspan ?>">
            <form method="post" class="d-flex flex-column gap-1"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $o['id'] ?>">
              <select name="status" class="form-select form-select-sm" style="width:130px"><?php foreach (['Pending','Processing','Shipped','Delivered','Cancelled'] as $s): ?><option value="<?= $s ?>" <?= $o['status']===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select>
              <button class="btn btn-sm btn-grad">Update</button>
            </form>
            <a href="<?= url('admin/orders.php?action=delete&id=').$o['id'] ?>" class="btn btn-sm btn-outline-danger mt-1 w-100" onclick="return confirm('Delete this order?')"><i class="bi bi-trash"></i> Delete</a>
          </td>
        </tr>
        <?php for ($i=1; $i<$itemCount; $i++): $it = $items[$i]; ?>
        <tr><td><?= e($it['name']) ?></td><td><img src="<?= img_url($it['image']) ?>" style="width:50px;height:50px;border-radius:8px;object-fit:cover" onerror="this.src='https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg'"></td></tr>
        <?php endfor; ?>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
