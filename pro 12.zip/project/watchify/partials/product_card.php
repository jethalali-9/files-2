<?php
function product_card($p) {
  ob_start(); ?>
  <div class="col-lg-3 col-md-6 reveal">
    <div class="card-watch">
      <div class="img-wrap">
        <a href="<?= url('product.php?id=').$p['id'] ?>"><img src="<?= img_url($p['image']) ?>" alt="<?= e($p['name']) ?>"></a>
        <?php if ($p['old_price']): ?><span class="tag">Sale</span><?php endif; ?>
        <button class="fav" title="Wishlist"><i class="bi bi-heart"></i></button>
      </div>
      <div class="body">
        <span class="brand"><?= e($p['brand_name']) ?> &middot; <?= e($p['cat_name']) ?></span>
        <h3><a href="<?= url('product.php?id=').$p['id'] ?>" class="text-reset"><?= e($p['name']) ?></a></h3>
        <div class="stars"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i></div>
        <div class="price"><?= rupee($p['price']) ?><?php if ($p['old_price']): ?><span class="old"><?= rupee($p['old_price']) ?></span><?php endif; ?></div>
        <form method="post" action="<?= url('cart.php') ?>"><?= csrf_field() ?><input type="hidden" name="action" value="add"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="btn-add"><i class="bi bi-bag-plus"></i> Add to Cart</button></form>
      </div>
    </div>
  </div>
  <?php return ob_get_clean();
}
