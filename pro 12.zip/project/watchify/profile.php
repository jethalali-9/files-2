<?php
require __DIR__.'/config/config.php';
require_login();
$uid = (int)$_SESSION['user_id'];
$user = find('users', $uid);
$title = 'My Profile - Watchify';
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['form']??'')==='profile') {
  csrf_verify();
  $name = clean($_POST['name'] ?? '');
  $phone = clean($_POST['phone'] ?? '');
  $address = clean($_POST['address'] ?? '');
  if ($name) {
    $stmt = db()->prepare("UPDATE users SET name=?, phone=?, address=? WHERE id=?");
    $stmt->execute([$name,$phone,$address,$uid]);
    $_SESSION['user_name'] = $name;
    $user = find('users', $uid);
    $msg = 'Profile updated successfully.';
  }
}
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['form']??'')==='password') {
  csrf_verify();
  $cur = $_POST['current'] ?? '';
  $new = $_POST['new'] ?? '';
  if (!password_verify($cur, $user['password'])) $msg = 'Current password is incorrect.';
  elseif (strlen($new) < 6) $msg = 'New password must be at least 6 characters.';
  else {
    $stmt = db()->prepare("UPDATE users SET password=? WHERE id=?");
    $stmt->execute([password_hash($new, PASSWORD_DEFAULT), $uid]);
    $msg = 'Password changed successfully.';
  }
}
$orders = db()->prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC");
$orders->execute([$uid]);
$orders = $orders->fetchAll();
$tab = $_GET['tab'] ?? 'profile';
include __DIR__.'/partials/header.php';
?>
<div class="container py-4">
  <nav><ol class="breadcrumb breadcrumb-soft"><li class="breadcrumb-item"><a href="<?= url('index.php') ?>">Home</a></li><li class="breadcrumb-item active">My Profile</li></ol></nav>
  <div class="profile-card fade-in">
    <div class="profile-head"><div class="avatar"><?= e(strtoupper(substr($user['name'],0,1))) ?></div><h4 class="fw-bold mb-0"><?= e($user['name']) ?></h4><p class="mb-0 text-light opacity-75"><?= e($user['email']) ?></p></div>
    <div class="row g-0">
      <div class="col-lg-3 border-end"><div class="profile-menu p-3"><div class="nav flex-column">
        <a class="nav-link <?= $tab==='profile'?'active':'' ?>" href="<?= url('profile.php?tab=profile') ?>"><i class="bi bi-person me-2"></i> My Profile</a>
        <a class="nav-link <?= $tab==='orders'?'active':'' ?>" href="<?= url('profile.php?tab=orders') ?>"><i class="bi bi-bag me-2"></i> My Orders</a>
        <a class="nav-link <?= $tab==='password'?'active':'' ?>" href="<?= url('profile.php?tab=password') ?>"><i class="bi bi-key me-2"></i> Change Password</a>
        <a class="nav-link text-danger" href="<?= url('logout.php') ?>"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
      </div></div></div>
      <div class="col-lg-9 p-4">
        <?php if ($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
        <?php if ($tab==='profile'): ?>
          <h5 class="fw-bold mb-3">Update Profile</h5>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="form" value="profile"><div class="row g-3">
            <div class="col-md-6"><label class="form-label">Full Name</label><input type="text" name="name" class="form-control" value="<?= e($user['name']) ?>" required></div>
            <div class="col-md-6"><label class="form-label">Email (not editable)</label><input type="email" class="form-control" value="<?= e($user['email']) ?>" disabled></div>
            <div class="col-md-6"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control" value="<?= e($user['phone']) ?>" required></div>
            <div class="col-12"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="3"><?= e($user['address']) ?></textarea></div>
            <div class="col-12"><button class="btn btn-grad"><i class="bi bi-save"></i> Save Changes</button></div>
          </div></form>
        <?php elseif ($tab==='orders'): ?>
          <h5 class="fw-bold mb-3">My Orders</h5>
          <?php if (!$orders): ?><div class="empty-state"><div class="ic"><i class="bi bi-bag"></i></div><h5>No orders yet</h5><p>When you place an order, it will appear here.</p><a href="<?= url('shop.php') ?>" class="btn btn-grad">Start Shopping</a></div>
          <?php else: ?><div class="table-responsive"><table class="table align-middle"><thead><tr><th>#</th><th>Date</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr></thead><tbody>
            <?php foreach ($orders as $o): $items = db()->prepare("SELECT * FROM order_items WHERE order_id=?"); $items->execute([$o['id']]); $cnt = $items->rowCount(); ?>
              <tr><td>#<?= $o['id'] ?></td><td><?= date('M d, Y', strtotime($o['created_at'])) ?></td><td><?= $cnt ?> item(s)</td><td><?= rupee($o['total']) ?></td><td><span class="badge-soft cod"><?= e($o['payment_method'] ?? 'COD') ?></span></td><td><span class="badge-soft <?= strtolower(e($o['status'])) ?>"><?= e($o['status']) ?></span></td><td><a href="<?= url('order_view.php?id=').$o['id'] ?>" class="btn btn-sm btn-outline-grad">View</a></td></tr>
            <?php endforeach; ?>
          </tbody></table></div><?php endif; ?>
        <?php elseif ($tab==='password'): ?>
          <h5 class="fw-bold mb-3">Change Password</h5>
          <form method="post" style="max-width:480px"><?= csrf_field() ?><input type="hidden" name="form" value="password">
            <div class="mb-3"><label class="form-label">Current Password</label><input type="password" name="current" class="form-control" required></div>
            <div class="mb-3"><label class="form-label">New Password</label><input type="password" name="new" class="form-control" required></div>
            <button class="btn btn-grad"><i class="bi bi-key"></i> Update Password</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
