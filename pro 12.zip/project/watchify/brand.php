<?php
require __DIR__.'/config/config.php';
$page = 'brand';
$slug = $_GET['slug'] ?? '';
$stmt = db()->prepare("SELECT * FROM brands WHERE slug=?");
$stmt->execute([$slug]);
$brand = $stmt->fetch();
if (!$brand) redirect('shop.php');
$stmt = db()->prepare("SELECT p.*, b.name brand_name, b.slug brand_slug, c.name cat_name, c.slug cat_slug FROM products p JOIN brands b ON b.id=p.brand_id JOIN categories c ON c.id=p.category_id WHERE p.brand_id=? AND p.status='active' ORDER BY p.id DESC");
$stmt->execute([$brand['id']]);
$products = $stmt->fetchAll();
$brands = db()->query("SELECT * FROM brands ORDER BY name")->fetchAll();
include __DIR__.'/partials/product_card.php';
include __DIR__.'/partials/header.php';
?>
<div class="container py-4">
  <nav><ol class="breadcrumb breadcrumb-soft"><li class="breadcrumb-item"><a href="<?= url('index.php') ?>">Home</a></li><li class="breadcrumb-item"><a href="<?= url('shop.php') ?>">Shop</a></li><li class="breadcrumb-item active"><?= e($brand['name']) ?></li></ol></nav>
  <div class="admin-card mb-4" style="background:var(--grad-hero);color:#fff"><div class="row align-items-center"><div class="col-md-8"><h2 class="fw-bold mb-1"><?= e($brand['name']) ?> Watches</h2><p class="mb-0 text-light opacity-75"><?= e($brand['description']) ?></p></div><div class="col-md-4 text-md-end"><span class="badge rounded-pill" style="background:rgba(245,158,11,.25);color:var(--amber-300);padding:.6rem 1.2rem"><?= count($products) ?> models</span></div></div></div>
  <div class="mb-3"><strong>Other brands:</strong> <?php foreach ($brands as $b): ?><a href="<?= url('brand.php?slug=').e($b['slug']) ?>" class="chip <?= $b['slug']==$slug?'active':'' ?>"><?= e($b['name']) ?></a><?php endforeach; ?></div>
  <?php if (!$products): ?><div class="empty-state"><div class="ic"><i class="bi bi-bag"></i></div><h5>No watches available</h5></div>
  <?php else: ?><div class="row g-4"><?php foreach ($products as $p) echo product_card($p); ?></div><?php endif; ?>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
