# Watchify - Watch Collection Website

A complete watch collection e-commerce website built with **PHP, MySQL & Bootstrap 5**.

## Features

- **Indian Rupees (₹)**: All prices displayed in INR
- **80 Products**: 20 products per category (Men, Women, Kids, Couple)
- **Cash on Delivery Only**: No online payment — pay at your doorstep
- **Admin File Upload**: Add/Edit product images via "Choose File" button (no URL needed)
- **Live Cart Total**: Quantity changes auto-update the total amount instantly
- **Filter Options**: Filter by brand, category, price range, search, and sort
- **Security**: CSRF tokens, input sanitization, prepared statements, XSS protection
- **New Unique Theme**: Teal / Amber / Charcoal color combination
- **Responsive**: Works on mobile, tablet, and desktop

## Installation

1. Copy the `watchify` folder to your web server (XAMPP `htdocs`).
2. Import `database/watchify.sql` via phpMyAdmin.
3. Edit `config/config.php` if your MySQL credentials differ.
4. Visit `http://localhost/watchify`.

## Default Admin

- URL: `http://localhost/watchify/admin/login.php`
- Email: `admin@watchify.com`
- Password: `admin123`
