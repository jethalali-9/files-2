<?php
require __DIR__.'/config/config.php';
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
if (($_POST['action']??'')==='add' && !empty($_POST['id'])) {
  csrf_verify();
  $id = (int)$_POST['id']; $qty = max(1, (int)($_POST['qty'] ?? 1));
  $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + $qty;
  redirect('cart.php');
}
if (($_POST['action']??'')==='update' && !empty($_POST['qty'])) {
  csrf_verify();
  foreach ($_POST['qty'] as $id=>$q) { $id=(int)$id; $q=max(0,(int)$q); if ($q<=0) unset($_SESSION['cart'][$id]); else $_SESSION['cart'][$id]=$q; }
  redirect('cart.php');
}
if (($_GET['action']??'')==='remove' && !empty($_GET['id'])) { unset($_SESSION['cart'][(int)$_GET['id']]); redirect('cart.php'); }
$title = 'Cart - Watchify';
$ids = array_keys($_SESSION['cart']);
$items = []; $total = 0;
if ($ids) {
  $in = implode(',', array_fill(0, count($ids), '?'));
  $stmt = db()->prepare("SELECT * FROM products WHERE id IN ($in)");
  $stmt->execute($ids);
  foreach ($stmt->fetchAll() as $p) { $qty = $_SESSION['cart'][$p['id']]; $items[] = ['p'=>$p,'qty'=>$qty,'sub'=>$p['price']*$qty]; $total += $p['price']*$qty; }
}
include __DIR__.'/partials/header.php';
?>
<div class="container py-4">
  <nav><ol class="breadcrumb breadcrumb-soft"><li class="breadcrumb-item"><a href="<?= url('index.php') ?>">Home</a></li><li class="breadcrumb-item active">Cart</li></ol></nav>
  <h3 class="fw-bold mb-4"><i class="bi bi-bag"></i> Shopping Cart</h3>
  <?php if (!$items): ?>
    <div class="empty-state"><div class="ic"><i class="bi bi-bag"></i></div><h5>Your cart is empty</h5><p>Browse our collection and add your favorite watches.</p><a href="<?= url('shop.php') ?>" class="btn btn-grad">Shop Watches</a></div>
  <?php else: ?>
    <div class="row g-4">
      <div class="col-lg-8">
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="update">
          <div class="d-flex flex-column gap-3">
            <?php foreach ($items as $it): ?>
              <div class="cart-item" data-cart-row data-price="<?= (float)$it['p']['price'] ?>">
                <img src="<?= img_url($it['p']['image']) ?>" alt="<?= e($it['p']['name']) ?>">
                <div class="flex-grow-1">
                  <h6 class="fw-bold mb-0"><?= e($it['p']['name']) ?></h6>
                  <small class="text-muted"><?= rupee($it['p']['price']) ?> each</small>
                  <div class="d-flex align-items-center gap-2 mt-2">
                    <button type="button" class="qty-btn" data-dec>-</button>
                    <input type="number" name="qty[<?= $it['p']['id'] ?>]" value="<?= $it['qty'] ?>" min="0" class="form-control text-center" style="width:70px" data-qty>
                    <button type="button" class="qty-btn" data-inc>+</button>
                    <a href="<?= url('cart.php?action=remove&id=').$it['p']['id'] ?>" class="btn btn-sm text-danger ms-2"><i class="bi bi-trash"></i></a>
                  </div>
                </div>
                <div class="fw-bold fs-5" style="color:var(--charcoal)" data-subtotal><?= rupee($it['sub']) ?></div>
              </div>
            <?php endforeach; ?>
          </div>
          <button class="btn btn-outline-grad mt-3"><i class="bi bi-arrow-repeat"></i> Update Cart</button>
        </form>
      </div>
      <div class="col-lg-4"><div class="admin-card">
        <h5 class="fw-bold">Order Summary</h5>
        <div class="d-flex justify-content-between py-2 border-bottom"><span>Subtotal</span><span><?= rupee($total) ?></span></div>
        <div class="d-flex justify-content-between py-2 border-bottom"><span>Shipping</span><span class="text-success">Free</span></div>
        <div class="d-flex justify-content-between py-2 border-bottom"><span>Payment</span><span class="badge-soft cod">COD</span></div>
        <div class="d-flex justify-content-between py-2 fw-bold fs-5"><span>Total</span><span id="grandTotal" style="color:var(--charcoal)"><?= rupee($total) ?></span></div>
        <?php if (is_logged_in()): ?><a href="<?= url('checkout.php') ?>" class="btn btn-grad w-100 btn-lg mt-3"><i class="bi bi-credit-card"></i> Checkout</a>
        <?php else: ?><a href="<?= url('login.php') ?>" class="btn btn-grad w-100 btn-lg mt-3">Login to Checkout</a><?php endif; ?>
        <a href="<?= url('shop.php') ?>" class="btn btn-outline-grad w-100 mt-2">Continue Shopping</a>
      </div></div>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
