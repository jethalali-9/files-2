<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'watchify');

// Site configuration
define('SITE_NAME', 'Watchify');
define('SITE_URL', 'http://localhost/watchify');
define('CURRENCY', '₹');

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection
function db() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            die('Database connection failed: ' . $conn->connect_error);
        }
        $conn->set_charset('utf8mb4');
    }
    return $conn;
}

// Security: sanitize input
function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Security: CSRF token
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify($token) {
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Auth helpers
function is_logged_in() {
    return !empty($_SESSION['user_id']);
}

function is_admin() {
    return !empty($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function require_admin() {
    if (!is_admin()) {
        header('Location: ../login.php');
        exit;
    }
}

// Format price in Indian Rupees
function format_price($price) {
    return CURRENCY . number_format($price, 2);
}

// Get all brands
function get_brands() {
    $result = db()->query("SELECT * FROM brands ORDER BY name");
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Get all categories
function get_categories() {
    $result = db()->query("SELECT * FROM categories ORDER BY name");
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Get products with optional filters
function get_products($brand_id = null, $category_id = null, $search = '', $limit = 0) {
    $sql = "SELECT p.*, b.name AS brand_name, c.name AS category_name
            FROM products p
            JOIN brands b ON p.brand_id = b.id
            JOIN categories c ON p.category_id = c.id
            WHERE 1=1";
    $params = [];
    $types = '';
    if ($brand_id) {
        $sql .= " AND p.brand_id = ?";
        $params[] = $brand_id;
        $types .= 'i';
    }
    if ($category_id) {
        $sql .= " AND p.category_id = ?";
        $params[] = $category_id;
        $types .= 'i';
    }
    if ($search) {
        $sql .= " AND p.name LIKE ?";
        $params[] = '%' . $search . '%';
        $types .= 's';
    }
    $sql .= " ORDER BY p.created_at DESC";
    if ($limit > 0) {
        $sql .= " LIMIT " . intval($limit);
    }
    $stmt = db()->prepare($sql);
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Get single product
function get_product($id) {
    $stmt = db()->prepare("SELECT p.*, b.name AS brand_name, c.name AS category_name
                           FROM products p
                           JOIN brands b ON p.brand_id = b.id
                           JOIN categories c ON p.category_id = c.id
                           WHERE p.id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Image upload handler
function upload_image($file, $old_image = '') {
    if (empty($file['name']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return $old_image;
    }
    $allowed = ['jpg','jpeg','png','gif','webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        return $old_image;
    }
    $new_name = 'watch_' . time() . '_' . rand(1000,9999) . '.' . $ext;
    $dest = __DIR__ . '/uploads/' . $new_name;
    if (!is_dir(__DIR__ . '/uploads')) {
        mkdir(__DIR__ . '/uploads', 0777, true);
    }
    if (move_uploaded_file($file['tmp_name'], $dest)) {
        if ($old_image && $old_image !== 'default.jpg' && file_exists(__DIR__ . '/uploads/' . $old_image)) {
            unlink(__DIR__ . '/uploads/' . $old_image);
        }
        return $new_name;
    }
    return $old_image;
}

// Image URL helper - returns placeholder if file missing
// DB stores names like "men_rolex_submariner.jpg" but actual files are .svg
function image_url($image) {
    if (!$image || $image === 'default.jpg') {
        return 'assets/img/placeholder.svg';
    }
    // try exact name
    $path = 'uploads/' . $image;
    if (file_exists(__DIR__ . '/' . $path)) {
        return $path;
    }
    // try .svg variant (strip extension, add .svg)
    $base = preg_replace('/\.(jpg|jpeg|png|gif|webp)$/i', '', $image);
    $svgPath = 'uploads/' . $base . '.svg';
    if (file_exists(__DIR__ . '/' . $svgPath)) {
        return $svgPath;
    }
    return 'assets/img/placeholder.svg';
}
