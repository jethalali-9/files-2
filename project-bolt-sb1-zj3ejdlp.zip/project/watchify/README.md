# Watchify - Watch Collection Website

A complete e-commerce watch collection website built with PHP, MySQL, Bootstrap 5, and custom CSS.

## Features

### Public Features
- **Home Page** - Hero banner, category showcase, latest products, brand listing
- **Brand Filter** - Browse watches by brand (Rolex, Titan, Fossil, Casio, etc.)
- **Category Filter** - Browse by Men, Women, Kids, Couple categories
- **Product Detail** - Full product info with quantity selector and live price update
- **About Us** - Company story and values
- **User Registration** - Name, Email, Phone (all required), Password
- **User Login** - Secure session-based authentication
- **User Profile** - Update name, phone, address, city, pincode, password
- **My Orders** - View order history with status tracking
- **Checkout** - Cash on Delivery with delivery details form
- **Logout** - Complete session destruction (must login again)

### Admin Panel (admin/)
- **Dashboard** - Stats: products, orders, users, revenue + recent orders
- **Products** - Full CRUD with photo upload (Choose File option), photo preview in list
- **Orders** - View all orders with user ID, name, phone, address, product, photo, amount, status; update status
- **Users** - View all registered users
- **Brands** - Add/delete brands

### Security
- Password hashing with `password_hash()` / `password_verify()`
- CSRF tokens on all forms
- Input sanitization with `htmlspecialchars()`
- Session-based auth with `session_regenerate_id()`
- Role-based access control (admin/user)
- Prepared statements (SQL injection prevention)

### Design
- Blue, black, white, gold color scheme
- Responsive design (mobile + desktop)
- Medium animations (hover effects, fade-in, pulse)
- Custom SVG logo and favicon
- Google Fonts (Playfair Display + Poppins)
- Bootstrap 5 + Bootstrap Icons
- 80 products (20 per category) with generated placeholder images

## Installation

1. **Copy the `watchify` folder to your web server** (XAMPP/WAMP/LAMP `htdocs` or `www`)

2. **Import the database**:
   - Open phpMyAdmin (http://localhost/phpmyadmin)
   - Click "Import"
   - Choose `watchify/database.sql`
   - Click "Go"

3. **Database config** (if needed, edit `config.php`):
   ```
   DB_HOST: localhost
   DB_USER: root
   DB_PASS: (your MySQL password, usually empty for XAMPP)
   DB_NAME: watchify
   ```

4. **Access the site**: http://localhost/watchify

## Admin Access
- **URL**: http://localhost/watchify/admin
- **Email**: admin@watchify.com
- **Password**: admin123

## Currency
All prices are displayed in Indian Rupees (₹).

## Payment
Cash on Delivery only.

## Tech Stack
- PHP 7.4+ (procedural with PDO-style prepared statements via mysqli)
- MySQL / MariaDB
- Bootstrap 5.3
- Custom CSS3
- Vanilla JavaScript

## File Structure
```
watchify/
├── config.php              # DB config + helper functions
├── database.sql            # Database schema + seed data
├── generate_placeholders.php # Image generator utility
├── index.php               # Home page
├── brand.php               # Brand filter page
├── category.php            # Category filter page
├── product.php             # Product detail page
├── about.php               # About us page
├── register.php            # User registration
├── login.php               # User login
├── logout.php              # Logout
├── profile.php             # Update profile
├── orders.php              # My orders
├── checkout.php            # Checkout (COD)
├── includes/
│   ├── header.php          # Shared header + navbar
│   └── footer.php          # Shared footer
├── admin/
│   ├── index.php           # Admin dashboard
│   ├── products.php       # Products CRUD + photo upload
│   ├── orders.php          # Orders management
│   ├── users.php           # Users list
│   ├── brands.php          # Brands management
│   └── includes/
│       ├── admin_header.php
│       └── admin_footer.php
├── assets/
│   ├── css/style.css       # Custom styles
│   └── img/
│       ├── logo.svg
│       ├── favicon.svg
│       └── placeholder.svg
└── uploads/                # Product images (generated)
```
