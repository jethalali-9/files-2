<?php
require_once __DIR__ . '/config.php';
$brands = get_brands();
$brand_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$brand_name = $brand_id ? db()->query("SELECT name FROM brands WHERE id=$brand_id")->fetch_assoc()['name'] : 'All Brands';
$products = get_products($brand_id ?: null, null, '', 0);

include __DIR__ . '/includes/header.php';
?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
      <h2 class="section-title text-start mb-0"><?= clean($brand_name) ?> Watches</h2>
      <p class="text-muted"><?= count($products) ?> products found</p>
    </div>
    <div class="d-flex gap-2">
      <select id="filterCat" class="form-select" onchange="applyFilter()">
        <option value="">All Categories</option>
        <?php foreach (get_categories() as $c): ?>
          <option value="cat<?= $c['id'] ?>"><?= clean($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
      <select id="sortBy" class="form-select" onchange="sortProducts()">
        <option value="">Sort By</option>
        <option value="price-low">Price: Low to High</option>
        <option value="price-high">Price: High to Low</option>
        <option value="name">Name A-Z</option>
      </select>
    </div>
  </div>

  <div class="row" id="productGrid">
    <?php foreach ($products as $p): ?>
      <div class="col-lg-3 col-md-6 product-item" data-cat="<?= $p['category_id'] ?>" data-price="<?= $p['price'] ?>" data-name="<?= strtolower(clean($p['name'])) ?>">
        <div class="product-card">
          <div class="img-wrap">
            <span class="badge-cat"><?= clean($p['category_name']) ?></span>
            <img src="<?= image_url($p['image']) ?>" alt="<?= clean($p['name']) ?>">
          </div>
          <div class="body">
            <h5><?= clean($p['name']) ?></h5>
            <div class="brand-name"><?= clean($p['brand_name']) ?></div>
            <div class="price"><?= format_price($p['price']) ?></div>
            <div class="actions">
              <a href="product.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-primary-custom w-100">View Details</a>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (!$products): ?>
      <div class="col-12 text-center py-5"><p class="text-muted">No products found for this brand.</p></div>
    <?php endif; ?>
  </div>
</div>

<script>
function applyFilter() {
  var c = document.getElementById('filterCat').value;
  document.querySelectorAll('.product-item').forEach(function(el) {
    var show = !c || el.dataset.cat === c.replace('cat','');
    el.style.display = show ? '' : 'none';
  });
}
function sortProducts() {
  var sort = document.getElementById('sortBy').value;
  var grid = document.getElementById('productGrid');
  var items = Array.from(grid.querySelectorAll('.product-item'));
  if (sort === 'price-low') items.sort((a,b)=> parseFloat(a.dataset.price) - parseFloat(b.dataset.price));
  else if (sort === 'price-high') items.sort((a,b)=> parseFloat(b.dataset.price) - parseFloat(a.dataset.price));
  else if (sort === 'name') items.sort((a,b)=> a.dataset.name.localeCompare(b.dataset.name));
  items.forEach(function(el) { grid.appendChild(el); });
}
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
