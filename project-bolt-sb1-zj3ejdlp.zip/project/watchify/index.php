<?php
require_once __DIR__ . '/config.php';
$brands = get_brands();
$categories = get_categories();
$latest = get_products(null, null, '', 8);
$featured = get_products(null, null, '', 4);

include __DIR__ . '/includes/header.php';
?>
<!-- Hero -->
<section class="hero">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-7">
        <h1>Timeless Elegance<br>On Your Wrist</h1>
        <p>Discover premium watches from world-renowned brands. Quality craftsmanship meets modern design at Watchify.</p>
        <a href="#products" class="btn btn-gold">Shop Collection <i class="bi bi-arrow-right"></i></a>
      </div>
      <div class="col-lg-5 text-center d-none d-lg-block">
        <img src="assets/img/favicon.svg" alt="Watchify" style="width:280px;filter:drop-shadow(0 10px 30px rgba(212,175,55,0.5));animation:pulse 3s infinite;">
      </div>
    </div>
  </div>
</section>

<!-- Categories -->
<section class="py-5">
  <div class="container">
    <h2 class="section-title">Shop by Category</h2>
    <p class="section-subtitle">Find the perfect watch for every occasion</p>
    <div class="row g-4">
      <?php foreach ($categories as $c): ?>
        <div class="col-md-3 col-sm-6">
          <a href="category.php?id=<?= $c['id'] ?>" class="text-decoration-none">
            <div class="cat-card">
              <img src="uploads/cat_<?= strtolower($c['name']) ?>.svg" alt="<?= clean($c['name']) ?>">
              <div class="overlay"><h4><?= clean($c['name']) ?> Watches</h4></div>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Latest Products -->
<section class="py-5" id="products" style="background:#fff;">
  <div class="container">
    <h2 class="section-title">Latest Collection</h2>
    <p class="section-subtitle">Explore our newest arrivals</p>

    <!-- Filter dropdown -->
    <div class="row mb-4">
      <div class="col-md-6 mx-auto">
        <div class="d-flex gap-2">
          <select id="filterBrand" class="form-select" onchange="applyFilter()">
            <option value="">All Brands</option>
            <?php foreach ($brands as $b): ?>
              <option value="brand<?= $b['id'] ?>"><?= clean($b['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <select id="filterCat" class="form-select" onchange="applyFilter()">
            <option value="">All Categories</option>
            <?php foreach ($categories as $c): ?>
              <option value="cat<?= $c['id'] ?>"><?= clean($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
    </div>

    <div class="row" id="productGrid">
      <?php foreach ($latest as $p): ?>
        <div class="col-lg-3 col-md-6 product-item" data-brand="<?= $p['brand_id'] ?>" data-cat="<?= $p['category_id'] ?>">
          <div class="product-card">
            <div class="img-wrap">
              <span class="badge-cat"><?= clean($p['category_name']) ?></span>
              <img src="<?= image_url($p['image']) ?>" alt="<?= clean($p['name']) ?>">
            </div>
            <div class="body">
              <h5><?= clean($p['name']) ?></h5>
              <div class="brand-name"><?= clean($p['brand_name']) ?></div>
              <div class="price"><?= format_price($p['price']) ?></div>
              <div class="actions">
                <a href="product.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-primary-custom w-100">View Details</a>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-4">
      <a href="brand.php" class="btn btn-gold">View All Products</a>
    </div>
  </div>
</section>

<!-- Brands strip -->
<section class="py-5">
  <div class="container">
    <h2 class="section-title">Our Brands</h2>
    <p class="section-subtitle">Trusted by watch lovers worldwide</p>
    <div class="row g-3">
      <?php foreach ($brands as $b): ?>
        <div class="col-md-2 col-sm-4 col-6">
          <a href="brand.php?id=<?= $b['id'] ?>" class="text-decoration-none">
            <div class="text-center p-3 bg-white rounded shadow-sm" style="transition:all .3s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
              <div style="font-family:'Playfair Display',serif;font-size:1.1rem;color:#1a3a5c;font-weight:700;"><?= clean($b['name']) ?></div>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<script>
function applyFilter() {
  var b = document.getElementById('filterBrand').value;
  var c = document.getElementById('filterCat').value;
  var items = document.querySelectorAll('.product-item');
  items.forEach(function(el) {
    var show = true;
    if (b && el.dataset.brand !== b.replace('brand','')) show = false;
    if (c && el.dataset.cat !== c.replace('cat','')) show = false;
    el.style.display = show ? '' : 'none';
  });
}
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
