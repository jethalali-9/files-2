<?php
require_once __DIR__ . '/includes/admin_header.php';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $msg = '<div class="alert alert-danger">Invalid session.</div>';
    } else {
        $order_id = intval($_POST['order_id']);
        $status = clean($_POST['status']);
        $stmt = db()->prepare("UPDATE orders SET status=? WHERE id=?");
        $stmt->bind_param('si', $status, $order_id);
        if ($stmt->execute()) {
            $msg = '<div class="alert alert-success">Order status updated.</div>';
        }
    }
}

$orders = db()->query("SELECT * FROM orders ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>
<?php if ($msg) echo $msg; ?>
<div class="table-card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Order ID</th>
          <th>User ID</th>
          <th>Name</th>
          <th>Phone</th>
          <th>Address</th>
          <th>Product</th>
          <th>Photo</th>
          <th>Qty</th>
          <th>Amount</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
          <tr>
            <td><strong>#<?= $o['id'] ?></strong></td>
            <td><?= $o['user_id'] ?></td>
            <td><?= clean($o['user_name']) ?></td>
            <td><?= clean($o['user_phone']) ?></td>
            <td style="max-width:180px;"><?= clean($o['user_address']) ?></td>
            <td><?= clean($o['product_name']) ?></td>
            <td><img src="<?= image_url($o['product_image']) ?>" alt="" style="width:50px;height:50px;border-radius:8px;object-fit:cover;"></td>
            <td><?= $o['quantity'] ?></td>
            <td><?= format_price($o['amount']) ?></td>
            <td><span class="status-badge status-<?= clean($o['status']) ?>"><?= clean($o['status']) ?></span></td>
            <td>
              <form method="POST" action="" class="d-flex gap-1">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                <select name="status" class="form-select form-select-sm" style="width:auto;" onchange="this.form.submit()">
                  <option value="Pending" <?= $o['status']==='Pending'?'selected':'' ?>>Pending</option>
                  <option value="Processing" <?= $o['status']==='Processing'?'selected':'' ?>>Processing</option>
                  <option value="Shipped" <?= $o['status']==='Shipped'?'selected':'' ?>>Shipped</option>
                  <option value="Delivered" <?= $o['status']==='Delivered'?'selected':'' ?>>Delivered</option>
                  <option value="Cancelled" <?= $o['status']==='Cancelled'?'selected':'' ?>>Cancelled</option>
                </select>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$orders): ?><tr><td colspan="11" class="text-center text-muted py-4">No orders yet</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
