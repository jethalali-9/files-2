<?php
require_once __DIR__ . '/includes/admin_header.php';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $msg = '<div class="alert alert-danger">Invalid session.</div>';
    } else {
        $name = clean($_POST['name']);
        $stmt = db()->prepare("INSERT INTO brands (name) VALUES (?)");
        $stmt->bind_param('s', $name);
        if ($stmt->execute()) {
            $msg = '<div class="alert alert-success">Brand added.</div>';
        }
    }
}
if (isset($_GET['delete'])) {
    $del = intval($_GET['delete']);
    db()->query("DELETE FROM brands WHERE id=$del");
    $msg = '<div class="alert alert-success">Brand deleted.</div>';
}
$brands = get_brands();
?>
<?php if ($msg) echo $msg; ?>
<div class="row g-4">
  <div class="col-md-4">
    <div class="admin-card">
      <h5>Add Brand</h5>
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        <div class="mb-3">
          <label class="form-label">Brand Name</label>
          <input type="text" name="name" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary-custom w-100">Add Brand</button>
      </form>
    </div>
  </div>
  <div class="col-md-8">
    <div class="table-card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr><th>ID</th><th>Brand Name</th><th>Products</th><th>Action</th></tr></thead>
          <tbody>
            <?php foreach ($brands as $b): ?>
              <?php $cnt = db()->query("SELECT COUNT(*) c FROM products WHERE brand_id=".$b['id'])->fetch_assoc()['c']; ?>
              <tr>
                <td><?= $b['id'] ?></td>
                <td><?= clean($b['name']) ?></td>
                <td><?= $cnt ?></td>
                <td><a href="?delete=<?= $b['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete brand?')"><i class="bi bi-trash"></i></a></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
