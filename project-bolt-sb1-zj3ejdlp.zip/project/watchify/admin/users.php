<?php
require_once __DIR__ . '/includes/admin_header.php';
$users = db()->query("SELECT * FROM users ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>
<div class="table-card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Role</th><th>Joined</th></tr></thead>
      <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td><?= clean($u['name']) ?></td>
            <td><?= clean($u['email']) ?></td>
            <td><?= clean($u['phone']) ?></td>
            <td style="max-width:200px;"><?= clean($u['address'] ?? '-') ?></td>
            <td><span class="badge <?= $u['role']==='admin'?'bg-danger':'bg-primary' ?>"><?= clean($u['role']) ?></span></td>
            <td class="small text-muted"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
