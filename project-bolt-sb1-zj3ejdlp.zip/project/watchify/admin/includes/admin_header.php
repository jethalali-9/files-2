<?php
require_once __DIR__ . '/../config.php';
require_admin();
$page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> Admin - <?= ucfirst($page) ?></title>
    <link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body style="background:#f0f2f5;">
<div class="admin-sidebar">
  <div class="brand-admin"><img src="../assets/img/favicon.svg" alt="" height="28"> Watchify</div>
  <a href="index.php" class="<?= $page==='index'?'active':'' ?>"><i class="bi bi-speedometer2"></i> Dashboard</a>
  <a href="products.php" class="<?= $page==='products'?'active':'' ?>"><i class="bi bi-box-seam"></i> Products</a>
  <a href="orders.php" class="<?= $page==='orders'?'active':'' ?>"><i class="bi bi-bag-check"></i> Orders</a>
  <a href="users.php" class="<?= $page==='users'?'active':'' ?>"><i class="bi bi-people"></i> Users</a>
  <a href="brands.php" class="<?= $page==='brands'?'active':'' ?>"><i class="bi bi-tags"></i> Brands</a>
  <a href="../index.php"><i class="bi bi-shop"></i> View Site</a>
  <a href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>
<div class="admin-content">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h3 style="font-family:'Playfair Display',serif;color:#1a3a5c;margin:0;"><?= ucfirst($page) ?></h3>
    <span class="text-muted">Welcome, <?= clean($_SESSION['name']) ?></span>
  </div>
