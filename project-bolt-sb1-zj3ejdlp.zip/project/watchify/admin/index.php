<?php
require_once __DIR__ . '/includes/admin_header.php';

$total_products = db()->query("SELECT COUNT(*) AS c FROM products")->fetch_assoc()['c'];
$total_orders = db()->query("SELECT COUNT(*) AS c FROM orders")->fetch_assoc()['c'];
$total_users = db()->query("SELECT COUNT(*) AS c FROM users WHERE role='user'")->fetch_assoc()['c'];
$total_revenue = db()->query("SELECT COALESCE(SUM(amount),0) AS s FROM orders")->fetch_assoc()['s'];
$pending = db()->query("SELECT COUNT(*) AS c FROM orders WHERE status='Pending'")->fetch_assoc()['c'];
$recent = db()->query("SELECT o.*, u.email FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
?>
<div class="row g-3 mb-4">
  <div class="col-md-3 col-sm-6">
    <div class="stat-card" style="background:linear-gradient(135deg,#1a3a5c,#2c5282);">
      <div class="d-flex justify-content-between">
        <div><div class="stat-num"><?= $total_products ?></div><div class="stat-label">Products</div></div>
        <i class="bi bi-box-seam stat-icon"></i>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card" style="background:linear-gradient(135deg,#d4af37,#b8941f);">
      <div class="d-flex justify-content-between">
        <div><div class="stat-num"><?= $total_orders ?></div><div class="stat-label">Orders</div></div>
        <i class="bi bi-bag-check stat-icon"></i>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card" style="background:linear-gradient(135deg,#28a745,#1e7e34);">
      <div class="d-flex justify-content-between">
        <div><div class="stat-num"><?= $total_users ?></div><div class="stat-label">Users</div></div>
        <i class="bi bi-people stat-icon"></i>
      </div>
    </div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card" style="background:linear-gradient(135deg,#9b2c5f,#702459);">
      <div class="d-flex justify-content-between">
        <div><div class="stat-num"><?= format_price($total_revenue) ?></div><div class="stat-label">Revenue</div></div>
        <i class="bi bi-currency-rupee stat-icon"></i>
      </div>
    </div>
  </div>
</div>

<div class="admin-card">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Recent Orders</h5>
    <a href="orders.php" class="btn btn-sm btn-primary-custom">View All</a>
  </div>
  <div class="table-responsive">
    <table class="table table-hover">
      <thead><tr><th>ID</th><th>User</th><th>Product</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        <?php foreach ($recent as $o): ?>
          <tr>
            <td>#<?= $o['id'] ?></td>
            <td><?= clean($o['user_name']) ?><br><small class="text-muted"><?= clean($o['email']) ?></small></td>
            <td><?= clean($o['product_name']) ?></td>
            <td><?= format_price($o['amount']) ?></td>
            <td><span class="status-badge status-<?= clean($o['status']) ?>"><?= clean($o['status']) ?></span></td>
            <td class="small text-muted"><?= date('d M Y', strtotime($o['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$recent): ?><tr><td colspan="6" class="text-center text-muted py-3">No orders yet</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="alert alert-info">
  <i class="bi bi-info-circle"></i> <?= $pending ?> order(s) pending. <a href="orders.php">Review now</a>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
