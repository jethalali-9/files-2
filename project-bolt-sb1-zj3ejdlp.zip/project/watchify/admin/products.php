<?php
require_once __DIR__ . '/includes/admin_header.php';
$brands = get_brands();
$categories = get_categories();

$action = $_GET['action'] ?? 'list';
$edit_id = intval($_GET['edit'] ?? 0);
$msg = '';

// Handle save (add/edit)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $msg = '<div class="alert alert-danger">Invalid session.</div>';
    } else {
        $name = clean($_POST['name']);
        $brand_id = intval($_POST['brand_id']);
        $category_id = intval($_POST['category_id']);
        $price = floatval($_POST['price']);
        $desc = clean($_POST['description']);
        $stock = intval($_POST['stock']);
        $old_image = $_POST['old_image'] ?? '';
        $image = upload_image($_FILES['image'] ?? [], $old_image);

        $edit_id = intval($_POST['id'] ?? 0);
        if ($edit_id) {
            $stmt = db()->prepare("UPDATE products SET name=?, brand_id=?, category_id=?, price=?, description=?, image=?, stock=? WHERE id=?");
            $stmt->bind_param('siidssii', $name, $brand_id, $category_id, $price, $desc, $image, $stock, $edit_id);
        } else {
            $stmt = db()->prepare("INSERT INTO products (name, brand_id, category_id, price, description, image, stock) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param('siidssi', $name, $brand_id, $category_id, $price, $desc, $image, $stock);
        }
        if ($stmt->execute()) {
            $msg = '<div class="alert alert-success">Product saved successfully.</div>';
            $action = 'list';
        } else {
            $msg = '<div class="alert alert-danger">Error: ' . $stmt->error . '</div>';
        }
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $del_id = intval($_GET['delete']);
    $prod = get_product($del_id);
    if ($prod && $prod['image'] && $prod['image'] !== 'default.jpg' && file_exists(__DIR__.'/../uploads/'.$prod['image'])) {
        unlink(__DIR__.'/../uploads/'.$prod['image']);
    }
    db()->query("DELETE FROM products WHERE id=$del_id");
    $msg = '<div class="alert alert-success">Product deleted.</div>';
    $action = 'list';
}

// Edit form data
$edit_product = null;
if ($action === 'edit' && $edit_id) {
    $edit_product = get_product($edit_id);
}

// List products
$products = get_products(null, null, '', 0);
?>

<?php if ($msg) echo $msg; ?>

<?php if ($action === 'add' || $action === 'edit'): ?>
  <div class="admin-card">
    <h5><?= $action === 'edit' ? 'Edit Product' : 'Add New Product' ?></h5>
    <form method="POST" action="" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <input type="hidden" name="id" value="<?= $edit_product['id'] ?? 0 ?>">
      <input type="hidden" name="old_image" value="<?= $edit_product['image'] ?? '' ?>">
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">Product Name</label>
          <input type="text" name="name" class="form-control" value="<?= clean($edit_product['name'] ?? '') ?>" required>
        </div>
        <div class="col-md-3 mb-3">
          <label class="form-label">Brand</label>
          <select name="brand_id" class="form-select" required>
            <?php foreach ($brands as $b): ?>
              <option value="<?= $b['id'] ?>" <?= ($edit_product['brand_id'] ?? 0)==$b['id']?'selected':'' ?>><?= clean($b['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3 mb-3">
          <label class="form-label">Category</label>
          <select name="category_id" class="form-select" required>
            <?php foreach ($categories as $c): ?>
              <option value="<?= $c['id'] ?>" <?= ($edit_product['category_id'] ?? 0)==$c['id']?'selected':'' ?>><?= clean($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3 mb-3">
          <label class="form-label">Price (₹)</label>
          <input type="number" step="0.01" name="price" class="form-control" value="<?= $edit_product['price'] ?? '' ?>" required>
        </div>
        <div class="col-md-3 mb-3">
          <label class="form-label">Stock</label>
          <input type="number" name="stock" class="form-control" value="<?= $edit_product['stock'] ?? 10 ?>">
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Product Photo</label>
          <input type="file" name="image" class="form-control" accept="image/*">
          <?php if (!empty($edit_product['image'])): ?>
            <div class="mt-2 d-flex align-items-center gap-2">
              <img src="<?= image_url($edit_product['image']) ?>" alt="" style="width:60px;height:60px;border-radius:8px;object-fit:cover;">
              <span class="small text-muted">Current: <?= clean($edit_product['image']) ?></span>
            </div>
          <?php endif; ?>
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control" rows="3"><?= clean($edit_product['description'] ?? '') ?></textarea>
      </div>
      <button type="submit" class="btn btn-primary-custom">Save Product</button>
      <a href="products.php" class="btn btn-secondary">Cancel</a>
    </form>
  </div>
<?php else: ?>
  <div class="d-flex justify-content-between mb-3">
    <h5 class="mb-0">All Products (<?= count($products) ?>)</h5>
    <a href="?action=add" class="btn btn-primary-custom"><i class="bi bi-plus-lg"></i> Add Product</a>
  </div>
  <div class="table-card">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead>
          <tr><th>ID</th><th>Photo</th><th>Name</th><th>Brand</th><th>Category</th><th>Price</th><th>Stock</th><th>Action</th></tr>
        </thead>
        <tbody>
          <?php foreach ($products as $p): ?>
            <tr>
              <td><?= $p['id'] ?></td>
              <td><img src="<?= image_url($p['image']) ?>" alt="" style="width:50px;height:50px;border-radius:8px;object-fit:cover;"></td>
              <td><?= clean($p['name']) ?></td>
              <td><?= clean($p['brand_name']) ?></td>
              <td><?= clean($p['category_name']) ?></td>
              <td><?= format_price($p['price']) ?></td>
              <td><?= $p['stock'] ?></td>
              <td>
                <a href="?action=edit&edit=<?= $p['id'] ?>" class="btn btn-sm btn-warning"><i class="bi bi-pencil"></i></a>
                <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product?')"><i class="bi bi-trash"></i></a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
