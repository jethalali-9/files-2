<?php
require_once __DIR__ . '/config.php';
require_login();

$stmt = db()->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include __DIR__ . '/includes/header.php';
?>
<div class="container py-5">
  <h2 class="section-title">My Orders</h2>
  <p class="section-subtitle">Track your orders and status</p>

  <?php if (empty($orders)): ?>
    <div class="text-center py-5">
      <i class="bi bi-bag" style="font-size:4rem;color:#ccc;"></i>
      <h4 class="mt-3 text-muted">No orders yet</h4>
      <p>Start shopping to see your orders here.</p>
      <a href="index.php" class="btn btn-gold">Shop Now</a>
    </div>
  <?php else: ?>
    <div class="table-card">
      <div class="table-responsive">
        <table class="table table-hover mb-0 align-middle">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Product</th>
              <th>Qty</th>
              <th>Amount</th>
              <th>Payment</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $o): ?>
              <tr>
                <td><strong>#<?= $o['id'] ?></strong></td>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <img src="<?= image_url($o['product_image']) ?>" alt="" style="width:50px;height:50px;border-radius:8px;object-fit:cover;">
                    <span><?= clean($o['product_name']) ?></span>
                  </div>
                </td>
                <td><?= $o['quantity'] ?></td>
                <td><strong><?= format_price($o['amount']) ?></strong></td>
                <td><span class="badge bg-warning text-dark"><?= clean($o['payment_method']) ?></span></td>
                <td><span class="status-badge status-<?= clean($o['status']) ?>"><?= clean($o['status']) ?></span></td>
                <td class="small text-muted"><?= date('d M Y', strtotime($o['created_at'])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
