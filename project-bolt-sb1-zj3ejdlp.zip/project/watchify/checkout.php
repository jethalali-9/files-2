<?php
require_once __DIR__ . '/config.php';
require_login();

$pid = intval($_GET['pid'] ?? 0);
$qty = max(1, intval($_GET['qty'] ?? 1));
$product = get_product($pid);

if (!$product) {
    header('Location: index.php');
    exit;
}

// Fetch user details
$stmt = db()->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid session. Please try again.';
    } else {
        $name = clean($_POST['name']);
        $phone = clean($_POST['phone']);
        $address = clean($_POST['address']);
        $quantity = max(1, intval($_POST['quantity']));
        $amount = $product['price'] * $quantity;

        if ($name && $phone && $address) {
            $stmt = db()->prepare("INSERT INTO orders (user_id, user_name, user_phone, user_address, product_id, product_name, product_image, quantity, amount, payment_method, status) VALUES (?,?,?,?,?,?,?,?,?,'Cash on Delivery','Pending')");
            $stmt->bind_param('issssisds', $_SESSION['user_id'], $name, $phone, $address, $pid, $product['name'], $product['image'], $quantity, $amount);
            if ($stmt->execute()) {
                $order_id = $stmt->insert_id;
                $success = $order_id;
            } else {
                $error = 'Order failed. Please try again.';
            }
        } else {
            $error = 'All fields are required.';
        }
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="container py-5">
  <h2 class="section-title">Checkout</h2>
  <p class="section-subtitle">Complete your order - Cash on Delivery</p>

  <?php if ($success): ?>
    <div class="alert alert-success text-center" style="max-width:600px;margin:0 auto;">
      <h4><i class="bi bi-check-circle-fill text-success"></i> Order Placed Successfully!</h4>
      <p>Your order ID is <strong>#<?= $success ?></strong></p>
      <p>Pay <?= format_price($product['price'] * $qty) ?> on delivery.</p>
      <a href="orders.php" class="btn btn-primary-custom">View My Orders</a>
      <a href="index.php" class="btn btn-gold">Continue Shopping</a>
    </div>
  <?php else: ?>
    <div class="row g-4 justify-content-center">
      <div class="col-lg-5">
        <div class="admin-card">
          <h5 class="mb-3">Product Summary</h5>
          <div class="d-flex gap-3">
            <img src="<?= image_url($product['image']) ?>" alt="" style="width:100px;height:100px;border-radius:10px;object-fit:cover;">
            <div>
              <h6><?= clean($product['name']) ?></h6>
              <p class="text-muted small"><?= clean($product['brand_name']) ?> - <?= clean($product['category_name']) ?></p>
              <p class="mb-0"><strong><?= format_price($product['price']) ?></strong></p>
            </div>
          </div>
          <hr>
          <div class="d-flex justify-content-between">
            <span>Quantity:</span>
            <strong id="qtyDisplay"><?= $qty ?></strong>
          </div>
          <div class="d-flex justify-content-between mt-2">
            <span>Total Amount:</span>
            <strong style="color:#1a3a5c;font-size:1.2rem;" id="totalDisplay"><?= format_price($product['price'] * $qty) ?></strong>
          </div>
          <div class="mt-2"><span class="badge bg-warning text-dark"><i class="bi bi-cash"></i> Cash on Delivery</span></div>
        </div>
      </div>

      <div class="col-lg-5">
        <div class="admin-card">
          <h5 class="mb-3">Delivery Details</h5>
          <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
          <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="quantity" value="<?= $qty ?>" id="qtyInput">
            <div class="mb-3">
              <label class="form-label">Full Name</label>
              <input type="text" name="name" class="form-control" value="<?= clean($user['name']) ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Phone Number</label>
              <input type="text" name="phone" class="form-control" value="<?= clean($user['phone']) ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Delivery Address</label>
              <textarea name="address" class="form-control" rows="3" required><?= clean($user['address'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="btn btn-gold w-100">Place Order</button>
          </form>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
