-- Watchify Database Schema
-- Import this file in phpMyAdmin / MySQL

CREATE DATABASE IF NOT EXISTS watchify CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE watchify;

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  password VARCHAR(255) NOT NULL,
  address TEXT,
  city VARCHAR(80),
  pincode VARCHAR(20),
  role ENUM('user','admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Brands table
CREATE TABLE IF NOT EXISTS brands (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  brand_id INT NOT NULL,
  category_id INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  description TEXT,
  image VARCHAR(255) DEFAULT 'default.jpg',
  stock INT DEFAULT 10,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  user_name VARCHAR(100) NOT NULL,
  user_phone VARCHAR(20) NOT NULL,
  user_address TEXT NOT NULL,
  product_id INT NOT NULL,
  product_name VARCHAR(150) NOT NULL,
  product_image VARCHAR(255),
  quantity INT NOT NULL DEFAULT 1,
  amount DECIMAL(10,2) NOT NULL,
  payment_method VARCHAR(50) DEFAULT 'Cash on Delivery',
  status VARCHAR(50) DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Admin user (password: admin123)
INSERT INTO users (name, email, phone, password, role) VALUES
('Admin','admin@watchify.com','9876543210','$2y$12$hlH9AvZL95HvB.X7KqjgmeOHhZQjx0PVpHBeoMqvWY.0uGAKtYwbS','admin');

-- Brands
INSERT INTO brands (name) VALUES
('Rolex'),('Titan'),('Fossil'),('Casio'),('Timex'),('Omega'),('Seiko'),('Sonata'),('Maxima'),('Daniel Wellington');

-- Categories
INSERT INTO categories (name) VALUES
('Men'),('Women'),('Kids'),('Couple');

-- Products: 20 per category = 80 products
-- Using placeholder image names; admin can upload real photos later
INSERT INTO products (name, brand_id, category_id, price, description, image, stock) VALUES
-- Men (category_id=1)
('Rolex Submariner Men',1,1,125000.00,'Luxury automatic dive watch with stainless steel case.','men_rolex_submariner.jpg',8),
('Titan Neo Men',2,1,4500.00,'Elegant analog watch with leather strap.','men_titan_neo.jpg',15),
('Fossil Grant Men',3,1,8500.00,'Chronograph with brown leather strap.','men_fossil_grant.jpg',12),
('Casio G-Shock Men',4,1,6500.00,'Rugged sports watch with digital display.','men_casio_gshock.jpg',20),
('Timex Expedition Men',5,1,3500.00,'Outdoor watch with durable build.','men_timex_expedition.jpg',18),
('Omega Seamaster Men',6,1,95000.00,'Premium automatic luxury watch.','men_omega_seamaster.jpg',5),
('Seiko 5 Sports Men',7,1,12000.00,'Automatic sports watch with steel strap.','men_seiko_5.jpg',10),
('Sonata SF Men',8,1,1800.00,'Affordable everyday analog watch.','men_sonata_sf.jpg',25),
('Maxima Max Men',9,1,1500.00,'Simple and stylish daily wear watch.','men_maxima_max.jpg',22),
('Daniel Wellington Men',10,1,15000.00,'Minimalist design with mesh strap.','men_dw_classic.jpg',7),
('Rolex Daytona Men',1,1,150000.00,'Racing chronograph luxury watch.','men_rolex_daytona.jpg',4),
('Titan Edge Men',2,1,6500.00,'Slim profile leather strap watch.','men_titan_edge.jpg',14),
('Fossil Townsman Men',3,1,9500.00,'Automatic with exhibition caseback.','men_fossil_townsman.jpg',11),
('Casio Edifice Men',4,1,7500.00,'Chronograph steel band watch.','men_casio_edifice.jpg',16),
('Timex Ironman Men',5,1,4200.00,'Digital sports with timer.','men_timex_ironman.jpg',19),
('Omega Speedmaster Men',6,1,110000.00,'Iconic moonwatch chronograph.','men_omega_speedmaster.jpg',3),
('Seiko Presage Men',7,1,18000.00,'Elegant dress automatic watch.','men_seiko_presage.jpg',9),
('Sonata Classic Men',8,1,2200.00,'Classic round dial analog watch.','men_sonata_classic.jpg',24),
('Maxima Attivo Men',9,1,2800.00,'Sporty silicone strap watch.','men_maxima_attivo.jpg',21),
('Daniel Walker Men',10,1,12000.00,'Brown leather vintage style watch.','men_dw_walker.jpg',8),

-- Women (category_id=2)
('Rolex Datejust Women',1,2,135000.00,'Elegant gold-tone luxury watch.','women_rolex_datejust.jpg',6),
('Titan Raga Women',2,2,5500.00,'Beautiful mother-of-pearl dial.','women_titan_raga.jpg',13),
('Fossil Riley Women',3,2,7800.00,'Rose gold bracelet watch.','women_fossil_riley.jpg',12),
('Casio Sheen Women',4,2,6200.00,'Crystal-studded elegant watch.','women_casio_sheen.jpg',17),
('Timex Easy Reader Women',5,2,2800.00,'Simple classic analog watch.','women_timex_easy.jpg',20),
('Omega Constellation Women',6,2,105000.00,'Diamond bezel luxury watch.','women_omega_const.jpg',4),
('Seiko Presage Women',7,2,16000.00,'Automatic with floral dial.','women_seiko_presage.jpg',8),
('Sonata Silver Women',8,2,1600.00,'Silver tone elegant watch.','women_sonata_silver.jpg',23),
('Maxima Femina Women',9,2,1900.00,'Slim dress watch for women.','women_maxima_femina.jpg',21),
('Daniel Wellington Petite Women',10,2,14000.00,'Minimalist rose gold watch.','women_dw_petite.jpg',7),
('Rolex Pearlmaster Women',1,2,145000.00,'Premium diamond-set watch.','women_rolex_pearl.jpg',3),
('Titan Nebula Women',2,2,7500.00,'Gold plated luxury watch.','women_titan_nebula.jpg',10),
('Fossil Caroline Women',3,2,8200.00,'Elegant mesh strap watch.','women_fossil_caroline.jpg',11),
('Casio Baby-G Women',4,2,5500.00,'Sporty shock resistant watch.','women_casio_babyg.jpg',18),
('Timex Weekender Women',5,2,2500.00,'Casual interchangeable strap.','women_timex_weekender.jpg',22),
('Omega De Ville Women',6,2,98000.00,'Classic dress luxury watch.','women_omega_deville.jpg',5),
('Seiko Supria Women',7,2,14000.00,'Slim elegant daily wear.','women_seiko_supria.jpg',9),
('Sonata Delight Women',8,2,2000.00,'Colorful dial fashion watch.','women_sonata_delight.jpg',24),
('Maxima Elegance Women',9,2,2300.00,'Crystal accent bracelet watch.','women_maxima_elegance.jpg',20),
('Daniel Wellington Iconic Women',10,2,16000.00,'Iconic link bracelet watch.','women_dw_iconic.jpg',6),

-- Kids (category_id=3)
('Casio Kids Digital',4,3,1200.00,'Fun colorful digital watch for kids.','kids_casio_digital.jpg',30),
('Timex Kids Time Machines',5,3,950.00,'Easy to read learning watch.','kids_timex_time.jpg',28),
('Sonata Kids Fun',8,3,700.00,'Bright color strap kids watch.','kids_sonata_fun.jpg',35),
('Maxima Kids Sport',9,3,650.00,'Durable silicone kids watch.','kids_maxima_sport.jpg',32),
('Titan Kids Star',2,3,1500.00,'Stylish analog kids watch.','kids_titan_star.jpg',25),
('Fossil Kids Explorer',3,3,2800.00,'Adventure style kids watch.','kids_fossil_explorer.jpg',18),
('Casio Kids Light',4,3,1100.00,'LED backlight kids watch.','kids_casio_light.jpg',30),
('Timex Kids Ironman',5,3,1300.00,'Sports timer kids watch.','kids_timex_ironman.jpg',26),
('Sonata Kids Cute',8,3,800.00,'Cartoon print kids watch.','kids_sonata_cute.jpg',33),
('Maxima Kids Joy',9,3,750.00,'Vibrant color kids watch.','kids_maxima_joy.jpg',31),
('Titan Kids Neo',2,3,1700.00,'Modern design kids watch.','kids_titan_neo.jpg',24),
('Fossil Kids Junior',3,3,2600.00,'Mini version explorer watch.','kids_fossil_junior.jpg',17),
('Casio Kids Sport',4,3,1400.00,'Water resistant kids watch.','kids_casio_sport.jpg',29),
('Timex Kids Scout',5,3,1050.00,'Outdoor adventure kids watch.','kids_timex_scout.jpg',27),
('Sonata Kids Play',8,3,900.00,'Playful design kids watch.','kids_sonata_play.jpg',34),
('Maxima Kids Active',9,3,850.00,'Active sporty kids watch.','kids_maxima_active.jpg',30),
('Titan Kids Edge',2,3,1900.00,'Slim profile kids watch.','kids_titan_edge.jpg',23),
('Fossil Kids Heritage',3,3,3000.00,'Classic style kids watch.','kids_fossil_heritage.jpg',16),
('Casio Kids Frogman',4,3,1600.00,'Dive style fun kids watch.','kids_casio_frogman.jpg',28),
('Timex Kids TimeX',5,3,1150.00,'Basic learning kids watch.','kids_timex_timex.jpg',26),

-- Couple (category_id=4)
('Titan Couple Set',2,4,9500.00,'Matching his and hers couple watches.','couple_titan_set.jpg',12),
('Fossil Couple Pack',3,4,16000.00,'Elegant couple watch set.','couple_fossil_pack.jpg',10),
('Casio Couple Duo',4,4,12000.00,'Sporty couple watch pair.','couple_casio_duo.jpg',11),
('Timex Couple Bond',5,4,6500.00,'Classic couple watch set.','couple_timex_bond.jpg',15),
('Sonata Couple Love',8,4,3500.00,'Affordable couple watch pair.','couple_sonata_love.jpg',20),
('Maxima Couple Twin',9,4,3200.00,'Stylish couple combo watches.','couple_maxima_twin.jpg',18),
('Daniel Wellington Couple Set',10,4,28000.00,'Premium minimalist couple set.','couple_dw_set.jpg',6),
('Seiko Couple Pair',7,4,30000.00,'Automatic couple watch pair.','couple_seiko_pair.jpg',5),
('Omega Couple Classic',6,4,180000.00,'Luxury couple watch set.','couple_omega_classic.jpg',3),
('Rolex Couple Royal',1,4,250000.00,'Premium royal couple set.','couple_rolex_royal.jpg',2),
('Titan Couple Neo',2,4,10500.00,'Modern couple watch set.','couple_titan_neo.jpg',11),
('Fossil Couple Gen',3,4,17000.00,'Trendy couple watch pair.','couple_fossil_gen.jpg',9),
('Casio Couple Steel',4,4,13000.00,'Steel band couple watches.','couple_casio_steel.jpg',10),
('Timex Couple Classic',5,4,7000.00,'Timeless couple watch set.','couple_timex_classic.jpg',14),
('Sonata Couple Joy',8,4,3800.00,'Budget couple watch pair.','couple_sonata_joy.jpg',19),
('Maxima Couple Bond',9,4,3400.00,'Matching couple watches.','couple_maxima_bond.jpg',17),
('Daniel Wellington Couple Iconic',10,4,30000.00,'Iconic couple watch set.','couple_dw_iconic.jpg',5),
('Seiko Couple Elegance',7,4,32000.00,'Elegant couple watch pair.','couple_seiko_elegance.jpg',4),
('Omega Couple Prestige',6,4,190000.00,'Prestige luxury couple set.','couple_omega_prestige.jpg',2),
('Rolex Couple Diamond',1,4,275000.00,'Diamond accent couple set.','couple_rolex_diamond.jpg',1);
