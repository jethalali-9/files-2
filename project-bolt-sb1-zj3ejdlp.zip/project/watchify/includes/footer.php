<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 mb-4">
        <h5><img src="assets/img/favicon.svg" alt="" height="30"> <?= SITE_NAME ?></h5>
        <p>Your premier destination for premium watches. We bring you the finest timepieces from world-renowned brands.</p>
      </div>
      <div class="col-lg-2 mb-4">
        <h5>Quick Links</h5>
        <ul class="list-unstyled">
          <li class="mb-2"><a href="index.php">Home</a></li>
          <li class="mb-2"><a href="about.php">About Us</a></li>
          <li class="mb-2"><a href="login.php">Login</a></li>
          <li class="mb-2"><a href="register.php">Register</a></li>
        </ul>
      </div>
      <div class="col-lg-3 mb-4">
        <h5>Categories</h5>
        <ul class="list-unstyled">
          <li class="mb-2"><a href="category.php?id=1">Men Watches</a></li>
          <li class="mb-2"><a href="category.php?id=2">Women Watches</a></li>
          <li class="mb-2"><a href="category.php?id=3">Kids Watches</a></li>
          <li class="mb-2"><a href="category.php?id=4">Couple Watches</a></li>
        </ul>
      </div>
      <div class="col-lg-3 mb-4">
        <h5>Contact</h5>
        <p><i class="bi bi-geo-alt"></i> 123 Watch Street, Mumbai, India</p>
        <p><i class="bi bi-telephone"></i> +91 98765 43210</p>
        <p><i class="bi bi-envelope"></i> info@watchify.com</p>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p>
    </div>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Navbar scroll effect
window.addEventListener('scroll', function() {
  var nav = document.getElementById('mainNav');
  if (window.scrollY > 50) nav.classList.add('scrolled');
  else nav.classList.remove('scrolled');
});
</script>
</body>
</html>
