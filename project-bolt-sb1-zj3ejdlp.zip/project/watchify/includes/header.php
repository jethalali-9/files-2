<?php
require_once __DIR__ . '/config.php';
$brands = get_brands();
$categories = get_categories();
$page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> - Premium Watch Collection</title>
    <link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <span class="logo-mark"><img src="assets/img/favicon.svg" alt=""><?= SITE_NAME ?></span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link <?= $page==='index'?'active':'' ?>" href="index.php">Home</a></li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?= $page==='brand'?'active':'' ?>" href="#" data-bs-toggle="dropdown">Brand</a>
          <ul class="dropdown-menu">
            <?php foreach ($brands as $b): ?>
              <li><a class="dropdown-item" href="brand.php?id=<?= $b['id'] ?>"><?= clean($b['name']) ?></a></li>
            <?php endforeach; ?>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?= $page==='category'?'active':'' ?>" href="#" data-bs-toggle="dropdown">Category</a>
          <ul class="dropdown-menu">
            <?php foreach ($categories as $c): ?>
              <li><a class="dropdown-item" href="category.php?id=<?= $c['id'] ?>"><?= clean($c['name']) ?></a></li>
            <?php endforeach; ?>
          </ul>
        </li>

        <li class="nav-item"><a class="nav-link <?= $page==='about'?'active':'' ?>" href="about.php">About Us</a></li>

        <?php if (is_logged_in()): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle"></i> <?= clean($_SESSION['name']) ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person"></i> Profile</a></li>
              <li><a class="dropdown-item" href="orders.php"><i class="bi bi-bag"></i> My Orders</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
            </ul>
          </li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="login.php"><i class="bi bi-box-arrow-in-right"></i> Login</a></li>
          <li class="nav-item"><a class="nav-link" href="register.php"><i class="bi bi-person-plus"></i> Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div style="height:70px;"></div>
