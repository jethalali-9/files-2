<?php
require_once __DIR__ . '/config.php';
$id = intval($_GET['id'] ?? 0);
$product = get_product($id);
if (!$product) {
    header('Location: index.php');
    exit;
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && is_logged_in()) {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $msg = '<div class="alert alert-danger">Invalid session.</div>';
    } else {
        $qty = max(1, intval($_POST['quantity'] ?? 1));
        header('Location: checkout.php?pid=' . $id . '&qty=' . $qty);
        exit;
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="container py-5">
  <div class="row g-5">
    <div class="col-lg-5">
      <img src="<?= image_url($product['image']) ?>" alt="<?= clean($product['name']) ?>" class="product-detail-img">
    </div>
    <div class="col-lg-7">
      <nav><ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
        <li class="breadcrumb-item"><a href="category.php?id=<?= $product['category_id'] ?>"><?= clean($product['category_name']) ?></a></li>
        <li class="breadcrumb-item active"><?= clean($product['name']) ?></li>
      </ol></nav>

      <h1 style="font-family:'Playfair Display',serif;color:#1a3a5c;"><?= clean($product['name']) ?></h1>
      <p class="text-muted mb-3">Brand: <strong><?= clean($product['brand_name']) ?></strong> | Category: <strong><?= clean($product['category_name']) ?></strong></p>
      <h3 class="text-primary mb-3" style="color:#1a3a5c;font-weight:700;"><?= format_price($product['price']) ?></h3>

      <p class="mb-4"><?= clean($product['description']) ?></p>

      <?php if ($msg) echo $msg; ?>

      <?php if ($product['stock'] > 0): ?>
        <p class="text-success"><i class="bi bi-check-circle"></i> In Stock (<?= $product['stock'] ?> available)</p>
      <?php else: ?>
        <p class="text-danger"><i class="bi bi-x-circle"></i> Out of Stock</p>
      <?php endif; ?>

      <?php if (is_logged_in() && $product['stock'] > 0): ?>
        <form method="POST" action="">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <div class="mb-3">
            <label class="form-label">Quantity</label>
            <div class="qty-selector">
              <button type="button" onclick="changeQty(-1)">-</button>
              <input type="number" name="quantity" id="qty" value="1" min="1" max="<?= $product['stock'] ?>" readonly>
              <button type="button" onclick="changeQty(1)">+</button>
            </div>
            <div class="mt-2">
              <strong>Total: </strong><span id="total" style="color:#1a3a5c;font-weight:700;"><?= format_price($product['price']) ?></span>
            </div>
          </div>
          <button type="submit" class="btn btn-gold"><i class="bi bi-bag-check"></i> Buy Now (Cash on Delivery)</button>
        </form>
      <?php elseif (!is_logged_in()): ?>
        <div class="alert alert-info">Please <a href="login.php">login</a> to purchase this product.</div>
        <a href="login.php" class="btn btn-primary-custom">Login to Buy</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
var price = <?= $product['price'] ?>;
function changeQty(d) {
  var q = document.getElementById('qty');
  var v = Math.max(1, Math.min(<?= $product['stock'] ?>, parseInt(q.value) + d));
  q.value = v;
  document.getElementById('total').innerText = '₹' + (price * v).toLocaleString('en-IN', {minimumFractionDigits:2, maximumFractionDigits:2});
}
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
