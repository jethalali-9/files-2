<?php
require_once __DIR__ . '/config.php';
require_login();

$stmt = db()->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid session.';
    } else {
        $name = clean($_POST['name']);
        $phone = clean($_POST['phone']);
        $address = clean($_POST['address']);
        $city = clean($_POST['city'] ?? '');
        $pincode = clean($_POST['pincode'] ?? '');
        $newpass = $_POST['new_password'] ?? '';

        if ($name && $phone) {
            if ($newpass) {
                if (strlen($newpass) < 6) {
                    $error = 'Password must be at least 6 characters.';
                } else {
                    $hash = password_hash($newpass, PASSWORD_DEFAULT);
                    $stmt = db()->prepare("UPDATE users SET name=?, phone=?, address=?, city=?, pincode=?, password=? WHERE id=?");
                    $stmt->bind_param('ssssssi', $name, $phone, $address, $city, $pincode, $hash, $_SESSION['user_id']);
                }
            } else {
                $stmt = db()->prepare("UPDATE users SET name=?, phone=?, address=?, city=?, pincode=? WHERE id=?");
                $stmt->bind_param('sssssi', $name, $phone, $address, $city, $pincode, $_SESSION['user_id']);
            }
            if (!$error && $stmt->execute()) {
                $_SESSION['name'] = $name;
                $success = 'Profile updated successfully!';
                $stmt->execute();
                $user = db()->query("SELECT * FROM users WHERE id=" . $_SESSION['user_id'])->fetch_assoc();
            }
        } else {
            $error = 'Name and phone are required.';
        }
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="container py-5">
  <h2 class="section-title">My Profile</h2>
  <p class="section-subtitle">Manage your account details</p>

  <div class="row justify-content-center">
    <div class="col-lg-7">
      <div class="admin-card">
        <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>

        <div class="d-flex align-items-center mb-4">
          <div style="width:70px;height:70px;border-radius:50%;background:#1a3a5c;color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.8rem;font-weight:700;">
            <?= strtoupper(substr($user['name'],0,1)) ?>
          </div>
          <div class="ms-3">
            <h5 class="mb-0"><?= clean($user['name']) ?></h5>
            <p class="text-muted mb-0"><?= clean($user['email']) ?></p>
          </div>
        </div>

        <form method="POST" action="">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Full Name</label>
              <input type="text" name="name" class="form-control" value="<?= clean($user['name']) ?>" required>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Email (not editable)</label>
              <input type="email" class="form-control" value="<?= clean($user['email']) ?>" disabled>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Phone Number</label>
              <input type="text" name="phone" class="form-control" value="<?= clean($user['phone']) ?>" required>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Pincode</label>
              <input type="text" name="pincode" class="form-control" value="<?= clean($user['pincode'] ?? '') ?>">
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label">Address</label>
            <textarea name="address" class="form-control" rows="2"><?= clean($user['address'] ?? '') ?></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">City</label>
            <input type="text" name="city" class="form-control" value="<?= clean($user['city'] ?? '') ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">New Password (leave blank to keep current)</label>
            <input type="password" name="new_password" class="form-control" minlength="6">
          </div>
          <button type="submit" class="btn btn-primary-custom">Update Profile</button>
          <a href="orders.php" class="btn btn-gold">My Orders</a>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
