<?php
require_once __DIR__ . '/config.php';
include __DIR__ . '/includes/header.php';
?>
<section class="hero" style="padding:60px 0;">
  <div class="container text-center">
    <h1>About Watchify</h1>
    <p>Your trusted partner for premium timepieces since 2020</p>
  </div>
</section>

<section class="py-5" style="background:#fff;">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-6">
        <h2 class="section-title text-start">Our Story</h2>
        <p class="mt-3">Watchify was founded with a simple mission: to bring premium quality watches within everyone's reach. We curate timepieces from the world's most respected brands, ensuring every watch meets our high standards of craftsmanship and style.</p>
        <p>From luxury icons like Rolex and Omega to everyday favorites like Titan and Casio, our collection spans every taste and budget. Every watch tells a story - let us help you find yours.</p>
      </div>
      <div class="col-lg-6 text-center">
        <img src="assets/img/favicon.svg" alt="Watchify" style="width:240px;filter:drop-shadow(0 10px 30px rgba(212,175,55,0.4));">
      </div>
    </div>
  </div>
</section>

<section class="py-5">
  <div class="container">
    <h2 class="section-title">Why Choose Us</h2>
    <p class="section-subtitle">We are committed to excellence in every detail</p>
    <div class="row g-4 text-center">
      <div class="col-md-3 col-sm-6">
        <div class="p-4 bg-white rounded shadow-sm h-100" style="transition:all .3s;" onmouseover="this.style.transform='translateY(-8px)'" onmouseout="this.style.transform=''">
          <i class="bi bi-shield-check" style="font-size:3rem;color:#1a3a5c;"></i>
          <h5 class="mt-3">100% Authentic</h5>
          <p class="text-muted small">Every watch is guaranteed genuine with original warranty.</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="p-4 bg-white rounded shadow-sm h-100" style="transition:all .3s;" onmouseover="this.style.transform='translateY(-8px)'" onmouseout="this.style.transform=''">
          <i class="bi bi-truck" style="font-size:3rem;color:#1a3a5c;"></i>
          <h5 class="mt-3">Cash on Delivery</h5>
          <p class="text-muted small">Pay when you receive. Safe and convenient.</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="p-4 bg-white rounded shadow-sm h-100" style="transition:all .3s;" onmouseover="this.style.transform='translateY(-8px)'" onmouseout="this.style.transform=''">
          <i class="bi bi-tags" style="font-size:3rem;color:#1a3a5c;"></i>
          <h5 class="mt-3">Best Prices</h5>
          <p class="text-muted small">Competitive pricing across all premium brands.</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="p-4 bg-white rounded shadow-sm h-100" style="transition:all .3s;" onmouseover="this.style.transform='translateY(-8px)'" onmouseout="this.style.transform=''">
          <i class="bi bi-headset" style="font-size:3rem;color:#1a3a5c;"></i>
          <h5 class="mt-3">24/7 Support</h5>
          <p class="text-muted small">Our team is always here to help you.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="py-5" style="background:#fff;">
  <div class="container text-center">
    <h2 class="section-title">Our Values</h2>
    <div class="row mt-4">
      <div class="col-md-4">
        <h5 style="color:#d4af37;">Quality First</h5>
        <p class="text-muted">We never compromise on the quality of our timepieces.</p>
      </div>
      <div class="col-md-4">
        <h5 style="color:#d4af37;">Customer Trust</h5>
        <p class="text-muted">Thousands of happy customers across India.</p>
      </div>
      <div class="col-md-4">
        <h5 style="color:#d4af37;">Wide Selection</h5>
        <p class="text-muted">80+ watches across 10 brands and 4 categories.</p>
      </div>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
