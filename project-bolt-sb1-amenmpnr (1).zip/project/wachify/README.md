# Wachify - Watch Collection Website

A complete watch collection e-commerce website built with **HTML, CSS, Bootstrap 5, PHP & MySQL**.

## Features

- **4 Main Menus** in the navbar:
  - **Home** - Hero, featured watches, categories, brands
  - **Brand** - Dropdown submenu listing all brand names (Rolex, Casio, Omega, Fossil, Titan) - click to filter products by brand
  - **Category** - Dropdown submenu with Men, Women, Kids, Couple - click to filter products by category
  - **About Us** - Company story, stats and values

- **User System**
  - Register / Login / Logout
  - Profile page with update profile (name, phone, address)
  - Change password
  - View order history with status tracking
  - Order detail view with status timeline

- **Shopping Flow**
  - Product listing with sidebar filters (brand, category, search)
  - Product detail page with related items
  - Cart (add, update quantity, remove)
  - Checkout (creates an order)

- **Admin Panel** (`/admin`)
  - Dashboard with stats (products, orders, revenue, users)
  - Products CRUD (add, edit, delete with brand/category, price, stock, featured, status)
  - Brands CRUD
  - Categories CRUD
  - Orders management (update order status)
  - Users management (view, delete)

- **Design**
  - Blue / Black / White gradient theme
  - Responsive (Bootstrap 5)
  - Animations: scroll reveal, hero float, hover effects
  - Custom SVG logo & favicon
  - Modern card UI with gradient accents

## Installation

1. **Copy the `wachify` folder** to your web server (XAMPP/WAMP/LAMP `htdocs` or `www`).
2. **Create the database**: open phpMyAdmin (or MySQL CLI) and import `database/wachify.sql`.
   - This creates the `wachify` database with all tables and seed data.
3. **Edit `config/config.php`** if your MySQL credentials differ from the defaults (`root`, no password).
4. **Set the base URL** in `config/config.php` (`BASE_URL`). Default is `/wachify`.
5. **Visit** `http://localhost/wachify` in your browser.

## Default Credentials

- **Admin panel**: `http://localhost/wachify/admin/login.php`
  - Email: `admin@wachify.com`
  - Password: `admin123`
- **Users**: register a new account from the site's Sign Up page.

## Tech Stack

- PHP 7.4+ / 8 (PDO + MySQL)
- MySQL / MariaDB
- Bootstrap 5.3 (CDN)
- Bootstrap Icons (CDN)
- Vanilla CSS + JS

## Folder Structure

```
wachify/
  config/config.php          Database + helpers
  database/wachify.sql        Schema + seed data
  assets/
    css/style.css            Theme styles
    js/main.js               Frontend interactions
    img/logo.svg, favicon.svg
  partials/                  header, footer, product_card
  admin/                     Admin panel (login, dashboard, CRUD)
  index.php, shop.php, brand.php, category.php, product.php
  about.php, cart.php, checkout.php
  register.php, login.php, logout.php, profile.php, order_view.php
```

Built as a complete, working demo. All watch images use Pexels stock photos.
