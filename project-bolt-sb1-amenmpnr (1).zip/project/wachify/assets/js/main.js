// Wachify - frontend interactions
document.addEventListener('DOMContentLoaded', function () {
  // Scroll reveal
  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('show'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('show'); });
  }

  // Admin sidebar toggle (mobile)
  var toggler = document.getElementById('adminToggle');
  var sidebar = document.getElementById('adminSidebar');
  if (toggler && sidebar) {
    toggler.addEventListener('click', function () { sidebar.classList.toggle('open'); });
  }

  // Auto-dismiss toasts
  document.querySelectorAll('.toast-custom').forEach(function (t) {
    setTimeout(function () {
      t.style.transition = 'opacity .5s';
      t.style.opacity = '0';
      setTimeout(function () { t.remove(); }, 500);
    }, 3500);
  });
});
