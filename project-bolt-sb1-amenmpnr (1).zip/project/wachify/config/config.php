<?php
// Wachify Database Configuration
// Edit these values to match your MySQL / MariaDB setup.

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'wachify');

// Site base URL (change if you deploy in a subfolder)
define('BASE_URL', '/wachify');

// Start session once
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Shared PDO connection (singleton).
 */
function db() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            die('<h3>Database connection failed.</h3><p>Please import <code>database/wachify.sql</code> and check <code>config/config.php</code>.</p>');
        }
    }
    return $pdo;
}

/** HTML-escape helper. */
function e($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/** Build a site URL from a path. */
function url($path = '') {
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

/** Redirect helper. */
function redirect($path = '') {
    header('Location: ' . url($path));
    exit;
}

/** Check if a user is logged in. */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/** Check if an admin is logged in. */
function is_admin() {
    return isset($_SESSION['admin_id']);
}

/** Require a user login. */
function require_login() {
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

/** Require an admin login. */
function require_admin() {
    if (!is_admin()) {
        redirect('admin/login.php');
    }
}

/** Get a single row by id. */
function find($table, $id) {
    $stmt = db()->prepare("SELECT * FROM `$table` WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}
