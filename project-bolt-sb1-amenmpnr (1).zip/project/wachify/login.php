<?php
require __DIR__.'/config/config.php';
if (is_logged_in()) redirect('index.php');
$title = 'Login - Wachify';
$err = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $email = trim($_POST['email'] ?? '');
  $pass = $_POST['password'] ?? '';
  $stmt = db()->prepare("SELECT * FROM users WHERE email=?");
  $stmt->execute([$email]);
  $u = $stmt->fetch();
  if (!$u || !password_verify($pass, $u['password'])) {
    $err = 'Invalid email or password.';
  } else {
    $_SESSION['user_id'] = (int)$u['id'];
    $_SESSION['user_name'] = $u['name'];
    redirect('profile.php');
  }
}
include __DIR__.'/partials/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card fade-in">
    <div class="auth-side">
      <img src="<?= url('assets/img/logo.svg') ?>" class="logo" alt="Wachify" style="filter:brightness(0) invert(1)">
      <h2>Welcome Back</h2>
      <p>Login to access your orders, wishlist and member-only deals.</p>
    </div>
    <div class="auth-form">
      <h3>Login to Wachify</h3>
      <p class="text-muted">New here? <a href="<?= url('register.php') ?>" class="fw-semibold" style="color:var(--blue-600)">Create an account</a></p>
      <?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
      <form method="post">
        <div class="mb-3">
          <label>Email Address</label>
          <input type="email" name="email" class="form-control" value="<?= e($_POST['email']??'') ?>" required>
        </div>
        <div class="mb-3">
          <label>Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button class="btn btn-grad w-100 btn-lg">Login</button>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
