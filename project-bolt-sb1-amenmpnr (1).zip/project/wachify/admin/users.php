<?php
require __DIR__.'/../config/config.php';
require_admin();
$page = 'users';
$title = 'Users';

if (($_GET['action']??'')==='delete' && !empty($_GET['id'])) {
  db()->prepare("DELETE FROM users WHERE id=?")->execute([(int)$_GET['id']]);
  redirect('admin/users.php');
}
$users = db()->query("SELECT u.*, (SELECT COUNT(*) FROM orders o WHERE o.user_id=u.id) orders FROM users u ORDER BY u.id DESC")->fetchAll();
include __DIR__.'/partials/header.php';
?>
<div class="admin-card">
  <h5 class="fw-bold mb-3">Registered Users (<?= count($users) ?>)</h5>
  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Joined</th><th></th></tr></thead>
      <tbody>
      <?php if (!$users): ?><tr><td colspan="7" class="text-center text-muted py-4">No users yet</td></tr><?php endif; ?>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?= $u['id'] ?></td>
          <td class="fw-semibold"><?= e($u['name']) ?></td>
          <td><?= e($u['email']) ?></td>
          <td><?= e($u['phone'] ?: '-') ?></td>
          <td><?= $u['orders'] ?></td>
          <td><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
          <td>
            <a href="<?= url('admin/users.php?action=delete&id=').$u['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this user and their orders?')"><i class="bi bi-trash"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
