<?php
require __DIR__.'/../config/config.php';
require_admin();
$page = 'products';
$title = 'Products';
$action = $_GET['action'] ?? 'list';
$brands = db()->query("SELECT * FROM brands ORDER BY name")->fetchAll();
$categories = db()->query("SELECT * FROM categories ORDER BY name")->fetchAll();

// Save (create/update)
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $id = (int)($_POST['id'] ?? 0);
  $name = trim($_POST['name'] ?? '');
  $brand_id = (int)($_POST['brand_id'] ?? 0);
  $cat_id = (int)($_POST['category_id'] ?? 0);
  $price = (float)($_POST['price'] ?? 0);
  $old_price = !empty($_POST['old_price']) ? (float)$_POST['old_price'] : null;
  $image = trim($_POST['image'] ?? '');
  $desc = trim($_POST['description'] ?? '');
  $stock = (int)($_POST['stock'] ?? 0);
  $featured = isset($_POST['featured']) ? 1 : 0;
  $status = $_POST['status'] ?? 'active';
  if ($id) {
    $stmt = db()->prepare("UPDATE products SET name=?,brand_id=?,category_id=?,price=?,old_price=?,image=?,description=?,stock=?,featured=?,status=? WHERE id=?");
    $stmt->execute([$name,$brand_id,$cat_id,$price,$old_price,$image,$desc,$stock,$featured,$status,$id]);
  } else {
    $stmt = db()->prepare("INSERT INTO products (name,brand_id,category_id,price,old_price,image,description,stock,featured,status) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$name,$brand_id,$cat_id,$price,$old_price,$image,$desc,$stock,$featured,$status]);
  }
  redirect('admin/products.php');
}
// Delete
if ($action==='delete' && !empty($_GET['id'])) {
  $stmt = db()->prepare("DELETE FROM products WHERE id=?");
  $stmt->execute([(int)$_GET['id']]);
  redirect('admin/products.php');
}

if ($action==='new' || $action==='edit') {
  $p = ['id'=>0,'name'=>'','brand_id'=>0,'category_id'=>0,'price'=>'','old_price'=>'','image'=>'','description'=>'','stock'=>0,'featured'=>0,'status'=>'active'];
  if ($action==='edit') {
    $p = find('products', (int)$_GET['id']);
    if (!$p) redirect('admin/products.php');
  }
  include __DIR__.'/partials/header.php';
  ?>
  <div class="admin-card" style="max-width:760px">
    <h5 class="fw-bold mb-3"><?= $action==='new'?'Add':'Edit' ?> Product</h5>
    <form method="post">
      <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
      <div class="row g-3">
        <div class="col-md-8"><label class="form-label">Name</label><input type="text" name="name" class="form-control" value="<?= e($p['name']) ?>" required></div>
        <div class="col-md-4"><label class="form-label">Stock</label><input type="number" name="stock" class="form-control" value="<?= (int)$p['stock'] ?>"></div>
        <div class="col-md-6">
          <label class="form-label">Brand</label>
          <select name="brand_id" class="form-select" required>
            <?php foreach ($brands as $b): ?><option value="<?= $b['id'] ?>" <?= $p['brand_id']==$b['id']?'selected':'' ?>><?= e($b['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Category</label>
          <select name="category_id" class="form-select" required>
            <?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $p['category_id']==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-6"><label class="form-label">Price ($)</label><input type="number" step="0.01" name="price" class="form-control" value="<?= e($p['price']) ?>" required></div>
        <div class="col-md-6"><label class="form-label">Old Price ($)</label><input type="number" step="0.01" name="old_price" class="form-control" value="<?= e($p['old_price']) ?>"></div>
        <div class="col-12"><label class="form-label">Image URL</label><input type="text" name="image" class="form-control" value="<?= e($p['image']) ?>" placeholder="https://..."></div>
        <div class="col-12"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="3"><?= e($p['description']) ?></textarea></div>
        <div class="col-md-6">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <option value="active" <?= $p['status']==='active'?'selected':'' ?>>Active</option>
            <option value="inactive" <?= $p['status']==='inactive'?'selected':'' ?>>Inactive</option>
          </select>
        </div>
        <div class="col-md-6 d-flex align-items-end">
          <div class="form-check">
            <input type="checkbox" name="featured" class="form-check-input" id="feat" <?= $p['featured']?'checked':'' ?>>
            <label class="form-check-label" for="feat">Featured product</label>
          </div>
        </div>
        <div class="col-12">
          <button class="btn btn-grad"><i class="bi bi-save"></i> Save Product</button>
          <a href="<?= url('admin/products.php') ?>" class="btn btn-outline-grad">Cancel</a>
        </div>
      </div>
    </form>
  </div>
  <?php
  include __DIR__.'/partials/footer.php';
  exit;
}

// List
$products = db()->query("SELECT p.*, b.name brand_name, c.name cat_name FROM products p JOIN brands b ON b.id=p.brand_id JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC")->fetchAll();
include __DIR__.'/partials/header.php';
?>
<div class="admin-card">
  <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <h5 class="fw-bold mb-0">All Products (<?= count($products) ?>)</h5>
    <a href="<?= url('admin/products.php?action=new') ?>" class="btn btn-grad"><i class="bi bi-plus-circle"></i> Add Product</a>
  </div>
  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr><th>ID</th><th>Image</th><th>Name</th><th>Brand</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($products as $p): ?>
        <tr>
          <td><?= $p['id'] ?></td>
          <td><img src="<?= e($p['image']) ?>" style="width:50px;height:50px;border-radius:8px;object-fit:cover"></td>
          <td class="fw-semibold"><?= e($p['name']) ?></td>
          <td><?= e($p['brand_name']) ?></td>
          <td><?= e($p['cat_name']) ?></td>
          <td>$<?= number_format($p['price'],2) ?></td>
          <td><?= $p['stock'] ?></td>
          <td><span class="badge-soft <?= $p['status']==='active'?'delivered':'cancelled' ?>"><?= e($p['status']) ?></span></td>
          <td class="text-end">
            <a href="<?= url('admin/products.php?action=edit&id=').$p['id'] ?>" class="btn btn-sm btn-outline-grad"><i class="bi bi-pencil"></i></a>
            <a href="<?= url('admin/products.php?action=delete&id=').$p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this product?')"><i class="bi bi-trash"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
