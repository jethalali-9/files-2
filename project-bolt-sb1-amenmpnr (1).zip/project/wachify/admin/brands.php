<?php
require __DIR__.'/../config/config.php';
require_admin();
$page = 'brands';
$title = 'Brands';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  $id = (int)($_POST['id'] ?? 0);
  $name = trim($_POST['name'] ?? '');
  $slug = strtolower(preg_replace('/[^a-z0-9]+/','-', $name));
  $desc = trim($_POST['description'] ?? '');
  if ($id) {
    $stmt = db()->prepare("UPDATE brands SET name=?,slug=?,description=? WHERE id=?");
    $stmt->execute([$name,$slug,$desc,$id]);
  } else {
    $stmt = db()->prepare("INSERT INTO brands (name,slug,description) VALUES (?,?,?)");
    $stmt->execute([$name,$slug,$desc]);
  }
  redirect('admin/brands.php');
}
if (($_GET['action']??'')==='delete' && !empty($_GET['id'])) {
  db()->prepare("DELETE FROM brands WHERE id=?")->execute([(int)$_GET['id']]);
  redirect('admin/brands.php');
}
$edit = null;
if (($_GET['action']??'')==='edit') $edit = find('brands', (int)$_GET['id']);
$brands = db()->query("SELECT b.*, (SELECT COUNT(*) FROM products p WHERE p.brand_id=b.id) cnt FROM brands b ORDER BY b.name")->fetchAll();
include __DIR__.'/partials/header.php';
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="admin-card">
      <h5 class="fw-bold mb-3"><?= $edit?'Edit':'Add' ?> Brand</h5>
      <form method="post">
        <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" class="form-control" value="<?= e($edit['name'] ?? '') ?>" required></div>
        <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="3"><?= e($edit['description'] ?? '') ?></textarea></div>
        <button class="btn btn-grad"><i class="bi bi-save"></i> Save</button>
        <?php if ($edit): ?><a href="<?= url('admin/brands.php') ?>" class="btn btn-outline-grad">Cancel</a><?php endif; ?>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="admin-card">
      <h5 class="fw-bold mb-3">All Brands (<?= count($brands) ?>)</h5>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>Products</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($brands as $b): ?>
            <tr>
              <td><?= $b['id'] ?></td>
              <td class="fw-semibold"><?= e($b['name']) ?></td>
              <td><code><?= e($b['slug']) ?></code></td>
              <td><?= $b['cnt'] ?></td>
              <td class="text-end">
                <a href="<?= url('admin/brands.php?action=edit&id=').$b['id'] ?>" class="btn btn-sm btn-outline-grad"><i class="bi bi-pencil"></i></a>
                <a href="<?= url('admin/brands.php?action=delete&id=').$b['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete brand and its products?')"><i class="bi bi-trash"></i></a>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
