<?php
require __DIR__.'/../config/config.php';
require_admin();
$page = 'categories';
$title = 'Categories';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  $id = (int)($_POST['id'] ?? 0);
  $name = trim($_POST['name'] ?? '');
  $slug = strtolower(preg_replace('/[^a-z0-9]+/','-', $name));
  if ($id) {
    $stmt = db()->prepare("UPDATE categories SET name=?,slug=? WHERE id=?");
    $stmt->execute([$name,$slug,$id]);
  } else {
    $stmt = db()->prepare("INSERT INTO categories (name,slug) VALUES (?,?)");
    $stmt->execute([$name,$slug]);
  }
  redirect('admin/categories.php');
}
if (($_GET['action']??'')==='delete' && !empty($_GET['id'])) {
  db()->prepare("DELETE FROM categories WHERE id=?")->execute([(int)$_GET['id']]);
  redirect('admin/categories.php');
}
$edit = null;
if (($_GET['action']??'')==='edit') $edit = find('categories', (int)$_GET['id']);
$cats = db()->query("SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) cnt FROM categories c ORDER BY c.name")->fetchAll();
include __DIR__.'/partials/header.php';
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="admin-card">
      <h5 class="fw-bold mb-3"><?= $edit?'Edit':'Add' ?> Category</h5>
      <form method="post">
        <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" class="form-control" value="<?= e($edit['name'] ?? '') ?>" required></div>
        <button class="btn btn-grad"><i class="bi bi-save"></i> Save</button>
        <?php if ($edit): ?><a href="<?= url('admin/categories.php') ?>" class="btn btn-outline-grad">Cancel</a><?php endif; ?>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="admin-card">
      <h5 class="fw-bold mb-3">All Categories (<?= count($cats) ?>)</h5>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>Products</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($cats as $c): ?>
            <tr>
              <td><?= $c['id'] ?></td>
              <td class="fw-semibold"><?= e($c['name']) ?></td>
              <td><code><?= e($c['slug']) ?></code></td>
              <td><?= $c['cnt'] ?></td>
              <td class="text-end">
                <a href="<?= url('admin/categories.php?action=edit&id=').$c['id'] ?>" class="btn btn-sm btn-outline-grad"><i class="bi bi-pencil"></i></a>
                <a href="<?= url('admin/categories.php?action=delete&id=').$c['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete category and its products?')"><i class="bi bi-trash"></i></a>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
