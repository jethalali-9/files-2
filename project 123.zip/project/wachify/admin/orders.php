<?php
require __DIR__.'/../config/config.php';
require_admin();
$page = 'orders';
$title = 'Orders';
if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['id'])) {
  $status = $_POST['status'] ?? 'Pending';
  db()->prepare("UPDATE orders SET status=? WHERE id=?")->execute([$status, (int)$_POST['id']]);
  redirect('admin/orders.php');
}
$orders = db()->query("SELECT o.*, u.name user_name, u.email user_email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC")->fetchAll();
include __DIR__.'/partials/header.php';
?>
<div class="admin-card">
  <h5 class="fw-bold mb-3">All Orders (<?= count($orders) ?>)</h5>
  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr><th>#</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th>Update Status</th></tr></thead>
      <tbody>
      <?php if (!$orders): ?><tr><td colspan="7" class="text-center text-muted py-4">No orders yet</td></tr><?php endif; ?>
      <?php foreach ($orders as $o): ?>
        <tr>
          <td>#<?= $o['id'] ?></td>
          <td><div class="fw-semibold"><?= e($o['user_name']) ?></div><small class="text-muted"><?= e($o['user_email']) ?></small></td>
          <td>$<?= number_format($o['total'],2) ?></td>
          <td><span class="badge-soft cod"><?= e($o['payment_method'] ?? 'COD') ?></span></td>
          <td><span class="badge-soft <?= strtolower(e($o['status'])) ?>"><?= e($o['status']) ?></span></td>
          <td><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
          <td>
            <form method="post" class="d-flex gap-2">
              <input type="hidden" name="id" value="<?= $o['id'] ?>">
              <select name="status" class="form-select form-select-sm" style="width:140px">
                <?php foreach (['Pending','Processing','Shipped','Delivered','Cancelled'] as $s): ?>
                  <option value="<?= $s ?>" <?= $o['status']===$s?'selected':'' ?>><?= $s ?></option>
                <?php endforeach; ?>
              </select>
              <button class="btn btn-sm btn-grad">Update</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
