# Watchify - Watch Collection Website

A complete watch collection e-commerce website built with **PHP, MySQL & Bootstrap 5**.

## What's New

- **New Design**: Emerald Green / Gold / Charcoal premium theme with Playfair Display + Poppins fonts
- **File Upload in Admin**: Add product images via "Choose File" button (no URL needed)
- **Cash on Delivery Only**: Checkout is COD-only — no online payment options
- **New Name**: Watchify

## Features

### Frontend
- **4 Navbar Menus**: Home, Brand (dropdown of brand names), Category (dropdown: Men/Women/Kids/Couple), About Us
- **Home**: Hero, featured watches, category cards, brand strip, COD banner, features section
- **Shop**: Product listing with sidebar filters (brand, category, search)
- **Product Detail**: Image, price, description, COD badge, related watches
- **Brand Page**: Filter products by brand with brand-name chips
- **Category Page**: Filter products by category with category chips
- **About Us**: Company story, stats, values
- **Cart**: Add, update quantity, remove items
- **Checkout**: Cash on Delivery only — enter shipping address and place order
- **User Account**: Register, Login, Profile (update name/phone/address), Change Password, View Orders with status timeline
- **Order View**: Full order detail with COD payment method and status tracking

### Admin Panel (`/admin`)
- **Dashboard**: Stats (products, orders, revenue, users) + recent orders + quick actions
- **Products CRUD**: Add/Edit/Delete with **file upload** for images (Choose File button)
- **Brands CRUD**: Add/Edit/Delete brands
- **Categories CRUD**: Add/Edit/Delete categories
- **Orders**: View all orders with COD payment method, update order status
- **Users**: View registered users, delete users

## Installation

1. **Copy the `wachify` folder** to your web server (XAMPP/WAMP `htdocs` or `www`).
2. **Create the database**: Open phpMyAdmin and import `database/wachify.sql`.
   - This creates the `wachify` database with all tables and seed data.
3. **Edit `config/config.php`** if your MySQL credentials differ from defaults (`root`, no password).
4. **Set the base URL** in `config/config.php` (`BASE_URL`). Default is `/wachify`.
5. **Ensure `assets/uploads/` is writable** (chmod 777) for product image uploads.
6. **Visit** `http://localhost/wachify` in your browser.

## Default Credentials

- **Admin panel**: `http://localhost/wachify/admin/login.php`
  - Email: `admin@watchify.com`
  - Password: `admin123`
- **Users**: Register a new account from the site's Sign Up page.

## Tech Stack

- PHP 7.4+ / 8 (PDO + MySQL)
- MySQL / MariaDB
- Bootstrap 5.3 (CDN)
- Bootstrap Icons (CDN)
- Google Fonts: Poppins + Playfair Display
- Vanilla CSS + JS

## Folder Structure

```
wachify/
  config/config.php            Database config + helpers
  database/wachify.sql         Schema + seed data
  assets/
    css/style.css              Premium theme styles
    js/main.js                 Frontend interactions + file upload preview
    img/logo.svg, favicon.svg  Custom SVG branding
    uploads/                   Uploaded product images (auto-created)
  partials/                    header, footer, product_card
  admin/                       Admin panel (login, dashboard, CRUD)
    partials/                  Admin header, footer
  index.php, shop.php, brand.php, category.php, product.php
  about.php, cart.php, checkout.php
  register.php, login.php, logout.php, profile.php, order_view.php
```

Built as a complete, working demo. Seed product images use Pexels stock photos.
