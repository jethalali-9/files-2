<?php
require __DIR__.'/config/config.php';
if (is_logged_in()) redirect('index.php');
$title = 'Sign Up - Watchify';
$err = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $name = trim($_POST['name'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $pass = $_POST['password'] ?? '';
  $phone = trim($_POST['phone'] ?? '');
  if (!$name || !$email || !$pass || !$phone) $err = 'Please fill all required fields (Name, Email, Phone, Password).';
  elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $err = 'Invalid email address.';
  else {
    $chk = db()->prepare("SELECT id FROM users WHERE email=?");
    $chk->execute([$email]);
    if ($chk->fetch()) $err = 'Email already registered. Please login.';
    else {
      $stmt = db()->prepare("INSERT INTO users (name,email,password,phone) VALUES (?,?,?,?)");
      $stmt->execute([$name,$email,password_hash($pass, PASSWORD_DEFAULT),$phone]);
      $_SESSION['user_id'] = (int)db()->lastInsertId();
      $_SESSION['user_name'] = $name;
      redirect('profile.php');
    }
  }
}
include __DIR__.'/partials/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card fade-in">
    <div class="auth-side">
      <img src="<?= url('assets/img/logo.svg') ?>" class="logo" alt="Watchify" style="filter:brightness(0) invert(1)">
      <h2>Join Watchify</h2>
      <p>Create your account to track orders, save favorites and enjoy a faster checkout with Cash on Delivery.</p>
      <ul class="mt-4 ps-0" style="list-style:none">
        <li class="mb-2"><i class="bi bi-check-circle me-2"></i> Cash on Delivery available</li>
        <li class="mb-2"><i class="bi bi-check-circle me-2"></i> Order history & tracking</li>
        <li class="mb-2"><i class="bi bi-check-circle me-2"></i> Faster checkout</li>
      </ul>
    </div>
    <div class="auth-form">
      <h3>Create Account</h3>
      <p class="text-muted">Already have an account? <a href="<?= url('login.php') ?>" class="fw-semibold emerald-text">Login</a></p>
      <?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
      <form method="post">
        <div class="mb-3"><label>Full Name</label><input type="text" name="name" class="form-control" value="<?= e($_POST['name']??'') ?>" required></div>
        <div class="mb-3"><label>Email Address</label><input type="email" name="email" class="form-control" value="<?= e($_POST['email']??'') ?>" required></div>
        <div class="mb-3"><label>Phone Number</label><input type="tel" name="phone" class="form-control" value="<?= e($_POST['phone']??'') ?>" required></div>
        <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required></div>
        <button class="btn btn-grad w-100 btn-lg">Create Account</button>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
