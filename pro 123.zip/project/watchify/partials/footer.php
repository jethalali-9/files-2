<?php
$brands = db()->query("SELECT * FROM brands ORDER BY name LIMIT 6")->fetchAll();
?>
<footer class="footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4 col-md-6">
        <img src="<?= url('assets/img/logo.svg') ?>" class="brand-logo" alt="Watchify">
        <p>Watchify is your destination for premium and everyday watches. Curated collections from the world's finest brands, delivered to your wrist.</p>
        <div class="social">
          <a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
          <a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
          <a href="#" aria-label="Twitter"><i class="bi bi-twitter-x"></i></a>
          <a href="#" aria-label="YouTube"><i class="bi bi-youtube"></i></a>
        </div>
      </div>
      <div class="col-lg-2 col-md-6">
        <h5>Explore</h5>
        <a href="<?= url('index.php') ?>">Home</a>
        <a href="<?= url('about.php') ?>">About Us</a>
        <a href="<?= url('cart.php') ?>">Cart</a>
        <a href="<?= url('profile.php') ?>">My Account</a>
      </div>
      <div class="col-lg-3 col-md-6">
        <h5>Brands</h5>
        <?php foreach ($brands as $b): ?>
          <a href="<?= url('brand.php?slug=').e($b['slug']) ?>"><?= e($b['name']) ?></a>
        <?php endforeach; ?>
      </div>
      <div class="col-lg-3 col-md-6">
        <h5>Categories</h5>
        <a href="<?= url('category.php?slug=men') ?>">Men</a>
        <a href="<?= url('category.php?slug=women') ?>">Women</a>
        <a href="<?= url('category.php?slug=kids') ?>">Kids</a>
        <a href="<?= url('category.php?slug=couple') ?>">Couple</a>
      </div>
    </div>
    <div class="footer-bottom">&copy; <?= date('Y') ?> Watchify. All rights reserved. Built with PHP &amp; Bootstrap 5.</div>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= url('assets/js/main.js') ?>"></script>
</body>
</html>
