<?php
if (!isset($page)) $page = '';
if (!isset($title)) $title = 'Watchify - Watch Collection';
$brands = db()->query("SELECT * FROM brands ORDER BY name")->fetchAll();
$categories = db()->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$cartCount = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
  foreach ($_SESSION['cart'] as $q) $cartCount += (int)$q;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($title) ?></title>
  <link rel="icon" href="<?= url('assets/img/favicon.svg') ?>" type="image/svg+xml">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700;800&display=swap" rel="stylesheet">
  <link href="<?= url('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body>
<div class="nav-wrap">
  <nav class="navbar navbar-expand-lg container">
    <a class="navbar-brand" href="<?= url('index.php') ?>"><img src="<?= url('assets/img/logo.svg') ?>" alt="Watchify"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav mx-auto gap-1">
        <li class="nav-item"><a class="nav-link <?= $page==='home'?'active':'' ?>" href="<?= url('index.php') ?>">Home</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?= $page==='brand'?'active':'' ?>" href="#" data-bs-toggle="dropdown">Brand</a>
          <ul class="dropdown-menu">
            <?php foreach ($brands as $b): ?>
              <li><a class="dropdown-item" href="<?= url('brand.php?slug=').e($b['slug']) ?>"><?= e($b['name']) ?></a></li>
            <?php endforeach; ?>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?= $page==='category'?'active':'' ?>" href="#" data-bs-toggle="dropdown">Category</a>
          <ul class="dropdown-menu">
            <?php foreach ($categories as $c): ?>
              <li><a class="dropdown-item" href="<?= url('category.php?slug=').e($c['slug']) ?>"><?= e($c['name']) ?></a></li>
            <?php endforeach; ?>
          </ul>
        </li>
        <li class="nav-item"><a class="nav-link <?= $page==='about'?'active':'' ?>" href="<?= url('about.php') ?>">About Us</a></li>
      </ul>
      <div class="nav-actions">
        <a href="<?= url('cart.php') ?>" class="btn btn-outline-grad position-relative">
          <i class="bi bi-bag"></i>
          <?php if ($cartCount>0): ?><span class="position-absolute top-0 start-100 translate-middle badge rounded-pill" style="background:var(--gold-500)"><?= $cartCount ?></span><?php endif; ?>
        </a>
        <?php if (is_logged_in()): ?>
          <a href="<?= url('profile.php') ?>" class="btn btn-grad"><i class="bi bi-person-circle"></i> Profile</a>
        <?php else: ?>
          <a href="<?= url('login.php') ?>" class="btn btn-outline-grad">Login</a>
          <a href="<?= url('register.php') ?>" class="btn btn-gold">Sign Up</a>
        <?php endif; ?>
      </div>
    </div>
  </nav>
</div>
