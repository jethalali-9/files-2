<?php
require __DIR__.'/config/config.php';
$page = 'about';
include __DIR__.'/partials/header.php';
?>
<section class="hero" style="background:var(--grad-dark)">
  <div class="container py-5 text-center"><h1 class="fade-in">About <span class="gold">Watchify</span></h1><p class="mx-auto" style="max-width:680px">We bring the world's finest watches to your wrist — from timeless luxury to everyday classics, crafted for every moment of your life.</p></div>
</section>
<section class="section">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-6 reveal"><img src="https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg" class="rounded-4 w-100 shadow-lg" alt="Watches"></div>
      <div class="col-lg-6 reveal">
        <span class="badge rounded-pill mb-2" style="background:var(--grad-soft);color:var(--emerald-700)">Our Story</span>
        <h2 class="fw-bold">Crafted for Time, <span class="gold">Designed for You</span></h2>
        <p class="text-muted">Founded with a passion for precision and style, Watchify curates premium watches from the world's most respected brands. Whether you're searching for a statement luxury piece, a reliable everyday watch, or a matching set for you and your partner — we have something for everyone.</p>
        <p class="text-muted">Every timepiece in our collection is 100% authentic, backed by warranty, and delivered with care. We offer <strong class="emerald-text">Cash on Delivery</strong> so you can shop with confidence. Our mission is simple: make exceptional watches accessible to all.</p>
        <div class="row g-3 mt-2">
          <div class="col-6"><div class="d-flex gap-2 align-items-center"><i class="bi bi-check-circle-fill" style="color:var(--emerald-600)"></i> 100% Authentic</div></div>
          <div class="col-6"><div class="d-flex gap-2 align-items-center"><i class="bi bi-check-circle-fill" style="color:var(--emerald-600)"></i> 2 Year Warranty</div></div>
          <div class="col-6"><div class="d-flex gap-2 align-items-center"><i class="bi bi-check-circle-fill" style="color:var(--emerald-600)"></i> Cash on Delivery</div></div>
          <div class="col-6"><div class="d-flex gap-2 align-items-center"><i class="bi bi-check-circle-fill" style="color:var(--emerald-600)"></i> Easy Returns</div></div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="section" style="background:var(--grad-primary);color:#fff">
  <div class="container"><div class="row text-center g-4">
    <div class="col-md-3 reveal"><div class="display-5 fw-bold" style="font-family:var(--font-display)">15+</div><div class="opacity-75">Watch Models</div></div>
    <div class="col-md-3 reveal"><div class="display-5 fw-bold" style="font-family:var(--font-display)">5</div><div class="opacity-75">Top Brands</div></div>
    <div class="col-md-3 reveal"><div class="display-5 fw-bold" style="font-family:var(--font-display)">4</div><div class="opacity-75">Categories</div></div>
    <div class="col-md-3 reveal"><div class="display-5 fw-bold" style="font-family:var(--font-display)">100%</div><div class="opacity-75">Satisfaction</div></div>
  </div></div>
</section>
<section class="section">
  <div class="container">
    <div class="section-title reveal"><h2>Why Choose <span class="gold">Watchify</span></h2><div class="bar"></div></div>
    <div class="row g-4">
      <div class="col-md-4 reveal"><div class="admin-card text-center h-100"><div style="font-size:2.8rem;color:var(--emerald-600)"><i class="bi bi-gem"></i></div><h5 class="fw-bold mt-2">Premium Quality</h5><p class="text-muted mb-0">Only authentic, top-brand watches make it to our shelves.</p></div></div>
      <div class="col-md-4 reveal"><div class="admin-card text-center h-100"><div style="font-size:2.8rem;color:var(--gold-500)"><i class="bi bi-cash-coin"></i></div><h5 class="fw-bold mt-2">Cash on Delivery</h5><p class="text-muted mb-0">Pay at your doorstep. No online payment needed.</p></div></div>
      <div class="col-md-4 reveal"><div class="admin-card text-center h-100"><div style="font-size:2.8rem;color:var(--emerald-600)"><i class="bi bi-truck"></i></div><h5 class="fw-bold mt-2">Fast Delivery</h5><p class="text-muted mb-0">Quick, safe shipping to your doorstep.</p></div></div>
    </div>
  </div>
</section>
<?php include __DIR__.'/partials/footer.php'; ?>
