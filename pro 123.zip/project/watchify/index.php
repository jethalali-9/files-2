<?php
require __DIR__.'/config/config.php';
$page = 'home';
$featured = db()->query("SELECT p.*, b.name brand_name, b.slug brand_slug, c.name cat_name, c.slug cat_slug FROM products p JOIN brands b ON b.id=p.brand_id JOIN categories c ON c.id=p.category_id WHERE p.featured=1 AND p.status='active' ORDER BY p.id DESC LIMIT 8")->fetchAll();
$categories = db()->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$brands = db()->query("SELECT * FROM brands ORDER BY name")->fetchAll();
include __DIR__.'/partials/header.php';
?>
<section class="hero">
  <div class="container py-5">
    <div class="row align-items-center g-4 py-4">
      <div class="col-lg-6 fade-in">
        <span class="badge rounded-pill mb-3" style="background:rgba(245,158,11,.2);color:var(--gold-300);padding:.6rem 1.2rem"><i class="bi bi-stars"></i> Premium Watch Collection</span>
        <h1>Timeless Style <span class="gold">on Your Wrist</span></h1>
        <p class="mt-3">Discover luxury and everyday watches from the world's finest brands. Crafted for men, women, kids and couples. Pay with <strong style="color:var(--gold-400)">Cash on Delivery</strong>.</p>
        <div class="d-flex gap-3 mt-4 flex-wrap">
          <a href="<?= url('category.php?slug=men') ?>" class="btn btn-white">Shop Now <i class="bi bi-arrow-right"></i></a>
          <a href="<?= url('about.php') ?>" class="btn btn-ghost">Learn More</a>
        </div>
        <div class="hero-stats">
          <div><div class="num">15+</div><div class="lbl">Watch Models</div></div>
          <div><div class="num">5</div><div class="lbl">Top Brands</div></div>
          <div><div class="num">4</div><div class="lbl">Categories</div></div>
          <div><div class="num">100%</div><div class="lbl">Authentic</div></div>
        </div>
      </div>
      <div class="col-lg-6 text-center">
        <img src="https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg" class="hero-watch" alt="Featured watch">
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-title reveal"><h2>Shop by <span class="gold">Category</span></h2><p>Find the perfect watch for everyone</p><div class="bar"></div></div>
    <div class="row g-4">
      <?php foreach ($categories as $c): ?>
        <div class="col-lg-3 col-md-6 reveal">
          <a href="<?= url('category.php?slug=').e($c['slug']) ?>" class="cat-card d-block">
            <img src="https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg" alt="<?= e($c['name']) ?>">
            <div class="overlay">
              <div class="icon"><i class="bi bi-<?= $c['slug']==='men'?'gender-male':($c['slug']==='women'?'gender-female':($c['slug']==='kids'?'balloon-heart':'heart')) ?>"></i></div>
              <h3><?= e($c['name']) ?></h3><span>Explore collection <i class="bi bi-arrow-right"></i></span>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section" style="background:linear-gradient(180deg,#fff,#ecfdf5)">
  <div class="container">
    <div class="section-title reveal"><h2>Featured <span class="gold">Watches</span></h2><p>Handpicked timepieces for every occasion</p><div class="bar"></div></div>
    <div class="row g-4">
      <?php foreach ($featured as $p): ?>
        <div class="col-lg-3 col-md-6 reveal">
          <div class="card-watch">
            <div class="img-wrap">
              <a href="<?= url('product.php?id=').$p['id'] ?>"><img src="<?= img_url($p['image']) ?>" alt="<?= e($p['name']) ?>"></a>
              <?php if ($p['old_price']): ?><span class="tag">Sale</span><?php endif; ?>
              <button class="fav" title="Wishlist"><i class="bi bi-heart"></i></button>
            </div>
            <div class="body">
              <span class="brand"><?= e($p['brand_name']) ?> &middot; <?= e($p['cat_name']) ?></span>
              <h3><a href="<?= url('product.php?id=').$p['id'] ?>" class="text-reset"><?= e($p['name']) ?></a></h3>
              <div class="stars"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i></div>
              <div class="price">$<?= number_format($p['price'],2) ?><?php if ($p['old_price']): ?><span class="old">$<?= number_format($p['old_price'],2) ?></span><?php endif; ?></div>
              <form method="post" action="<?= url('cart.php') ?>"><input type="hidden" name="action" value="add"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="btn-add"><i class="bi bi-bag-plus"></i> Add to Cart</button></form>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-4"><a href="<?= url('shop.php') ?>" class="btn btn-grad btn-lg px-5">View All Watches</a></div>
  </div>
</section>

<section class="section" style="padding:2rem 0">
  <div class="container"><div class="cod-banner reveal"><i class="bi bi-cash-coin fs-1"></i><div><h5 class="mb-0 fw-bold">Cash on Delivery Available</h5><small>Order now and pay when your watch arrives at your doorstep.</small></div></div></div>
</section>

<section class="section">
  <div class="container">
    <div class="section-title reveal"><h2>Our <span class="gold">Brands</span></h2><p>Trusted names in watchmaking</p><div class="bar"></div></div>
    <div class="brand-strip reveal">
      <?php foreach ($brands as $b): ?><a href="<?= url('brand.php?slug=').e($b['slug']) ?>" class="brand-pill"><?= e($b['name']) ?></a><?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section" style="background:var(--grad-dark);color:#fff">
  <div class="container">
    <div class="row g-4 text-center">
      <div class="col-md-3 reveal"><div style="font-size:2.8rem;color:var(--gold-400)"><i class="bi bi-truck"></i></div><h5 class="fw-bold mt-2">Free Shipping</h5><p class="text-light opacity-75">On all orders above $50</p></div>
      <div class="col-md-3 reveal"><div style="font-size:2.8rem;color:var(--gold-400)"><i class="bi bi-shield-check"></i></div><h5 class="fw-bold mt-2">2 Year Warranty</h5><p class="text-light opacity-75">On every timepiece</p></div>
      <div class="col-md-3 reveal"><div style="font-size:2.8rem;color:var(--gold-400)"><i class="bi bi-cash"></i></div><h5 class="fw-bold mt-2">Cash on Delivery</h5><p class="text-light opacity-75">Pay at your doorstep</p></div>
      <div class="col-md-3 reveal"><div style="font-size:2.8rem;color:var(--gold-400)"><i class="bi bi-headset"></i></div><h5 class="fw-bold mt-2">24/7 Support</h5><p class="text-light opacity-75">Always here to help</p></div>
    </div>
  </div>
</section>
<?php include __DIR__.'/partials/footer.php'; ?>
