-- Watchify Watch Collection - Database Schema
-- Import this file into MySQL (phpMyAdmin or CLI) before running the site.

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS watchify
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE watchify;

-- Brands
DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Products
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `old_price` decimal(10,2) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`), KEY `category_id` (`category_id`),
  CONSTRAINT `fk_prod_brand` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prod_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admins
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Orders (COD only)
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending',
  `payment_method` varchar(30) NOT NULL DEFAULT 'Cash on Delivery',
  `customer_name` varchar(120) DEFAULT NULL,
  `customer_phone` varchar(30) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), KEY `user_id` (`user_id`),
  CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Order items
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`), KEY `order_id` (`order_id`),
  CONSTRAINT `fk_oi_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed: Brands
INSERT INTO `brands` (`name`, `slug`, `description`) VALUES
('Rolex', 'rolex', 'Luxury Swiss watches, a symbol of prestige and precision.'),
('Casio', 'casio', 'Affordable, durable and innovative Japanese watches.'),
('Omega', 'omega', 'Premium Swiss timepieces known for accuracy and style.'),
('Fossil', 'fossil', 'Modern fashion watches blending classic and contemporary.'),
('Titan', 'titan', 'Trusted Indian brand offering elegant everyday watches.');

-- Seed: Categories
INSERT INTO `categories` (`name`, `slug`) VALUES
('Men', 'men'), ('Women', 'women'), ('Kids', 'kids'), ('Couple', 'couple');

-- Seed: Products
INSERT INTO `products` (`name`, `brand_id`, `category_id`, `price`, `old_price`, `image`, `description`, `stock`, `featured`, `status`) VALUES
('Rolex Submariner', 1, 1, 12500.00, 14000.00, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Iconic diving watch with automatic movement.', 5, 1, 'active'),
('Rolex Datejust', 1, 2, 9800.00, NULL, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Classic ladies Datejust in steel and gold.', 4, 1, 'active'),
('Casio G-Shock', 2, 1, 120.00, 150.00, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Shock resistant sport watch for men.', 20, 1, 'active'),
('Casio Baby-G', 2, 2, 95.00, NULL, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Tough and stylish watch for women.', 15, 0, 'active'),
('Casio Kids Digital', 2, 3, 40.00, 55.00, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Fun, colorful digital watch for kids.', 30, 1, 'active'),
('Omega Seamaster', 3, 1, 5400.00, 5900.00, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Professional diver watch with chronometer.', 3, 1, 'active'),
('Omega Constellation', 3, 2, 4800.00, NULL, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Elegant constellation watch for women.', 4, 0, 'active'),
('Fossil Gen 6', 4, 1, 295.00, 350.00, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Smart hybrid watch for men.', 12, 1, 'active'),
('Fossil Virginia', 4, 2, 180.00, NULL, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Slim leather strap watch for women.', 10, 0, 'active'),
('Titan Neo', 5, 1, 75.00, 99.00, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Everyday minimalist watch for men.', 25, 1, 'active'),
('Titan Raga', 5, 2, 90.00, NULL, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Graceful watch for women.', 18, 0, 'active'),
('Titan Kids Time', 5, 3, 35.00, 45.00, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Colorful easy-read watch for kids.', 40, 1, 'active'),
('Couple Set Classic', 5, 4, 160.00, 199.00, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Matching his-and-hers couple watch set.', 8, 1, 'active'),
('Couple Set Luxe', 4, 4, 320.00, NULL, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Premium couple watch set by Fossil.', 6, 0, 'active'),
('Rolex Couple Edition', 1, 4, 22000.00, 24000.00, 'https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg', 'Exclusive couple set by Rolex.', 2, 1, 'active');

-- Seed: Default admin (admin@watchify.com / admin123)
INSERT INTO `admins` (`name`, `email`, `password`) VALUES
('Admin', 'admin@watchify.com', '$2y$12$znoxEYlEsi55CKGf1ZZBLus9RyLMBDSfUwsRwIHJgo9Fq9UKmZDwC');

SET FOREIGN_KEY_CHECKS = 1;
