<?php
require __DIR__.'/config/config.php';
require_login();
$uid = (int)$_SESSION['user_id'];
$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM orders WHERE id=? AND user_id=?");
$stmt->execute([$id, $uid]);
$order = $stmt->fetch();
if (!$order) redirect('profile.php?tab=orders');
$items = db()->prepare("SELECT * FROM order_items WHERE order_id=?");
$items->execute([$order['id']]);
$items = $items->fetchAll();
$title = 'Order #'.$order['id'].' - Watchify';
include __DIR__.'/partials/header.php';
?>
<div class="container py-4">
  <nav><ol class="breadcrumb breadcrumb-soft"><li class="breadcrumb-item"><a href="<?= url('index.php') ?>">Home</a></li><li class="breadcrumb-item"><a href="<?= url('profile.php?tab=orders') ?>">My Orders</a></li><li class="breadcrumb-item active">Order #<?= $order['id'] ?></li></ol></nav>
  <div class="admin-card fade-in">
    <div class="d-flex justify-content-between flex-wrap gap-2 mb-3">
      <div><h4 class="fw-bold mb-0">Order #<?= $order['id'] ?></h4><p class="text-muted mb-0">Placed on <?= date('F d, Y H:i', strtotime($order['created_at'])) ?></p></div>
      <div class="text-end"><span class="badge-soft <?= strtolower(e($order['status'])) ?> fs-6"><?= e($order['status']) ?></span></div>
    </div>
    <div class="cod-banner mb-4"><i class="bi bi-cash-coin"></i> <span>Payment Method: <strong><?= e($order['payment_method'] ?? 'Cash on Delivery') ?></strong></span></div>
    <div class="d-flex justify-content-between mb-4 position-relative" style="overflow-x:auto">
      <?php
      $steps = ['Pending','Processing','Shipped','Delivered'];
      $current = array_search($order['status'], $steps);
      if ($order['status']==='Cancelled') $current = -1;
      foreach ($steps as $i=>$s):
        $done = $current !== false && $i <= $current;
      ?>
        <div class="text-center flex-fill position-relative" style="min-width:120px">
          <div class="rounded-circle mx-auto d-grid" style="width:46px;height:46px;place-items:center;font-weight:700;background:<?= $done?'var(--grad-primary)':'#e5e7eb' ?>;color:<?= $done?'#fff':'#9ca3af' ?>"><?= $i+1 ?></div>
          <div class="small mt-2 fw-semibold <?= $done?'':'text-muted' ?>"><?= $s ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <h6 class="fw-bold">Shipping Address</h6><p class="text-muted"><?= e($order['shipping_address']) ?></p>
    <h6 class="fw-bold mt-4">Items</h6>
    <div class="table-responsive">
      <table class="table align-middle">
        <thead><tr><th>Product</th><th>Photo</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
        <tbody>
          <?php foreach ($items as $it): ?>
          <tr><td><?= e($it['name']) ?></td><td><img src="<?= img_url($it['image']) ?>" style="width:50px;height:50px;border-radius:8px;object-fit:cover" onerror="this.src='https://images.pexels.com/photos/9978722/pexels-photo-9978722.jpeg'"></td><td>$<?= number_format($it['price'],2) ?></td><td><?= $it['qty'] ?></td><td>$<?= number_format($it['price']*$it['qty'],2) ?></td></tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot><tr><th colspan="3" class="text-end">Total</th><th>$<?= number_format($order['total'],2) ?></th></tr></tfoot>
      </table>
    </div>
    <a href="<?= url('profile.php?tab=orders') ?>" class="btn btn-outline-grad">Back to Orders</a>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
