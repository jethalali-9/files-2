<?php
if (!isset($page)) $page = '';
if (!isset($title)) $title = 'Admin - Watchify';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($title) ?></title>
  <link rel="icon" href="<?= url('assets/img/favicon.svg') ?>" type="image/svg+xml">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700;800&display=swap" rel="stylesheet">
  <link href="<?= url('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body style="background:var(--light)">
<aside class="admin-sidebar" id="adminSidebar">
  <div class="brand"><img src="<?= url('assets/img/logo.svg') ?>" alt="" style="height:36px;filter:brightness(0) invert(1)"></div>
  <nav class="nav flex-column">
    <a class="nav-link <?= $page==='dashboard'?'active':'' ?>" href="<?= url('admin/index.php') ?>"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a class="nav-link <?= $page==='products'?'active':'' ?>" href="<?= url('admin/products.php') ?>"><i class="bi bi-watch"></i> Products</a>
    <a class="nav-link <?= $page==='brands'?'active':'' ?>" href="<?= url('admin/brands.php') ?>"><i class="bi bi-tags"></i> Brands</a>
    <a class="nav-link <?= $page==='categories'?'active':'' ?>" href="<?= url('admin/categories.php') ?>"><i class="bi bi-grid"></i> Categories</a>
    <a class="nav-link <?= $page==='orders'?'active':'' ?>" href="<?= url('admin/orders.php') ?>"><i class="bi bi-bag-check"></i> Orders</a>
    <a class="nav-link <?= $page==='users'?'active':'' ?>" href="<?= url('admin/users.php') ?>"><i class="bi bi-people"></i> Users</a>
    <a class="nav-link text-danger" href="<?= url('admin/logout.php') ?>"><i class="bi bi-box-arrow-right"></i> Logout</a>
    <hr class="border-light opacity-25">
    <a class="nav-link" href="<?= url('index.php') ?>"><i class="bi bi-house"></i> View Site</a>
  </nav>
</aside>
<div class="admin-main">
  <div class="admin-topbar">
    <button class="btn btn-outline-grad d-lg-none" id="adminToggle"><i class="bi bi-list"></i></button>
    <h5 class="fw-bold mb-0"><?= e($title) ?></h5>
    <div class="d-flex align-items-center gap-2">
      <span class="badge rounded-pill" style="background:var(--grad-gold)">Admin</span>
      <span class="text-muted small"><?= e($_SESSION['admin_name'] ?? 'Admin') ?></span>
    </div>
  </div>
