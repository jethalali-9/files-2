<?php
require __DIR__.'/../config/config.php';
require_admin();
$page = 'dashboard';
$title = 'Dashboard';
$products = (int)db()->query("SELECT COUNT(*) FROM products")->fetchColumn();
$brands = (int)db()->query("SELECT COUNT(*) FROM brands")->fetchColumn();
$orders = (int)db()->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$users = (int)db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
$revenue = (float)db()->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status<>'Cancelled'")->fetchColumn();
$recent = db()->query("SELECT o.*, u.name user_name FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 6")->fetchAll();
include __DIR__.'/partials/header.php';
?>
<div class="row g-3 mb-4">
  <div class="col-lg-3 col-md-6"><div class="stat-card stat-1"><div class="lbl">Products</div><div class="num"><?= $products ?></div><i class="bi bi-watch position-absolute" style="right:1rem;bottom:1rem;font-size:3rem;opacity:.2"></i></div></div>
  <div class="col-lg-3 col-md-6"><div class="stat-card stat-2"><div class="lbl">Orders</div><div class="num"><?= $orders ?></div><i class="bi bi-bag-check position-absolute" style="right:1rem;bottom:1rem;font-size:3rem;opacity:.2"></i></div></div>
  <div class="col-lg-3 col-md-6"><div class="stat-card stat-3"><div class="lbl">Revenue</div><div class="num">$<?= number_format($revenue,0) ?></div><i class="bi bi-currency-dollar position-absolute" style="right:1rem;bottom:1rem;font-size:3rem;opacity:.2"></i></div></div>
  <div class="col-lg-3 col-md-6"><div class="stat-card stat-4"><div class="lbl">Users</div><div class="num"><?= $users ?></div><i class="bi bi-people position-absolute" style="right:1rem;bottom:1rem;font-size:3rem;opacity:.2"></i></div></div>
</div>
<div class="row g-3">
  <div class="col-lg-8">
    <div class="admin-card">
      <div class="d-flex justify-content-between align-items-center mb-3"><h5 class="fw-bold mb-0">Recent Orders</h5><a href="<?= url('admin/orders.php') ?>" class="btn btn-sm btn-outline-grad">View All</a></div>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>#</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>
          <?php if (!$recent): ?><tr><td colspan="6" class="text-center text-muted py-4">No orders yet</td></tr><?php endif; ?>
          <?php foreach ($recent as $o): ?>
            <tr><td>#<?= $o['id'] ?></td><td><?= e($o['customer_name'] ?: $o['user_name']) ?></td><td>$<?= number_format($o['total'],2) ?></td><td><span class="badge-soft cod"><?= e($o['payment_method'] ?? 'COD') ?></span></td><td><span class="badge-soft <?= strtolower(e($o['status'])) ?>"><?= e($o['status']) ?></span></td><td><?= date('M d', strtotime($o['created_at'])) ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="admin-card">
      <h5 class="fw-bold mb-3">Quick Actions</h5>
      <a href="<?= url('admin/products.php?action=new') ?>" class="btn btn-grad w-100 mb-2"><i class="bi bi-plus-circle"></i> Add Product</a>
      <a href="<?= url('admin/brands.php?action=new') ?>" class="btn btn-outline-grad w-100 mb-2"><i class="bi bi-tag"></i> Add Brand</a>
      <a href="<?= url('admin/categories.php?action=new') ?>" class="btn btn-outline-grad w-100 mb-2"><i class="bi bi-grid"></i> Add Category</a>
      <a href="<?= url('admin/orders.php') ?>" class="btn btn-outline-grad w-100"><i class="bi bi-bag-check"></i> Manage Orders</a>
    </div>
    <div class="admin-card">
      <h5 class="fw-bold mb-3">Overview</h5>
      <div class="d-flex justify-content-between py-2 border-bottom"><span>Brands</span><span class="fw-bold"><?= $brands ?></span></div>
      <div class="d-flex justify-content-between py-2 border-bottom"><span>Products</span><span class="fw-bold"><?= $products ?></span></div>
      <div class="d-flex justify-content-between py-2"><span>Total Orders</span><span class="fw-bold"><?= $orders ?></span></div>
    </div>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
