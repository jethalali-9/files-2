<?php
// Watchify Database Configuration
// Edit these values to match your MySQL / MariaDB setup.

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'watchify');

// Site base URL (change if you deploy in a subfolder)
define('BASE_URL', '/watchify');

// Start session once
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function db() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            die('<h3>Database connection failed.</h3><p>Please import <code>database/watchify.sql</code> and check <code>config/config.php</code>.</p>');
        }
    }
    return $pdo;
}

function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function url($path = '') { return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/'); }

/** Resolve a product image path to a full URL (handles both uploaded files and external URLs). */
function img_url($path) {
    if (!$path) return '';
    if (preg_match('#^https?://#', $path)) return $path;
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}
function redirect($path = '') { header('Location: ' . url($path)); exit; }
function is_logged_in() { return isset($_SESSION['user_id']); }
function is_admin() { return isset($_SESSION['admin_id']); }
function require_login() { if (!is_logged_in()) redirect('login.php'); }
function require_admin() { if (!is_admin()) redirect('admin/login.php'); }
function find($table, $id) {
    $stmt = db()->prepare("SELECT * FROM `$table` WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}
