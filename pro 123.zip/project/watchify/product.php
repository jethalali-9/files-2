<?php
require __DIR__.'/config/config.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT p.*, b.name brand_name, b.slug brand_slug, c.name cat_name, c.slug cat_slug FROM products p JOIN brands b ON b.id=p.brand_id JOIN categories c ON c.id=p.category_id WHERE p.id=? AND p.status='active'");
$stmt->execute([$id]);
$p = $stmt->fetch();
if (!$p) redirect('shop.php');
$related = db()->prepare("SELECT p.*, b.name brand_name, c.name cat_name FROM products p JOIN brands b ON b.id=p.brand_id JOIN categories c ON c.id=p.category_id WHERE p.category_id=? AND p.id<>? AND p.status='active' LIMIT 4");
$related->execute([$p['category_id'], $id]);
$related = $related->fetchAll();
include __DIR__.'/partials/product_card.php';
include __DIR__.'/partials/header.php';
?>
<div class="container py-4">
  <nav><ol class="breadcrumb breadcrumb-soft"><li class="breadcrumb-item"><a href="<?= url('index.php') ?>">Home</a></li><li class="breadcrumb-item"><a href="<?= url('shop.php') ?>">Shop</a></li><li class="breadcrumb-item"><a href="<?= url('category.php?slug=').e($p['cat_slug']) ?>"><?= e($p['cat_name']) ?></a></li><li class="breadcrumb-item active"><?= e($p['name']) ?></li></ol></nav>
  <div class="row g-4">
    <div class="col-lg-6"><div class="admin-card p-0 overflow-hidden"><img src="<?= img_url($p['image']) ?>" class="w-100" style="aspect-ratio:1/1;object-fit:cover" alt="<?= e($p['name']) ?>"></div></div>
    <div class="col-lg-6">
      <div class="admin-card">
        <span class="brand text-uppercase fw-bold" style="color:var(--emerald-600)"><?= e($p['brand_name']) ?> &middot; <?= e($p['cat_name']) ?></span>
        <h1 class="fw-bold mb-2"><?= e($p['name']) ?></h1>
        <div class="stars mb-3" style="color:var(--gold-400);font-size:1.1rem"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i> <span class="text-muted fs-6">(4.5 / 5)</span></div>
        <div class="d-flex align-items-center gap-3 mb-3">
          <span class="fs-2 fw-bold" style="color:var(--charcoal)">$<?= number_format($p['price'],2) ?></span>
          <?php if ($p['old_price']): ?><span class="fs-4 text-muted text-decoration-line-through">$<?= number_format($p['old_price'],2) ?></span><?php endif; ?>
        </div>
        <p class="text-muted"><?= e($p['description']) ?></p>
        <p><strong>Availability:</strong> <?= $p['stock']>0 ? '<span class="text-success">In stock ('.$p['stock'].')</span>' : '<span class="text-danger">Out of stock</span>' ?></p>
        <div class="cod-banner mb-3" style="padding:.7rem 1rem"><i class="bi bi-cash-coin"></i> <span>Cash on Delivery available</span></div>
        <form method="post" action="<?= url('cart.php') ?>" class="d-flex gap-2 align-items-center mt-3">
          <input type="hidden" name="action" value="add"><input type="hidden" name="id" value="<?= $p['id'] ?>">
          <input type="number" name="qty" value="1" min="1" max="<?= $p['stock'] ?>" class="form-control" style="width:90px">
          <button class="btn btn-grad btn-lg flex-grow-1" <?= $p['stock']<=0?'disabled':'' ?>><i class="bi bi-bag-plus"></i> Add to Cart</button>
        </form>
        <a href="<?= url('brand.php?slug=').e($p['brand_slug']) ?>" class="btn btn-outline-grad btn-lg w-100 mt-2">More from <?= e($p['brand_name']) ?></a>
      </div>
    </div>
  </div>
  <h4 class="fw-bold mt-5 mb-3">Related Watches</h4>
  <div class="row g-4"><?php foreach ($related as $r) echo product_card($r); ?></div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
