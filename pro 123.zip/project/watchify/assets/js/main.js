// Watchify - frontend interactions
document.addEventListener('DOMContentLoaded', function () {
  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('show'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('show'); });
  }

  var toggler = document.getElementById('adminToggle');
  var sidebar = document.getElementById('adminSidebar');
  if (toggler && sidebar) {
    toggler.addEventListener('click', function () { sidebar.classList.toggle('open'); });
  }

  var fileInput = document.getElementById('productImage');
  var preview = document.getElementById('uploadPreview');
  var previewWrap = document.getElementById('previewWrap');
  if (fileInput && preview) {
    fileInput.addEventListener('change', function () {
      var file = this.files[0];
      if (file) {
        var reader = new FileReader();
        reader.onload = function (e) {
          preview.src = e.target.result;
          if (previewWrap) previewWrap.style.display = 'block';
        };
        reader.readAsDataURL(file);
      }
    });
  }
});
