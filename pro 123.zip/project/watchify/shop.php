<?php
require __DIR__.'/config/config.php';
$page = 'shop';
$where = "WHERE p.status='active'";
$params = [];
if (!empty($_GET['brand'])) { $where .= " AND b.slug=?"; $params[] = $_GET['brand']; }
if (!empty($_GET['category'])) { $where .= " AND c.slug=?"; $params[] = $_GET['category']; }
if (!empty($_GET['q'])) { $where .= " AND p.name LIKE ?"; $params[] = '%'.$_GET['q'].'%'; }
$sql = "SELECT p.*, b.name brand_name, b.slug brand_slug, c.name cat_name, c.slug cat_slug FROM products p JOIN brands b ON b.id=p.brand_id JOIN categories c ON c.id=p.category_id $where ORDER BY p.id DESC";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
$brands = db()->query("SELECT * FROM brands ORDER BY name")->fetchAll();
$categories = db()->query("SELECT * FROM categories ORDER BY name")->fetchAll();
include __DIR__.'/partials/product_card.php';
include __DIR__.'/partials/header.php';
?>
<div class="container py-4">
  <nav><ol class="breadcrumb breadcrumb-soft"><li class="breadcrumb-item"><a href="<?= url('index.php') ?>">Home</a></li><li class="breadcrumb-item active">Shop</li></ol></nav>
  <div class="row g-4">
    <div class="col-lg-3">
      <div class="admin-card">
        <h5 class="fw-bold mb-3"><i class="bi bi-funnel"></i> Filters</h5>
        <form method="get">
          <div class="mb-3"><label class="fw-semibold mb-2">Brand</label>
            <?php foreach ($brands as $b): ?>
              <div class="form-check"><input class="form-check-input" type="radio" name="brand" id="b<?= $b['id'] ?>" value="<?= e($b['slug']) ?>" <?= ($_GET['brand']??'')==$b['slug']?'checked':'' ?>><label class="form-check-label" for="b<?= $b['id'] ?>"><?= e($b['name']) ?></label></div>
            <?php endforeach; ?>
          </div>
          <div class="mb-3"><label class="fw-semibold mb-2">Category</label>
            <?php foreach ($categories as $c): ?>
              <div class="form-check"><input class="form-check-input" type="radio" name="category" id="c<?= $c['id'] ?>" value="<?= e($c['slug']) ?>" <?= ($_GET['category']??'')==$c['slug']?'checked':'' ?>><label class="form-check-label" for="c<?= $c['id'] ?>"><?= e($c['name']) ?></label></div>
            <?php endforeach; ?>
          </div>
          <div class="mb-3"><label class="fw-semibold mb-2">Search</label><input type="text" class="form-control" name="q" value="<?= e($_GET['q']??'') ?>" placeholder="Watch name..."></div>
          <button class="btn btn-grad w-100">Apply</button>
          <a href="<?= url('shop.php') ?>" class="btn btn-outline-grad w-100 mt-2">Clear</a>
        </form>
      </div>
    </div>
    <div class="col-lg-9">
      <div class="d-flex justify-content-between align-items-center mb-3"><h4 class="fw-bold mb-0">All Watches <span class="text-muted fs-6">(<?= count($products) ?>)</span></h4></div>
      <?php if (!$products): ?>
        <div class="empty-state"><div class="ic"><i class="bi bi-search"></i></div><h5>No watches found</h5><p>Try adjusting your filters.</p></div>
      <?php else: ?>
        <div class="row g-4"><?php foreach ($products as $p) echo product_card($p); ?></div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__.'/partials/footer.php'; ?>
